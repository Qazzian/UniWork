/*
** Simulates the room and its air temperature.
** This process will run indefinitely receiving pulses of cold/heat
** from room devices. For each pulse divide the pulse temperature 
** by the room capacity to determine the effect of the pulse and
** add the modified pulse temp to the room ambient temperature. When
** the ambient temperature increases/decreases by 1 Celcius
** tell the Thermostat process of the change.
** It is the responsibility of the Thermostat process to shut down
** this process (PHASE 2 ONLY).
**
** Options
** ========
** temperature -c capacity
**             -tdfd {temperature device read file descriptor}
**             -ttfd {temperature thermostat write file descriptor}
** -c: The room capacity in cubic metres
** -tdfd: The pipe input file descriptor used to read pulses of
**     heat/cold from device processes (PHASE 2 ONLY)
** -ttfd: The pipe output file descriptor used to notify the
**     Thermostat process of changes in ambient temperature (PHASE 2)
**
*/

/* ENTER #include HEADERS HERE */

/* ENTER #define AND GLOBAL VARIABLE HERE */

int main(int argc, char *argv[])
{
   /* ENTER HERE: ARGUMENT PROCESSING CODE: PHASE 1, TASK 2 */

   /* Infinite loop waiting for device temperature pulses
   ** and informing Thermostat of changes. PHASE 2 ONLY.
   */
}

