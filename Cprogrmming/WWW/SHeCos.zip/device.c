/*
** Simulates the heating or cooling device.
** This process will run indefinitely sending a pulse of
** cool or warm air every pulseRate seconds to the Temperature process.
** The device process can be switched off and then on again using
** UNIX SIGSTOP and SIGCONT signals (PHASE 2). The parent Thermostat 
** process is also responsible for terminating the device 
** process when it shuts down (PHASE 2).
**
** Options
** ========
** device [-pr pulseRate] [-pt pulseTemp] -tdfd pipeFileDescriptor
** -pr: The device pulse rate (in seconds)
** -pt: The device pulse temperature in Celcius
** -tdfd: The output pipe file descriptor used to send pulses of
**     heat/cold to the Temperature process (PHASE 2 ONLY)
**
*/

/* ENTER HERE #include HEADERS */

/* ENTER HERE ANY USEFUL #define STATEMENTS and global variables */

int main(int argc, char **argv)
{
   /* ENTER HERE PROCESS ARGUMENT CODE: PHASE 1, TASK 2 */

   /*
   ** Now run as infinite loop, sleeping for pulseRate seconds
   ** on each iteration. PHASE 2 ONLY
   */

}

