/*
** controller.c
** Synopsis
** ========
** controller building-directory
**
** Description
** ===========
** This is the main executable for the office building heating system.
** The program takes the pathname to the building database
** and navigates through the database's directory tree structure
** to find rooms that require heating/cooling.
** A room requires controlling if it contains a .properties file.
** Other rooms will be ignored.
** The database directory structure consists of:
** o A directory representing the building
** o Zero or more name.fl subdirectories. These allow
**   the database maintainer to structure the database as
**   a hierarchy of floors. This is optional.
** o Each floor (including the root building directory) may have
**   zero or more name.rm subdirectories. These represent rooms
**   within the building that need heating or cooling. A room can be
**   any building space: office, corridor, foyer etc
** o Each room may have a single .properties file that contains the
**   capacity of the room. Each room may have zero or more
**   name.cl and name.ht files that represent coolers and heaters.
**   None of these files are read by this process, but are used
**   by child thermostat processes started by the controller.
**
**
*/

/* ADD SUITABLE #include FILES HERE */
#include <stdlib.h> /* For NULL definition */

/* ADD SUITABLE #define STATEMENTS HERE E.G. FLAG CONSTANTS */

/* struct room defines a room node. Not all the fields are used
** in Phase 1
*/

struct room
{
   int thermostatPid;                 /* Process id of thermostat */
   char *location;                    /* Room location path */
   int desiredTemp;                   /* Desired temp for room */
   int switchedOn;                    /* Is the thermostat switched on? */
   int controllerThermostatOutputFd;  /* Pipe output fd for thermostat */
   int controllerThermostatInputFd;   /* Pipe input fd for thermostat */
   struct room *nextroom;             /* Next room in the list */
};

/* struct floor represents a floor node */

struct floor
{
   struct floor *upstairs;            /* The floor above! */
   struct room *firstroom;            /* The first room */
   char *location;                    /* The floor location path */
};

typedef struct floor *treeT;

treeT databasetree;

int switchThermostatOnOff(struct room *rm, int switchOn);
struct room *findRoom(treeT, char *roomName);
const char *lastelement(const char *pathname);
const char *getextension(const char *pathname);
void fatal(char *message);

main(int argc, char **argv)
{
   void processcommands(treeT databasetree);

   /* Obtain the arguments */

   /* ENTER CODE HERE. PHASE 1, TASK 1 */

   /* Traverse the database and build the in-memory data-structure
   ** that mimics the database.
   */

   /* ENTER CODE HERE. PHASE 1, TASK 3 */

   /* Now display the command prompt to users, and process user commands */
   processcommands(databasetree);
}

void processcommands(treeT databasetree)
{
   /*
   ** Presents the user with a command line prompt representing
   ** the control panel of the thermostat controller.
   ** The command line arguments supported are:
   **
   ** switch {all | pathname}{on | off}
   ** ===================================
   ** This will switch on or off the thermostats in the
   ** building. They can all be switched on or off or
   ** a specific room's thermostat can be started or stopped.
   ** With switch on, the default desired temperature setting is
   ** passed as an argument to the new thermostat process.
   **
   ** set {def | all | pathname} temperature
   ** ===========================================
   ** Sets the desired temperature (Celcius). "def" will set the
   ** default temperature. If "all" is specified then all running
   ** thermostat processes will be sent a new desired temperature. If
   ** a pathname is specified then the room identified by that pathname
   ** will have its thermostat desired temperature setting changed.
   **
   ** getd {def | all | pathname}
   ** ===================================
   ** Gets the desired temperature. Either the default,
   ** a list of temperatures for each active room, or the temperature
   ** for a given room identified by the pathname.
   **
   ** geta {all | pathname}
   ** ==========================
   ** Gets the current ambient temperature. Either a list of
   ** temperatures for each active room, or the temperature for
   ** a given room identified by the pathname.
   **
   ** exit
   ** ====
   ** All active rooms must be switched off, followed by an exit
   ** of this controller process.
   */

   /* ENTER CODE HERE. PHASE 1, TASK 1 */
}

/* ENTER ANY UTILITY FUNCTIONS HERE. PHASE 1, TASKS 1 & 3 */


/* Provided Utility Functions */

/******************************************************************************
 * Returns a pointer to the last element of a file path 
 * (i.e. the file name).
 *****************************************************************************/
const char *lastElement(const char *pathname)
{
   char *res = "";

   if (pathname == NULL) {
      return NULL;
   }
   else if (pathname[strlen(pathname)-1] != '/' && (res = strrchr(pathname, '/')) != NULL) {
      /* Was found so extract a copy of the last element */
      return (++res);
   }
   else {
      /* Since no '/' found then assume the pathname is the last element */
      return pathname;
   }
}

/****************************************************************************** 
 * Returns a pointer to the first character of the file/dir extention.
 *****************************************************************************/
const char *getExtension(const char *pathname)
{
   char *res = "";

   if (pathname == NULL) {
      return "";
   }
   else if (pathname[strlen(pathname)-1] != '.' && (res = strrchr(pathname, '.')) != NULL) {
      return ++res;
   }
   else {
      return "";
   }
}

/****************************************************************************** 
 * Prints an error message based on errno and exits the program.
 *****************************************************************************/
void fatal(char *message)
{
   perror(message);
   exit(1);
}

