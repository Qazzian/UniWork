/* The thermostat program has several responsibilities:
** 1. To start several child processes that form part of the
**    central heating system (PHASE 2 ONLY). These are:
**    o The Temperature process: This represents ambient temperature
**      in a room.
**    o One or more cooler or heater device processes: These will
**      simulate the generation of heat or cold within the room.
** 2. It will connect up these processes so that one can interact
**    with another (PHASE 2 ONLY). The connections are:
**    o The cooler and heater processes will send pulses of heat/cold
**      to the Temperature process
**    o The Temperature process will "tell" the thermostat parent
**      process about changes in ambient room temperature
**    o The Thermostat process will switch on or off the cooler and
**      heater processes, and will set their heating/cooling rates
** 3. The thermostat process will receive requests from a central
**    building heating controller process (PHASE 2 ONLY). 
**    These requests will be:
**    o To switch the heaters/coolers on or off
**    o To receive change in desired temperature requests
**    o To receive requests for the current room ambient temperature
**      and send that temperature back to the calling process
*/

/* ENTER SUITABLE #include HEADER FILES */

#include <stdlib.h> /* For NULL definition */

/* ENTER SUITABLE #define statements */

/* ENTER SUITABLE GLOBAL VARIABLES */

/* Predefined data structures for heaters and coolers */
enum devices {Cooler, Heater};

struct device
{
   int pulseRate;              /* Rate device generates heat/cold */
   int pulseTemp;              /* Pulse temperature */
   int switchedOn;             /* Is it switched on? */
   enum devices type;          /* Heater or cooler? */
   int devicePid;              /* Process id of device process */
   struct device *nextDevice;  /* Next device in the list */
};


const char *getextension(const char *pathname);
void fatal(char *message);

main(int argc, char **argv)
{
  /* Process command line arguments
  ** thermostat -dt desiredTempInCelcius
  **            -ctofd {controller to thermostat output fd}
  **            -ctifd {controller to thermostat input fd}
  **            {room pathname}
  ** -dt: The initial desired temperature in Celcius
  ** -ctofd: controller to thermostat pipe output fd (PHASE 2)
  ** -ctifd: controller to thermostat pipe input fd (PHASE 2)
  ** room pathname: The database location of the room
  */

  /* ENTER HERE CODE FOR ARGUMENT PROCESSING: PHASE 1, TASK 2 */

  /* To make life easier when reading room files we set the
  ** current working directory to roomPathname
  */

  /* ENTER CODE HERE IF REQUIRED: PHASE 1, TASK 4 */

  /* Read the .properties file to obtain the room capacity */

  /* ENTER CODE HERE: PHASE 1, TASK 4 */

  /* We now need to start the cooler and heater devices (PHASE 2).
  ** Each is described by a .ht or .cl file. We start
  ** by creating a linked list data structure of coolers and
  ** heaters (PHASE 1)
  */

  /* ENTER CODE HERE: PHASE 1, TASK 4 */

  /* PHASE 2: Starting of device and temperature processes
  ** will go here
  */

  /* Now handle parent process requests and
  ** ambient temperature change notifications from the
  ** temperature process: PHASE 2 ONLY */

  /* while (true)
  {
     handleTemperatureChanges();
     handleControllerRequests();
  }*/  /* while */

}

/* Useful utility functions */

const char *getextension(const char *pathname)
{
   char *res = "";

   if (pathname == NULL)
   {
      return "";
   }
   else if (pathname[strlen(pathname)-1] != '.' &&
            (res = (char *)strrchr(pathname, '.')) != NULL)
   {
      return ++res;
   }
   else
   {
      return "";
   }
}


void fatal(char *message)
{
   perror(message);
   exit(1);
}