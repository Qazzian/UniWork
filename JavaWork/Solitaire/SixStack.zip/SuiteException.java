public class SuiteException extends Exception{

	public SuiteException(){
		super();
	}
	
	public SuiteException(String s){
		super(s);
	}

}