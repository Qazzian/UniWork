// package Qaz.util;

public class ListException extends Exception
{
	public ListException()
	{
		super("List Exception!");
	}
	
	public ListException(String s)
	{
		super(s);
	}
	
}