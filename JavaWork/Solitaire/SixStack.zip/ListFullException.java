// package Qaz.util;

public class ListFullException extends ListException
{
	public ListFullException()
	{
		super("List is full!");
	}
	
	public ListFullException(String s)
	{
		super(s);
	}
	
}