public class SuiteInvalidException extends SuiteException{

	public SuiteInvalidException(){
		super();
	}
	
	public SuiteInvalidException(String s){
		super(s);
	}


}