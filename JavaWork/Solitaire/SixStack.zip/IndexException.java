// // package Qaz.util;

public class IndexException extends Exception
{
	public IndexException()
	{
		super("Index Exception!");
	}
	
	public IndexException(String s)
	{
		super(s);
	}
}