


/**
  * Problem:
  * Develop a hasa class model of the following
  *
  * Nurse                   Casualty            Ward
  * Midwife                 Out Patient         Theatre
  * Surgeon                 In Patient          Waiting Room
  * Doctor                  Orthopaedic         Reception
  * Porter                  Medical             Beds
  * Manager                 Surgical
  * Consultant
  * Gynaecologist
  * Radiographer
  */

 /*
  * Suggested solution - each class will be in a different file
  */

  public class Hospital
  {
  }

  public class StaffList
  {
      private Staff [] theList;
  }

  public class PatientList
  {
      private Casualty [] theList
  }