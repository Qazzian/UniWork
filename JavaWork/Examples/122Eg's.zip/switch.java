.
.
.
.
   int theValue = 0;

   switch (theValue)
   {
       case 1:
          System.out.println("The value is 1");
          break;
       case 2:
          System.out.println("The value is 2");
          break;
       case 3:
       case 4:
          System.out.println("The value is 3 or 4");
          break;
       default:
          System.out.println("Something else was entered ");
          break;
   }