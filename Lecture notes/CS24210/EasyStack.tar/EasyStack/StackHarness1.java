
class StackHarness1 {
  public static void main(String args[]) {

    /* Build a little stack */

    System.out.println("\nPush a Lemon onto an Empty stack\n");
    StackD a_stack = 
      new Push(new Lemon(), new Empty());

    System.out.println("The stack contains:\n");
    a_stack.accept(new ShowContentsV());
  }
}

