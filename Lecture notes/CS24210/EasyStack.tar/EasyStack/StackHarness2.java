
class StackHarness2 {
  public static void main(String args[]) {

    /* Build a little stack*/

    System.out.println("\nPush an Apple and then " + 
      "a Peach onto on Empty stack\n");
    StackD a_stack = 
      new Push(new Peach(), 
          new Push(new Apple(), new Empty())
      );

    System.out.println("The stack contains:\n");
    a_stack.accept(new ShowContentsV());
  }
}

