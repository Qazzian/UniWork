
class StackHarness4 {
  public static void main(String args[]) {

    /* Build a little stack */

    System.out.println("\nCreate an Empty Stack\n");
    StackD a_stack = new Empty();

    System.out.println("The stack contains:\n");
    a_stack.accept(new ShowContentsV());
  }
}

