
class StackHarness5 {
  public static void main(String args[]) {

    /* Build a little stack */

    System.out.println("\nPush an Apple, then a Fig, " + 
      "then a Peach, then an Integer onto an Empty stack\n");
    StackD a_stack = new Push(new Integer(5),
      new Push(new Peach(), 
        new Push(new Fig(),
          new Push(new Apple(), 
            new Empty()
          )
        )
      )
    );

    System.out.println("The stack contains:\n");
    a_stack.accept(new ShowContentsV());

    System.out.println("\nRemove one item from the stack\n");
    a_stack = (StackD) a_stack.accept(new PopV());

    System.out.println("The stack contains:\n");
    a_stack.accept(new ShowContentsV());

    System.out.println("\nRemove one item from the stack\n");
    a_stack = (StackD) a_stack.accept(new PopV());

    System.out.println("The final stack contains:\n");
    a_stack.accept(new ShowContentsV());
  }
}

