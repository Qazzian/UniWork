
abstract class StackD {
  abstract Object accept(StackVisitorI ask);
}

class Empty extends StackD {
  Object accept(StackVisitorI ask) {
    return ask.forEmpty();
  }
}

class Push extends StackD {
  Object f;
  StackD s;
  Push (Object _f, StackD _s) {
    f = _f;
    s = _s;
  }

  Object accept(StackVisitorI ask) {
    return ask.forPush(f,s);
  }
}

interface StackVisitorI {
  Object forEmpty();
  Object forPush(Object f, StackD s);
}

class ShowContentsV implements StackVisitorI {
  public Object forEmpty() {return null;}

  public Object forPush(Object f, StackD s) {
    System.out.println(f.getClass().getName());
    s.accept(this);
    return null;
  }
}

class PopV implements StackVisitorI {
  public Object forEmpty() {return new Empty();}
  public Object forPush(Object f, StackD s) {
    return (StackD) s;
  }
}

