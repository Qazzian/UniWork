
class StackHarness3 {
  public static void main(String args[]) {

    /* Build a little stack */

    System.out.println("\nPush an Apple, then a Fig, " +
      "then a Peach onto an Empty stack\n");
    StackD a_stack = 
      new Push(new Peach(), 
        new Push(new Fig(),
          new Push(new Apple(), 
            new Empty()
          )
        )
      );

    System.out.println("The stack contains:\n");
    a_stack.accept(new ShowContentsV());
  }
}

