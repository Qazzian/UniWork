#include "tree.h"
#include <stdlib.h>

tree_t *mknode(TREE_LABEL_T label, tree_t *l, tree_t *r) {
	tree_t *the_node = malloc(sizeof(tree_t));
	the_node -> this = label;
	the_node -> left = l;
	the_node -> right = r;
	return the_node;
}

tree_t *mkleaf(TREE_LABEL_T label) {
	return mknode(label,NULL,NULL);
}

int isleaf (tree_t *node) {
	return (node -> left == NULL && node -> right == NULL);
}

void postorder(tree_t *root, int (*visit)(TREE_LABEL_T)) {
    if (root != NULL) {
	postorder(root -> left,visit);
	postorder(root -> right,visit);
	visit(root->this);
    }
}

void preorder(tree_t *root, int (*visit)(TREE_LABEL_T)) {
    if (root != NULL) {
	visit(root->this);
	preorder(root -> left,visit);
	preorder(root -> right,visit);
    }
}
