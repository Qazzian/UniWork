#define body_of_installId \
	int i;\
\
        /* this should really check for an error return */\
        if (top_symbol >= max_symbols) {\
           realloc(symbolTable, (top_symbol+10)*sizeof(char *));\
           max_symbols += 10;\
        }\
\
        for (i=0;i<top_symbol;i++)\
          if (!(strncmp(symbolTable[i],yytext,yyleng))) break;\
\
        if (i==top_symbol) {\
          symbolTable[i] =  malloc((yyleng+1)*sizeof(char));\
          strncat(symbolTable[i],yytext,yyleng);\
          top_symbol++;\
        }\
\
        return i;

