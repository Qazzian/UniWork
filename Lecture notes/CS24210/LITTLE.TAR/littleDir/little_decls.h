typedef struct {
        char *label;
        int value;
} label_t;

label_t *makeLabel(char *label, int value);

#define TREE_LABEL_T label_t *
#include "tree.h"

typedef struct {
        char *label;
        int value;
        tree_t *treeptr;
} stack_t;

#define YYSTYPE stack_t

/* labels for SEQ, ASSIGN, IF, BRANCH, WHILE, NUMBER, ID */

#define seq_label "sequ\0"
#define assign_label ":=\0"
#define if_label "if\0"
#define branch_label "branch\0"
#define while_label "while\0"
#define number_label "number\0"
#define id_label "id\0"
#define addto_label "+=\0"
#define subfrom_label "-=\0"
#define lt_label "<\0"
#define le_label "<=\0"
#define eq_label "=\0"

/* symbol table declarations */

int max_symbols = 20;
int top_symbol = 0;
char *symbolTable[20];
int installId(void);
void outputSymbolTable(void);

/* prints the text, identifier name, or integer value
   at a node of the abstract syntax tree
*/

int visitor(TREE_LABEL_T node) {

        if (!strncmp(node->label, id_label)) /* ID */
          printf("%s (%s)\n",node->label,symbolTable[node->value]);

        else if (!strncmp(node->label, number_label)) /* NUMBER */
          printf("%s (%d)\n",node->label,node->value);

        else /* any other kind of node */ printf("%s\n",node->label);

        return 0;
}

