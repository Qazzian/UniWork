#ifndef TREE_LABEL_T
#define TREE_LABEL_T int 
#endif

typedef struct tree_node{
        TREE_LABEL_T this;
        struct tree_node *left;
        struct tree_node *right;
} tree_t;

tree_t *mknode(TREE_LABEL_T, tree_t *, tree_t *);

tree_t *mkleaf(TREE_LABEL_T);

void postorder(tree_t *, int (*)(TREE_LABEL_T));
void preorder(tree_t *, int (*)(TREE_LABEL_T));

