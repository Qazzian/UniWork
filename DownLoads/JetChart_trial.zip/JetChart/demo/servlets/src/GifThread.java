import java.io.*;
import java.util.Date;

/**
 * GifThread.java
 *
 *
 * Created: Mon Dec 27 09:53:30 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */

public class GifThread extends Thread {
    
    String gifWriteDir,gifExpirationTime,gifValidationTime;

    public GifThread(String gifWriteDir,String gifExpirationTime,String gifValidationTime) {
	this.gifWriteDir=gifWriteDir;
	this.gifExpirationTime=gifExpirationTime;
	this.gifValidationTime=gifValidationTime;
	
    }
   
    /**
     * Starts managing gif deletion, based on the expiration and validation time parameters.
     * Note that these two parameters must be combined to define a starting deletion time
     * that is adequated to the period between the gif file generation and remote client
     * request, or the gif file could be deleted before has been sent to the client browser.
     
     * Validation time depends on the average number of server requests. A small number
     * guarantees a clean gif directory in a short time, but can  affect servlet performance,
     * once the cleaning thread will be awaked more frequently. 
     * A long validation time will not affect servlet performance so often, but a consequence is 
     * that gif directory will remain full of files for a longer time.
     * 
     * For the servlet demos, the expiration time has been set to 5, that is, gif file
     * only will be valid just 5 minutes from its last-modified time. After that and when the
     * thread awake and check the interval, the file is deleted.
     *
     * The validation has been set to 5, as well, causing thread to be awaked every 5 minutes.
     */
    public void run() {

	// Creates a File object with a reference to the gif writing directory.
	File gifList=new File(gifWriteDir);

	// Converts gif expiration and validation parameters to milisseconds.
	long gifExpirationTime=60000*(Long.valueOf(this.gifExpirationTime).longValue());
	long gifValidationTime=60000*(Long.valueOf(this.gifValidationTime).longValue());
       
	// Starts validation
	while (true) {

	    try {
		// Puts thread to sleep for the validation time
		Thread.sleep(gifValidationTime);
	    }
	    catch (InterruptedException e) {
	    }

	    // Thread is awake. Gets list of gif files, applying a gif name filter.
	    String[] gifs=gifList.list(new GifFilter());

	    // If exist gifs to be deleted...
	    if (gifs!=null) {

		// A loop to verify lastModified property.
		for (int counter=0;counter<gifs.length;counter ++) {
		    
		    // Gets each gif file name and creates a File object to reference file.
		    File gifName=new File(gifWriteDir+gifs[counter]);
		    
		    // Gets the lastModifed property and the present date in milisseconds.
		    long lastModified=gifName.lastModified();
		    long now=new Date().getTime();

		    /**
		     * Compares the gif file creation date with the present date. If greater than
		     * the gif expiration time, deletes gif file. 
		     */
		    if (now-lastModified>gifExpirationTime) {
			gifName.delete();
			//System.out.println(gifName.getName()+" has been deleted");
		    }
		    
		}
		//System.out.println(" ");
	    }
	}
    }
    
    // A file name filter to gif files
    class GifFilter implements FilenameFilter {
	public boolean accept(File f,String name) {
	    return (name.endsWith(".gif"));
	}
    } 


} 
