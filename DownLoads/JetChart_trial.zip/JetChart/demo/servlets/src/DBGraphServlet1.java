import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;
import java.awt.*;
import java.util.Vector;
import java.util.Date;

import com.jinsight.jetchart.*;

/**
 * DBGraphServlet1.java
 *
 *
 * Created: Wed Dec 22 22:19:49 1999
 * Updated: Thu Sep 07 2000
 * @author Andre de Lima Soares
 * @version 1.1
 */


/**
 * graph database: table Sales - employee,c,20
 *                             - total_sales,n
 *                             - month,c,6
 */

public class DBGraphServlet1 extends HttpServlet implements SingleThreadModel {
    
    Connection conn;
    PreparedStatement psEmployees,psSales;
    
    Graph graph;
    
    PointSerie ps;
    BarSerie bs;
    PieSerie pie;
    
    float[] values;
    
    // Servlet parameters
    String JDBCDriver,url;
    String gifWriteDir,gifURL;
    String gifExpirationTime,gifValidationTime;

    public void init() throws ServletException {
	// Gets servlet init parameters
	getInitParameters();

	
	try {

	    // Connects to database
	    connectDatabase();
	    
	    // Creates three type of series for this demo
	    createSeries();
	    
	    // Creates graphic context and sets it properties
	    createGraphicContext();
	   
	    // Starts cleaning thread. See the GifThread class for a class description
	    GifThread gifThread=new GifThread(gifWriteDir,gifExpirationTime,gifValidationTime);
	    gifThread.start(); 


	}
	catch (Exception e) {
	    e.printStackTrace();
	}

	

	    
    }
    public void destroy() {
	try {
	    // Closes database connection

	    if (psSales!=null)
		psSales.close();

	    if (psEmployees!=null)
		psEmployees.close();

	    if (conn!=null)
		conn.close();

	}
	catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {

	// Gets month and serie type parameters
	String month=req.getParameter("month");
	int serieType=Integer.valueOf(req.getParameter("chart")).intValue();
	
	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();

	try {
	    
	    // Gets list of employees for the selected month
	    String[] employees=getEmployees(month);

	    // If there is a valid list of employees with sales in the selected month...
	    if (employees!=null) {
		values=new float[employees.length];
		psSales.setString(1,month);
		ResultSet rs=psSales.executeQuery();
		int record=0;
		
		while (rs.next()) {
		    String employee=rs.getString(1);
		    float total_sales=rs.getFloat(2);
		    values[record]=total_sales;
		    record++;
		    
		}
	    	
		/** 
		 * It is necessary to close the ResultSet here, because when there is a database
		 * connection with the jdbc-odbc bridge accessing an mdb file, an  exception with
		 * a 'invalid cursor'  message is raised.
		 * 
		 */
		rs.close();
		
		String graphTitle="TOTAL SALES ON "+month.substring(0,2)+"/"+month.substring(2);
		
		graph.setTitle(new String[]{graphTitle});
		
		graph.setLabels(employees);
		
		setSerieType(serieType);
		
		// Generates gif. See ServletGifGenerator class for a detailed description.
		ServletGifGenerator servletGifGenerator=new ServletGifGenerator(graph,gifWriteDir);
		
		// Gets a File reference to the generated gif
		File f=servletGifGenerator.generateFile();
				
		sendGifURL(f,res);
	    }
	    /**
	     * If there is not a valid list of employees, send a message to the remote client 
	     * informing about unavailable data.
	     */
	    else {
		pw.println("<html><body>There is no data available for month "+month.substring(0,2)+
			   "/"+month.substring(2)+"</body></html>");
		pw.close();
	    }
	}
	catch (SQLException e) {
	    pw.println(e.getMessage());
	}
	

    }
    

    private void getInitParameters() throws UnavailableException { 
	
	JDBCDriver=getInitParameter("JDBCDriver");
	url=getInitParameter("url");
	gifWriteDir=getInitParameter("gifWriteDir");
	gifURL=getInitParameter("gifURL");
	gifExpirationTime=getInitParameter("gifExpirationTime");
	gifValidationTime=getInitParameter("gifValidationTime");

	if (JDBCDriver==null)
	    throw new UnavailableException(this,"Missing JDBC Driver parameter.");
	if (url==null)
	    throw new UnavailableException(this,"Missing JDBC url parameter.");
	if (gifWriteDir==null)
	    throw new UnavailableException(this,"Missing gif write directory parameter.");
	if (gifURL==null)
	    throw new UnavailableException(this,"Missing gif URL parameter.");
	if (gifExpirationTime==null)
	    throw new UnavailableException(this,"Missing gif expiration time.");
	if (gifValidationTime==null)
	    throw new UnavailableException(this,"Missing gif validation time in servlet.properties file.");


    }

    private void connectDatabase() throws SQLException,ClassNotFoundException {
	Class.forName(JDBCDriver);
	conn=DriverManager.getConnection(url,"root","ptax7mf3");
	
	// Prepares queries to be executed on database
	psSales=conn.prepareStatement("SELECT EMPLOYEE,TOTAL_SALES FROM Sales WHERE MONTH=? ORDER BY EMPLOYEE");
	
	/**
	 * The prepared statement below returns a ResultSet containing employees with  sales in a 
	 * given month. The chart labels will be these employees names.
	 */
	psEmployees=conn.prepareStatement("SELECT DISTINCT EMPLOYEE FROM Sales WHERE MONTH=? ORDER BY EMPLOYEE");
    }

    private void createGraphicContext() {
	
	// Creates Graph object.
	graph=new Graph();

	// Defines servlet environment and chart size. These are mandatory settings. 
	//graph.setServletApplication(true); // DEPRECATED
	graph.setOffScreenGraphEnabled(true);
	graph.setSize(400,300);

	// Enables grid
	graph.setGridEnabled(true);

	// Enables 3D
	graph.set3DEnabled(true);

	// Sets value format
	graph.setValueFormat("###,###");

	// Sets color and font of the horizontal axis
	graph.getXAxis().setColor(Color.red);
	graph.getXAxis().setFont(new Font("SansSerif",Font.PLAIN,12));

	// Sets 3D color of the horizontal and vertical axis
	graph.getXAxis().setFill3DColor(Color.orange);
	graph.getYAxis().setFill3DColor(Color.orange);

	// Sets chart title font and color
	graph.setTitleFont(new Font("SansSerif",Font.BOLD,12));
	graph.setTitleForeground(Color.blue);

	// Sets legend orientation to horizontal
	graph.getLegend().setOrientation(Legend.HORIZONTAL);

	// Sets gradient colors from white to black
	graph.setGradientColors(Color.white,Color.gray);
	
	// Sets gradient colors painting from bottom to top
	graph.setGradientOrientation(Graph.BOTTOM_TO_TOP);
	

    }


    private void createSeries() {
	
	// Creates Point Serie.
	ps=new PointSerie(null,"Total Sales per month");
	//ps.setShape(PointSerie.TRIANGLE);
	ps.setColor(Color.pink);

	// Enables mark legend on point serie.
	ps.setMarkLegendEnabled(true);

	// Disable mark legend opacity for Point Serie ps.
	ps.setMarkLegendOpacityEnabled(false);
	
	ps.setMarkLegendForeground(Color.red);
	ps.setFont(new Font("SansSerif",Font.BOLD,10));

	// Creates Bar Serie
	bs=new BarSerie(null,"Total Sales per month");
	bs.setColor(Color.green.darker());

	// Creates Pie Serie
	pie=new PieSerie(null);
	

    }

    /**
     * This method executes prepared statement psEmployees and returns a list
     * of employees with values for a given month. This method is executed each
     * time a new request arrives from the remote client.
     */
    private String[] getEmployees(String month) throws SQLException { 

	String[] employees=null;

	psEmployees.setString(1,month);
	ResultSet rs=psEmployees.executeQuery();
	Vector employeesList=new Vector();
	while (rs.next()) 
	    employeesList.addElement(rs.getString(1));

	/** 
	 * It is necessary to close the ResultSet here, because when there is a database
	 * connection with the jdbc-odbc bridge accessing an  mdb file, an  exception with
	 * a 'invalid cursor'  message is raised.
	 * 
	 */
	
	rs.close();
    	
  if (employeesList.size()!=0) {
	    employees=new String[employeesList.size()];
	    for (int counter=0;counter<employeesList.size();counter++)
		employees[counter]=(String)employeesList.elementAt(counter);
	}

	return employees;
	
    }


    
    // Sets serie type. 
    private void setSerieType(int serieType) {

	// Fist remove all previous added series.
	graph.removeAllSeries();
	switch (serieType) {
	case 1 : { // A Point Serie was selected
	    ps.setValues(values);
	    graph.addSerie(ps);
	    break;
	}
	case 2 : {
	    bs.setValues(values); // A Bar Serie was selected
	    graph.addSerie(bs);
	    break;
	}
	case 3 : {
	    pie.setValues(values); // A Pie Serie was selected.

	    /**
	     * Each time new values are assigned to a Pie Serie, new Slices are created. So,
	     * each new slice content and opacity must be assigned here, instead of when
	     * the PieSerie pie was created.
	     */
	    Slice[] slices=pie.getSlices();
	    for (int counter=0;counter<slices.length;counter++) {
		slices[counter].setSliceLegendEnabled(true);
		slices[counter].getSliceLegend().setContent(SliceLegend.LABEL_AND_PERCENT);
		slices[counter].getSliceLegend().setOpacityEnabled(true);
	    }
	    graph.addSerie(pie);
	    break;
	}
	}
    }


    private void sendGifURL(File f,HttpServletResponse res) throws IOException {
	/**
	 * Here, image is not sent directly to the remote client, but just  html code containing
	 * the url location of the gif file. After sending the html content to the client, the gif 
	 * file can not be immediately deleted. That's because interpretation  of
	 * the html code occurs when it reaches the client browser, and at this moment, if 
	 * the gif file has been deleted, the browser will not show it.
	 * A consequence is a growing nr of generated gif files in the gif directory.
	 * To eliminate this problem, the cleaning thread started at the end of the init() method
	 * manages gif deletion, based on the expiration and validation time informed int the
	 * servlet.properties file.
	 */
	
	
	res.setContentType("text/html");

	// Gets file name and eliminates directory path.
	String fileName=f.getName();
	int fileSeparatorIndex=fileName.lastIndexOf("/");

	if (fileSeparatorIndex!=-1)
	    fileName=fileName.substring(fileSeparatorIndex+1);

	PrintWriter pw=res.getWriter();
	pw.println("<html><body bgcolor=#33ccff><center><table border=2>"+
		   "<tr><td><img src="+gifURL+fileName+"></td></tr></table></body></html>");

	pw.close();
    }
}
			       

    
