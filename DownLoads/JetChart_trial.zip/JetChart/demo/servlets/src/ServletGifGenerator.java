import java.io.*;
import java.util.Date;

/**
 * ServletGifGenerator.java
 *
 *
 * Created: Mon Dec 27 10:35:34 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */

import com.jinsight.jetchart.*;

public class ServletGifGenerator {
    Graph graph;
    String gifWriteDir;

    public ServletGifGenerator(Graph graph,String gifWriteDir) {
	this.graph=graph;
	this.gifWriteDir=gifWriteDir;
    }

    public File generateFile() throws IOException {

	/**
	 * The name of the generated gif file is unique.
	 * The name is based on the current millisecond time, which certainly assures
	 * uniqueness. A necessary step to avoid problem with the cache of the remote
	 * browser. When a gif is always generated with the same name, and its reference is
	 * returned to the browser more than once, the browser checks cache to
	 * avoid a new net download, and when it finds a gif with the same name referenced
	 * in the html code, this wrong image is presented instead of the correct one.
	 * Neither a "Cache-control" nor a "Expires" headers in the response content were efficient to
	 * prevent this behavior.
	 * 
	 */
	long time=new Date().getTime();

	// Creates a File object to be passed to the gifEncode() method.
	File f=new File(gifWriteDir+time+".gif");
	
	/** 
	 * Here, creates the gif file in the directory informed in the gifWriteDir variable.
	 * The second parameter of the gifEncode method is just a scale factor.
	 */
	graph.gifEncode(f,100);

	return f;

    }
}
	
    
