import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Date;
import java.awt.Toolkit;

import java.awt.*;

import com.jinsight.jetchart.*;

/**
 * GraphServlet.java
 *
 *
 * Created: Sun Dec 19 15:12:15 1999
 * Updated: Thu Sep 07 2000
 * @author Andre de Lima Soares 
 * @version 1.0
 */


/**
 * This is a basic servlet demo that generates gif files from client requests.
 * There is just one graphic context(graph object) where all series are painted.
 * The GraphServlet implements, here, a SingleThreadModel interface,  to
 * avoid concurrency inside the doGet() method. Each gif file is generated with
 * a unique name, read from its directory and then sent to the remote client.
 */

public class GraphServlet  extends HttpServlet implements SingleThreadModel {
    
    // Graphic context
    Graph graph;

    // Servlet parameters
    String gifWriteDir,imageSerieGifDir,gifURL,gifExpirationTime,gifValidationTime;

    // Values to be passed to series
    float[] values1,values2,values3,values4;


    /**
     * Series references
     */
    AreaSerie as1,as2;
    StackBarSerie sb1,sb2,sb3,sb4;
    PieSerie pie;
    ImageSerie is;

    /**
     * Servlet initialization. 
     */
    public void init() throws ServletException {
	// Gets servlet parameters
	getInitParameters();

	createGraphicContext();

	// Starts cleaning thread. See the GifThread class for a class description
	GifThread gifThread=new GifThread(gifWriteDir,gifExpirationTime,gifValidationTime);
	gifThread.start(); 

    }

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException {

	// Creates graphic context
	//createGraphicContext();
	
	// Gets and sets serie type from request parameter.
	int serieType=Integer.valueOf(req.getParameter("serie")).intValue();


	setSerieType(serieType);
	// Sets graph properties from request parameters. 
	setGraphProperties(req);
	

	// Generates gif. See ServletGifGenerator class for a detailed description.
	ServletGifGenerator servletGifGenerator=new ServletGifGenerator(graph,gifWriteDir);
	
	// Gets a File reference to the generated gif
	File f=servletGifGenerator.generateFile();

	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();

	// Gets file name and eliminates directory path.
	String fileName=f.getName();
	int fileSeparatorIndex=fileName.lastIndexOf("/");

	if (fileSeparatorIndex!=-1)
	    fileName=fileName.substring(fileSeparatorIndex+1);

	pw.println("<html><body bgcolor=#33ccff><center><table border=2>"+
		   "<tr><td><img src="+gifURL+fileName+"></td></tr></table></body></html>");
	pw.close();

	    
    }
	
    private File createGifFile() throws IOException {
	
	/**
	 * The name of the generated gif file is unique.
	 * The name is based on the current millisecond time, which certainly assures
	 * uniqueness.
	 */
	long time=new Date().getTime();
	
	// Creates a File object to be passed to the gifEncode() method.
	File f=new File(gifWriteDir+time+".gif");
	System.out.println("chegou aqui");
	// Here, creates the gif file in the directory informed in the gifWriteDir variable.
	graph.gifEncode(f,100);

	return f;
    }    
    
    private void getInitParameters() throws UnavailableException {
	/**
	 * Gets the gif directory name from the servlet.properties file.
	 */

	gifWriteDir=getInitParameter("gifWriteDir");
	imageSerieGifDir=getInitParameter("imageSerieGifDir");
	gifURL=getInitParameter("gifURL");
	gifExpirationTime=getInitParameter("gifExpirationTime");
	gifValidationTime=getInitParameter("gifValidationTime");
	
	if (gifWriteDir==null)
	    throw new UnavailableException(this,"Missing gif write directory parameter.");
	if (imageSerieGifDir==null)
	    throw new UnavailableException(this,"Missing image serie gif directory parameter.");
	if (gifURL==null)
	    throw new UnavailableException(this,"Missing gif URL parameter.");
	if (gifExpirationTime==null)
	    throw new UnavailableException(this,"Missing gif expiration time.");
	if (gifValidationTime==null)
	    throw new UnavailableException(this,"Missing gif validation time.");	
	
    }

    private void createGraphicContext() {
	
	// Creates labels for the chart
	String[] labels={"label1","label2","label3","label4"};

	/**
	 * Creates float values for the series. Of course, this is a simple example.
	 * Values could come from a database, based on parameters, inside the doGet() method.
	 */
	values1=new float[]{300,500,100,400};
	values2=new float[]{600,200,400,800};
	values3=new float[]{100,700,300,400};
	values4=new float[]{500,900,450,760};

	// Creates graphic context
	graph=new Graph(labels);
	
        // Disposes series in line(this is noticed only when there are two or more series).
	graph.set3DSeriesInLineEnabled(true);

	// Sets initial gradient colors
	graph.setGradientColors(Color.yellow,Color.blue);

	// Sets legend font and orientation
	graph.getLegend().setFont(new Font("SansSerif",Font.PLAIN,10));
	graph.getLegend().setOrientation(Legend.HORIZONTAL);

	// Enables grid
	graph.setGridEnabled(true);
		
	// Sets chart title
	graph.setTitle(new String[]{"The JetChart Library","Gif File Generation Demo"});
	graph.setTitleFont(new Font("SansSerif",Font.BOLD,14));
	graph.setTitleForeground(Color.blue);


	/**
	 * The two lines below are essential when a Graph object is created inside a Servlet.
	 * The first provides   a valid graphic context to create a non-null off-screen
	 * image where chart will be painted and saved in a gif file. The second sets image size.
	 */
	// graph.setServletApplication(true) // DEPRECATED.
	graph.setOffScreenGraphEnabled(true);
	graph.setSize(400,300);

    }

    private void setGraphProperties(HttpServletRequest req) {

	/**
	 * The legend is enabled by default. However, when an Image Serie is painted
	 * alone, without any series combination, legend is disabled. In this example,
	 * we need to show legend when other type of serie is shown. So, here we force
	 * legend painting, once it could be disabled in a image serie probably painted
	 * before.
	 */
	graph.setLegendEnabled(true);
	
	// Sets 3D state
	graph.set3DEnabled(req.getParameter("trid")!=null);

	// Sets grid state
	graph.setGridEnabled(req.getParameter("grid")!=null);

	// Sets grid type
	graph.getGrid().setCrossedLinesEnabled(req.getParameter("crossedgrid")!=null);
					    
	
	// Sets orientation state
	graph.setHorizontalGraphEnabled(req.getParameter("horizontal")!=null);

	// Gets 3D depth
	int depth=Integer.valueOf(req.getParameter("depth")).intValue();

	/**
	 * Checks if the serie is a Pie Serie. If affirmative, sets 3d depth to depth value
	 */
	PieSerie ps=null;
	if (req.getParameter("serie").equals("6")) {
	    ps=(PieSerie)(graph.getSeries().elementAt(0));
	    ps.set3DDepth(depth);
	}
	else {
	    /**
	     * The methods setVDepth() and setHDepth() do not apply to PieSeries. They set
	     * depth to vertical charts and horizontal charts, respectively.
	     */
	    graph.setVDepth(depth);
	    graph.setHDepth(depth);
	}

	// Gets legend position
	String position=req.getParameter("legposition");
	if (position.equalsIgnoreCase("LEFT"))
	    graph.getLegend().setPosition(Legend.LEFT);
	else if (position.equalsIgnoreCase("RIGHT"))
	    graph.getLegend().setPosition(Legend.RIGHT);
	else if (position.equalsIgnoreCase("BOTTOM"))
	    graph.getLegend().setPosition(Legend.BOTTOM);


	/**
	 * Gets labels axis title. Labels can be on the horizontal or vertical axis. A PieSerie defines
	 * its XAxis title here, too, with the XAxis class setTitle method. The other series defines 
	 * labels title with the Graph class setLabelsTitle method.
	 */
	String labelstitle=req.getParameter("labelstitle");
	if (labelstitle.trim().length()!=0) {
	    // ps is defined on 3D checking.
	    if (ps!=null)
		graph.getXAxis().setTitle(labelstitle);
	    else
		graph.setLabelsTitle(labelstitle);
	}
	else {
	    if (ps!=null)
		graph.getXAxis().setTitle(null);
	    else
		graph.setLabelsTitle(null);
	}

	// Gets values axis title
	String valuestitle=req.getParameter("valuestitle");
	if (valuestitle.trim().length()!=0)
	    // ps is defined on 3D checking
	    if (ps!=null)
		graph.getYAxis().setTitle(valuestitle);
	    else
		graph.setValuesTitle(valuestitle);
	else {
	    if (ps!=null)
		graph.getYAxis().setTitle(null);
	    else
		graph.setValuesTitle(null);
	}

	// Gets XAxis color
	Color xaxiscolor=convertColor(Integer.valueOf(req.getParameter("xaxiscolor")).intValue());
	graph.getXAxis().setColor(xaxiscolor);

	// Gets XAxis 3D color
	Color xaxis3dcolor=convertColor(Integer.valueOf(req.getParameter("xaxis3dcolor")).intValue());
	graph.getXAxis().setFill3DColor(xaxis3dcolor);

	// Gets YAxis color
	Color yaxiscolor=convertColor(Integer.valueOf(req.getParameter("yaxiscolor")).intValue());
	graph.getYAxis().setColor(yaxiscolor);

	// Gets YAxis 3D color
	Color yaxis3dcolor=convertColor(Integer.valueOf(req.getParameter("yaxis3dcolor")).intValue());
	graph.getYAxis().setFill3DColor(yaxis3dcolor);

	// Gets chart size
	int width,height;
	try {
	    width=Integer.valueOf(req.getParameter("width")).intValue();
	    height=Integer.valueOf(req.getParameter("height")).intValue();
	}
	catch (NumberFormatException e) {
	    width=400;
	    height=300;
	}
	graph.setSize(width,height);


	// Gets gradient colors
	Color initGradColor=convertColor(Integer.valueOf(req.getParameter("initGradColor")).intValue());
	Color finalGradColor=convertColor(Integer.valueOf(req.getParameter("finalGradColor")).intValue());
	graph.setGradientColors(initGradColor,finalGradColor);

    }


    /**
     * Sets serie type, based on parameters received by this servlet
     */
    private void setSerieType(int serieType) {

	// removes series previously added
	graph.removeAllSeries();

	switch (serieType) {
	case 1 : {
	   
	    graph.addSerie(createLineSerie1());
	    break;
	}
	case 2 : {
	    graph.addSerie(createAreaSerie1());
	    break;
	}
	case 3 : {
	  
	    graph.addSerie(createPointSerie());
	    break;
	}
	case 4 : {

	    graph.addSerie(createBarSerie());
	  
	    break;
	}
	case 5 : {

	    StackBarSerie.setStackBarWidth(20);
	    
	    graph.addSerie(createStackBarSerie1());
	    graph.addSerie(createStackBarSerie2());
	    graph.addSerie(createStackBarSerie3());
	    graph.addSerie(createStackBarSerie4());

	    break;

	}
	case 6 : {
	    graph.addSerie(createPieSerie());
	    break;
	}
	case 7: {
	    graph.addSerie(createImageSerie());
	    break;
	}
	case 8 : {
            
	    graph.addSerie(createLineSerie1());
	    graph.addSerie(createLineSerie2());

	   
	    break;
	}
	case 9 : {
	    graph.addSerie(createBarSerie());
	    graph.addSerie(createStackBarSerie1());
	    graph.addSerie(createStackBarSerie2());
	    graph.addSerie(createStackBarSerie3());
	    graph.addSerie(createStackBarSerie4());
	    graph.set3DSeriesInLineEnabled(false);
	    break;
	}
	case 10: {
	    graph.addSerie(createAreaSerie2());
	    graph.addSerie(createAreaSerie1());
	}
	}
    }

    /**
     * Gets gradient color based on parameter passed to this servlet
     */
    private Color convertColor(int colorIndex) {
	Color gradColor=null;
	switch (colorIndex) {
	case 0: {
	    gradColor=Color.white;
	    break;
	}
        case 1: {
	    gradColor=Color.black;
	    break;
	}
	case 2: {
	    gradColor=Color.blue;
	    break;
	}
	case 3: {
	    gradColor=Color.green;
	    break;
	}
	case 4: {
	    gradColor=Color.red;
	    break;
	}
	case 5: {
	    gradColor=Color.yellow;
	    break;
	}
	case 6: {
	    gradColor=Color.gray;
	    break;
	}
	case 7: {
	    gradColor=Color.orange;
	    break;
	}
	case 8: {
	    gradColor=Color.cyan;
	    break;
	}
	case 9: {
	    gradColor=Color.magenta;
	    break;
	}
	case 10: {
	    gradColor=Color.pink;
	    break;
	}
	case 11: {
	    gradColor=Color.lightGray;
	    break;
	}
	}
	    
	return gradColor;
    }

    LineSerie createLineSerie1() {
	 
	LineSerie ls1=new LineSerie(values1,"Line 1");
	ls1.setColor(Color.magenta);

	return ls1;
    }

    LineSerie createLineSerie2() {

	 LineSerie ls2=new LineSerie(values2,"Line 2");
	 ls2.setColor(Color.red);

	 return ls2;
    }


    PointSerie createPointSerie() {
	PointSerie ps=new PointSerie(values2,"Point");
	ps.setColor(Color.orange);
	
	return ps;

    }
    
    BarSerie createBarSerie() {
	BarSerie bs=new BarSerie(values4,"Bar");
	bs.setColor(Color.green);
	bs.setWidth(20);
	
	return bs;
    }

    StackBarSerie createStackBarSerie1() {
	
	StackBarSerie sb1=new StackBarSerie(values1,"StackBar 1");
	sb1.setColor(Color.pink);
	
	return sb1;
    }

    StackBarSerie createStackBarSerie2() {

	StackBarSerie sb2=new StackBarSerie(values2,"StackBar 2");
	sb2.setColor(Color.cyan);
	
	return sb2;
    }

    StackBarSerie createStackBarSerie3() {
	
	StackBarSerie sb3=new StackBarSerie(values3,"StackBar 3");
	sb3.setColor(Color.red);

	return sb3;

    }

    
    StackBarSerie createStackBarSerie4() {

	StackBarSerie sb4=new StackBarSerie(values4,"StackBar 4");
	sb4.setColor(Color.yellow);

	return sb4;

    }
    
    AreaSerie createAreaSerie1() {
	AreaSerie as1=new AreaSerie(values3,"Area 1");
	as1.setColor(Color.green.darker());
	return as1;
    }

    AreaSerie createAreaSerie2() {
	AreaSerie as2=new AreaSerie(values4,"Area 2");
	as2.setColor(Color.yellow);

	return as2;
    }

    PieSerie createPieSerie() {

	PieSerie pie=new PieSerie(values1);

	Slice[] slices=pie.getSlices();
	for (int counter=0;counter<slices.length;counter++)
	    slices[counter].setSliceLegendEnabled(true);
	
	for (int counter=0;counter<slices.length;counter++) {
	    slices[counter].getSliceLegend().setOpacityEnabled(true);
	    slices[counter].getSliceLegend().setContent(SliceLegend.VALUE_AND_PERCENT);
	}

	pie.setAngleOffset(90);
	pie.getSlice(1).setPosition(10);
	pie.setBorderEnabled(true);

	return pie;
    }

    ImageSerie createImageSerie() {

    	/**
	 * The images for the ImageSerie are located at the directory specified by the init 
	 * parameter imageSerieGifDir.
	 */
	Image img1=Toolkit.getDefaultToolkit().getImage(imageSerieGifDir+"floppy.gif");
	Image img2=Toolkit.getDefaultToolkit().getImage(imageSerieGifDir+"cdrom.gif");
	Image img3=Toolkit.getDefaultToolkit().getImage(imageSerieGifDir+"floppy.gif");
	Image img4=Toolkit.getDefaultToolkit().getImage(imageSerieGifDir+"cdrom.gif");
	Image[] images={img1,img2,img3,img4};	
	ImageSerie is=new ImageSerie(values2,images);

	return is;

    }

}
