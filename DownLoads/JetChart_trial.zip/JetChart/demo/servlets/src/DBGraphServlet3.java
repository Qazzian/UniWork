import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;


/**
 * DBGraphServlet3.java
 *
 *
 * Created: Thu Jan 20 14:45:34 2000
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */
    
public class DBGraphServlet3 extends HttpServlet implements SingleThreadModel {

    String JDBCDriver,url,appletCodebase;
    Connection conn;
    PreparedStatement ps;

    public void init() throws ServletException {
	getInitParameters();
	openDBConnection();
    }

    public void destroy() {
	try {
	    if (ps!=null)
		ps.close();

	    if (conn!=null)
		conn.close();
	}
	catch (SQLException e) {
	    e.printStackTrace();
	}
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,
    IOException  {

        // Gets year parameter to pass to the prepared statement.
	String year=req.getParameter("year");

	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();

	try {

	    // Fetches information from table Census concerning the requested year.
	    ps.setString(1,year);
	    ResultSet rs=ps.executeQuery();
	    rs.next();
	    String total_men=rs.getString(1);
	    String total_women=rs.getString(2);
	    String urban_men=rs.getString(3);
	    String urban_women=rs.getString(4);
	    String rural_men=rs.getString(5);
	    String rural_women=rs.getString(6);
	    rs.close();

	    /**
             * Starts html code definition. 
	     * The GraphApplet class is configured to show charts concerning the requested year.
	     * The appletCodebase initialization parameter points to the applet url codebase.
	     * In the first applet are shown two bar series.
	     */  
	    String html="<html><body bgcolor=white><center>\n"+
		"<applet code=GraphApplet codebase="+appletCodebase+"\n"+
		" width=350 height=300 archive=GraphApplet.jar>\n"+
		"<param name='title' value='Brazilian Historical Demographic Census,"+
		"Year of "+year+"'>\n"+
		"<param name='showgrid' value='yes'>\n"+
		"<param name='gradientcolors' value='ffffff,66ffff'>\n"+
		"<param name='3d' value='yes'>\n"+
		"<param name='draggable' value='yes'>\n"+
		"<param name='3dseriesinline' value='no'>\n"+
		"<param name='valueformat' value='###,###,###,###'>\n"+
		"<param name='showtooltip' value='yes'>\n"+
		"<param name='legendorientation' value='1'>\n"+
		"<param name='labels' value='Total,Urban Area,Rural Area'>\n"+
		"<param name='serie1' value='bar,Men,ffff00'>\n"+
		"<param name='serie1_values' value='"+total_men+","+urban_men+","+rural_men+"'>\n"+
		"<param name='serie2' value='bar,Women,33cc00'>\n"+
		"<param name='serie2_values' value='"+total_women+","+urban_women+","+rural_women+"'>\n"+
		"</applet>\n";

	    /**
	     * Fetches data from the Census table to configure next applet.
	     * Labels and values of the stack bar series are defined here.
	     */

	    // Capture labels
	    Statement stmt=conn.createStatement();
	    rs=stmt.executeQuery("select year from Census;");
	    String labels="";
	    rs.next();
	    do {
		labels+=!(labels.equals("")) ? "," : "";
		labels+=rs.getString(1);
	    }
	    while (rs.next());

	    rs.close();

	    // Capture serie1 values
	    rs=stmt.executeQuery("select urban_men+urban_women from Census;");
	    String serie1Values="";
	    rs.next();
	    do {
		serie1Values+=!(serie1Values.equals("")) ? "," : "";
		serie1Values+=rs.getString(1);
	    }
	    while (rs.next());
	    
	    rs.close();

	    // Capture serie2 values
	    rs=stmt.executeQuery("select rural_men+rural_women from Census;");
	    String serie2Values="";
	    rs.next();
	    do {
		serie2Values+=!(serie2Values.equals("")) ? "," : "";
		serie2Values+=rs.getString(1);
	    }
	    while (rs.next());


	    /**
	     * Now, finish html code with the second applet and its parameters.
	     */
	    html+="<applet code=GraphApplet codebase="+appletCodebase+" \n"+
		"width=350 height=300 archive=GraphApplet.jar>\n"+
		"<param name='title' value='Brazilian Historical Demographic Census,"+
		"Urban x Rural Areas Demographic Trend'>\n"+
		"<param name='showgrid' value='yes'>\n"+
		"<param name='3d' value='yes'>\n"+
		"<param name='gradientcolors' value='ffffff,99ffcc'>\n"+
		"<param name='draggable' value='yes'>\n"+
		"<param name='3dseriesinline' value='no'>\n"+
		"<param name='valueformat' value='###,###,###,###'>\n"+
		"<param name='showtooltip' value='yes'>\n"+
		"<param name='legendorientation' value='1'>\n"+
		"<param name='labels' value='"+labels+"'>\n"+
		"<param name='serie1' value='stackbar,Urban Area,33ccff'>\n"+
		"<param name='serie1_values' value='"+serie1Values+"'>\n"+
		"<param name='serie2' value='stackbar,Rural Area,ffcc99'>\n"+
		"<param name='serie2_values' value='"+serie2Values+"'>\n"+
		"</applet>\n"+
		"</body></html>";
	    
	    // Sends html code back to remote client.
	    pw.println(html);
	    pw.close();
	}
	catch (SQLException e) {
	    e.printStackTrace();
	}
    }
    
    private void getInitParameters() throws ServletException {

	JDBCDriver=getInitParameter("JDBCDriver");
	url=getInitParameter("url");
	appletCodebase=getInitParameter("appletCodebase");
	if (JDBCDriver==null)
	    throw new UnavailableException(this,"Missing JDBC Driver Parameter.");
	if (url==null)
	    throw new UnavailableException(this,"Missing URL Parameter.");
	if (appletCodebase==null)
	    throw new UnavailableException(this,"Missing Applet Codebase.");
    }

    private void openDBConnection() {
	try {
	    Class.forName(JDBCDriver);
	    conn=DriverManager.getConnection(url,"root","ptax7mf3");
	    ps=conn.prepareStatement("select urban_men+rural_men as total_men,"+
				     "urban_women+rural_women as total_women,"+
				     "urban_men,urban_women,rural_men,rural_women from Census "+
				     "where year=?");

	}
	catch (SQLException e) {
	    e.printStackTrace();
	}
	catch (ClassNotFoundException e) {
	    e.printStackTrace();
	}
    }


}
