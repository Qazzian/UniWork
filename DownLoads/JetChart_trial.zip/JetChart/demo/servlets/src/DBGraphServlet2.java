import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;
import java.awt.*;
import java.util.Vector;

import com.jinsight.jetchart.*;

/**
 * DBGraphServlet2.java
 *
 *
 * Created: Mon Dec 27 09:35:04 1999
 * Updated: Thu Sep 07 2000
 * @author Andre de Lima Soares
 * @version 1.0
 */


/**
 * graph database : table MonthSales - month,c,2
 *                                     year,c,4
 *                                     estimated_sales,float
 *                                     real_sales,float
 *                                     
 */

/**
 * This servlet shows two Line Series. One shows total sales over one year period, and the other
 * shows estimated sales related to each month.
 */
public class DBGraphServlet2 extends HttpServlet implements SingleThreadModel {
   
    Graph graph;
    
    LineSerie ls1,ls2;

    String JDBCDriver,url;
    String gifWriteDir,gifURL;
    String gifExpirationTime,gifValidationTime;

    Connection conn;
    PreparedStatement psSales,psMonths;

    float[] estimatedSales,realSales;
    
    public void init() throws ServletException {
	// Gets servlet init parameters
	getInitParameters();
	
	try {

	    // Connects to database
	    connectDB();
	   
	    // Creates graphic context
	    createGraphicContext();

	    // Creates series
	    createSeries();

	    // Starts cleaning thread. See the GifThread class for a class description
	    GifThread gifThread=new GifThread(gifWriteDir,gifExpirationTime,gifValidationTime);
	    gifThread.start();
	}
	catch (Exception e) {
	    e.printStackTrace();
	}

	

    }

    public void destroy() {
	// Closes connection to database
	try {
	    if (psSales!=null)
		psSales.close();
	    if (psMonths!=null)
		psMonths.close();
	    if (conn!=null)
		conn.close();
	}
	catch (SQLException e) {
	}
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,
	IOException {

	// Gets year parameter
	String year=req.getParameter("year");
	
	
	try {

	    // Gets list of months with sales in the year informed.
	    String[] months=getMonths(year);

	    // If there are months with sales...
	    if (months!=null) {
		
		// Creates two float arrays to receive estimated and real sales values
		estimatedSales=new float[months.length];
		realSales=new float[months.length];

		int record=0;

		// Query table MonthSales about values
		psSales.setString(1,year);
		
		ResultSet rs=psSales.executeQuery();
		
		// Fills arrays with values returned from ResultSet rs
		while (rs.next()) {
		    estimatedSales[record]=Float.valueOf(rs.getString(1)).floatValue();
		    realSales[record]=Float.valueOf(rs.getString(2)).floatValue();
		    record++;
		}
		
		/** 
		 * It is necessary to close the ResultSet here, because when there is a database
		 * connection with the jdbc-odbc bridge accessing an  mdb file, an  exception with
		 * a 'invalid cursor'  message is raised.
		 * 
		 */
		rs.close();
	    	
		// Sets title of graphic context to the specified year
		graph.setTitle(new String[]{"ESTIMATED SALES x REAL SALES","YEAR OF "+year});

		// Sets labels of graphic context to the specified year
		graph.setLabels(months);

		// Sets values of each line serie
		ls1.setValues(estimatedSales);
		ls2.setValues(realSales);

		// Generates gif. See ServletGifGenerator class for a detailed description.
		ServletGifGenerator servletGifGenerator=new ServletGifGenerator(graph,gifWriteDir);

		// Gets a File reference to the generated gif
		File f=servletGifGenerator.generateFile();
		
		// Sends html code to the remote client referencing the generated gif
		sendGifURL(f,res);
	    }
	    // If there isn't any values for the selected month...
	    else {
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		pw.println("<html><body>There is no data available for year "+year+
			   "</body></html>");
		pw.close();
	    }

	}
	catch (SQLException e) {
	    e.printStackTrace();
	}
	


    }

    private String[] getMonths(String year) throws SQLException {
	String[] months=null;
	psMonths.setString(1,year);
	ResultSet rs=psMonths.executeQuery();
	Vector monthsList=new Vector();
	
	while (rs.next()) 
	    monthsList.addElement(rs.getString(1));
	
	/** 
	 * It is necessary to close the ResultSet here, because when there is a database
	 * connection with the jdbc-odbc bridge accessing an  mdb file, an  exception with
	 * a 'invalid cursor'  message is raised.
	 * 
	 */
	rs.close();
    	
    	
	if (monthsList.size()!=0) {
	    months=new String[monthsList.size()];
	    for (int counter=0;counter<monthsList.size();counter++)
		months[counter]=(String)monthsList.elementAt(counter);
	}
	return months;
    }

	

    public void getInitParameters() throws UnavailableException {
	JDBCDriver=getInitParameter("JDBCDriver");
	url=getInitParameter("url");
	gifWriteDir=getInitParameter("gifWriteDir");
	gifURL=getInitParameter("gifURL");
	gifExpirationTime=getInitParameter("gifExpirationTime");
	gifValidationTime=getInitParameter("gifValidationTime");

	if (JDBCDriver==null)
	    throw new UnavailableException(this,"Missing JDBC Driver parameter.");
	if (url==null)
	    throw new UnavailableException(this,"Missing JDBC url parameter.");
	if (gifWriteDir==null)
	    throw new UnavailableException(this,"Missing gif write directory parameter.");
	if (gifURL==null)
	    throw new UnavailableException(this,"Missing gif URL parameter.");
	if (gifExpirationTime==null)
	    throw new UnavailableException(this,"Missing gif expiration time.");
	if (gifValidationTime==null)
	    throw new UnavailableException(this,"Missing gif validation time.");
    }

    private void connectDB()  throws SQLException,ClassNotFoundException {
	Class.forName(JDBCDriver);
	conn=DriverManager.getConnection(url,"root","ptax7mf3");
	psSales=conn.prepareStatement("SELECT estimated_sales,real_sales FROM MonthSales "+
				      "WHERE year=? ORDER BY month");
	psMonths=conn.prepareStatement("SELECT DISTINCT month FROM MonthSales WHERE "+
				       "year=? ORDER BY month");
    }

    private void createGraphicContext() {
	 graph=new Graph();
	 graph.setLabelsTitle("Month");
	 graph.setGridEnabled(true);
	 graph.getGrid().setCrossedLinesEnabled(true);
	 graph.getLegend().setOrientation(Legend.HORIZONTAL);
	 graph.setGradientColors(Color.yellow,new Color(0,140,255));
	 
	 //graph.setServletApplication(true); // DEPRECATED
         graph.setOffScreenGraphEnabled(true);
	 graph.setSize(300,300);
    }

    private void createSeries() {
	
	ls1=new LineSerie(null,"Estimated sales");
	ls1.setColor(Color.blue);
	ls1.setThickness(2);
	ls1.setMarksEnabled(false);
	

	ls2=new LineSerie(null,"Real sales");
	ls2.setColor(Color.red);
	ls2.setThickness(2);
	ls2.setMarksEnabled(false);

	graph.addSerie(ls1);
	graph.addSerie(ls2);

    }

    private void sendGifURL(File f,HttpServletResponse res) throws IOException {
	
	/**
	 * Here, image is not sent directly to the remote client, but just  html code containing
	 * the url location of the gif file. After sending the html content to the client, the gif 
	 * file can not be immediately deleted. That's because interpretation  of
	 * the html code occurs when it reaches the client browser, and at this moment, if 
	 * the gif file has been deleted, the browser will not show it.
	 * A consequence is a growing nr of generated gif files in the gif directory.
	 * To eliminate this problem, the cleaning thread started at the end of the init() method
	 * manages gif deletion, based on the expiration and validation time informed int the
	 * servlet.properties file.
	 */
	
	res.setContentType("text/html");


	// Gets file name and eliminates directory path.
	String fileName=f.getName();
	int fileSeparatorIndex=fileName.lastIndexOf("/");

	if (fileSeparatorIndex!=-1)
	    fileName=fileName.substring(fileSeparatorIndex+1);

	PrintWriter pw=res.getWriter();
	pw.println("<html><body bgcolor=#33ccff><center><table border=2>"+
		   "<tr><td><img src="+gifURL+fileName+"></td></tr></table></body></html>");

	pw.close();
    }

 

}	
