The servlet source files are compatible with jsdk 2.1 version. 
To compile with the jsdk 2.0 version, the init() method must be
changed  to receive a ServletConfig object, as below:

public void init(ServletConfig sc) {
   super.init(sc);
         .
         .
         .
}

When running the servletrunner script, the servlet.properties
file directory must be informed with the -d option.
Suppose the servlets classes and the servlet.properties files
are located in a directory named /home/JetChart/demo/servlets.
the servletrunner must be executed with the -d option:

servletrunner -d /home/JetChart/demo/servlets

Additional information can be obtained in the jsdk2.0 
documentation.
