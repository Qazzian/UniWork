import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

public class Main extends Frame implements ItemListener,AdjustmentListener {
    Graph graph;
    StackBarSerie sbs1,sbs2,sbs3;
    
    Checkbox is3D,isHorizontal;

    Scrollbar depth;

    public Main() {
	
	// A title for the frame
	setTitle("The JetChart Library - Stacked Bars Chart Demo");
	
	// Values for the series
	float[] values1={100,200,150,400};
	float[] values2={300,150,90,180};
	float[] values3={500,350,200,100};
	
	// Creates three bar series
	sbs1=new StackBarSerie(values1,"Stack Bar Serie 1");
	sbs2=new StackBarSerie(values2,"Stack Bar Serie 2");
	sbs3=new StackBarSerie(values3,"Stack Bar Serie 3");
	
		
	// Sets stack bar series properties
	setStackBarSeriesProperties();
	
	// Labels for chart
	String[] labels={"label1","label2","label3","label4"};

	// Creates graphic context, passing labels
	graph=new Graph(labels);

	// Sets chart optional properties
	setChartProperties();

	// Adds the three stack bar series to the graphic context
	graph.addSerie(sbs1);
	graph.addSerie(sbs2);
	graph.addSerie(sbs3);

	add("Center",graph);

	// Creates a top panel to layout components
	createTopPanel();

	// Adds window adapter
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(400,350);

	// Centers frame on the screen
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);

	setVisible(true);

    }

    // Event handler for 3D state and chart orientation
    public void itemStateChanged(ItemEvent evt) {
	if (evt.getSource()==is3D) {
	    graph.set3DEnabled(is3D.getState());
	    depth.setEnabled(is3D.getState());
	}
	else if (evt.getSource()==isHorizontal)
	    graph.setHorizontalGraphEnabled(isHorizontal.getState());

	graph.repaint();
    }

    // Event handler for chart depth adjustment
    public void adjustmentValueChanged(AdjustmentEvent evt) {
	if (evt.getSource()==depth) {
	    graph.setVDepth(depth.getValue());
	    graph.setHDepth(depth.getValue());
	    graph.repaint();
	}
    }
	    
	    
    // Creates top panel
    private void createTopPanel( ) {

	// Creates top panel with a border around
	Panel topPanel=new Panel() {
	    public void paint(Graphics g) {
		g.setColor(Color.lightGray);
		g.draw3DRect(0,0,getSize().width-1,getSize().height-1,true);
		g.draw3DRect(2,2,getSize().width-4,getSize().height-4,false);
	    }
	};

	topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
	
	//  Checkbox for 3D property.
	is3D=new Checkbox("3D");
	is3D.setFont(new Font("Arial",Font.PLAIN,10));
	is3D.addItemListener(this);
	
	// Checkbox for chart orientation property
	isHorizontal=new Checkbox("Horizontal");
	isHorizontal.setFont(new Font("Arial",Font.PLAIN,10));
	isHorizontal.addItemListener(this);

	// Scrollbar for chart depth adjustment
	depth=new Scrollbar(Scrollbar.HORIZONTAL,5,1,0,30) {
	    public Dimension getPreferredSize() {
		Dimension d=super.getPreferredSize();
		return new Dimension(100,d.height);
	    }
	};
	
	depth.setEnabled(false);
	depth.addAdjustmentListener(this);
	
	topPanel.add(is3D);
	topPanel.add(isHorizontal);
	topPanel.add(new Label("3D depth:"));
	topPanel.add(depth);
    
	add("North",topPanel);

    }

    private void setStackBarSeriesProperties() {
	// Sets color
	sbs1.setColor(Color.cyan);
	sbs2.setColor(Color.pink);
	sbs3.setColor(Color.yellow);
	
	// Sets width. The setStackBarWidth method sets value of a private static variable of class
	// StackBarSerie, and is valid for all StackBar series.
	StackBarSerie.setStackBarWidth(15);

    }

    private void setChartProperties() {
	
	// Enables tooltip
	graph.setToolTipEnabled(true);	

	// Sets chart title
	String[] title={"Stacked Bars Chart","Demo with three series"};
	graph.setTitle(title);
	
	// Sets labels title
	graph.setLabelsTitle("Labels Title");

	// Sets values title
	graph.setValuesTitle("Values Title");

	// Applies gradient colors to graphic context
	graph.setGradientColors(Color.yellow,new Color(51,102,255));
	//graph.setGradientOrientation(graph.LEFT_TO_RIGHT);

	// Enables chart and legend dragging. A double-click over chart alternates
	// between moving chart and scale adjustment.
	graph.setDraggingEnabled(true);

	// Enables grid and sets grid color
	graph.setGridEnabled(true);
	graph.getGrid().setColor(new Color(153,153,153));
	// graph.getGrid().setCrossedLinesEnabled(true);

	// Sets legend orientation and position. Legend can be dinamically
	// dragged, if the Graph draggable property is set to true.
	graph.getLegend().setOrientation(Legend.HORIZONTAL);
	//graph.getLegend().setPosition(Legend.RIGHT);
	//graph.getLegend().setPosition(Legend.LEFT);

	// Sets format for values.
	graph.setValueFormat("###,###0.00");
    
	// Sets depth for vertical graph.
	graph.setVDepth(5);

	// Sets depth for horizontal graph.
	graph.setHDepth(5);

	// Disables inline painting of 3D series, drawing bar series side by side.
	graph.set3DSeriesInLineEnabled(false);
	
	
    }



    public static void main(String[] args) {
	new Main();
    }
}

