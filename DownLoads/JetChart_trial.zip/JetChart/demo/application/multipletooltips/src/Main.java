import java.awt.*;
import java.applet.*;
import com.jinsight.jetchart.*;

/**
 * Main.java
 *
 *
 * Created: Thu Nov  9 20:52:51 2000
 *
 * @author Andre de Lima Soares
 * @version 1.1
 * Last update: November 9, 2000
 *
 */

/**
 * This is an applet that demonstrates how to configure and use multiple tooltips display.
 * It runs as an application, too.
 */
public class Main extends Applet {

    public void init() {

	setLayout(new BorderLayout());
	
	Graph graph=new Graph();
	graph.setTitle(new String[]{"The JetChart Library","Multiple Tooltips Demo"});

	graph.getXAxis().setColor(Color.red);
	graph.getYAxis().setColor(Color.red);

	graph.setGridEnabled(true);

	graph.getGrid().setColor(new Color(128,128,128));
	
	graph.setDraggingEnabled(true);

	graph.setStartDate("11092000");

	// Enables tooltip display. 
	graph.setToolTipEnabled(true);

	// Sets tooltip delay. Default value is 500 milliseconds.
	graph.setToolTipDelay(300);

	// Enables multiple tooltips display. Multiple tooltips display has no effect with 3D charts.
	graph.setMultipleToolTipsEnabled(true);

	// Sets the distance between tooltips to 20 pixels. Default value is 4.
	graph.getToolTip().setGap(20);

	// Sets the tooltip pointer type to a line. Uncomment this line to see effect.
	//graph.getToolTip().setPointerType(ToolTip.LINE);

	// Disables border around tooltip. Uncomment this line to see effect.
	//graph.getToolTip().setBorderEnabled(false);
	graph.getToolTip().setBackground(new Color(255,255,204));


	// Creates a bar serie and enables highlight.
	BarSerie bs=new BarSerie(new float[]{100,200,300,400,500,600,700,600,500,400,300,200,100},"Bar Serie");
	bs.setColor(Color.blue);
	bs.setHighlightEnabled(true);

	// Creates a line serie, enables highlight, disables marks  and set its thickness to 3 pixels.
	LineSerie ls=new LineSerie(new float[]{50,100,320,400,120,54,345,234,111,434,544,232,112},"Line Serie");
	ls.setColor(Color.green.darker());
	ls.setHighlightEnabled(true);
	ls.setHighlightColor(Color.magenta);
	ls.setThickness(3);
	ls.setMarksEnabled(false);

	graph.addSerie(bs);
	graph.addSerie(ls);

	add("Center",graph);

    }

    public static void main(String[] args) {
	Main m=new Main();
	m.init();
	Frame f=new Frame();
	f.setSize(400,250);
	Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
	f.add("Center",m);
	f.setLocation((d.width-500)/2,(d.height-300)/2);
	f.setVisible(true);
    }

}
