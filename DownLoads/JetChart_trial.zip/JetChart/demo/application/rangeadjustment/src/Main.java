import com.jinsight.jetchart.*;
import java.awt.*;
import java.awt.event.*;
/**
 * Main.java
 * This demo demonstrates range adjustment, with a date chart and an area serie. 
 */

public class Main extends Frame implements ItemListener,AdjustmentListener {
    
    Graph graph;
    Panel p,p2;
    Scrollbar minRangeValue,rangeIncrement;
    Checkbox cb,cb2;
    Label minRange,increment;

    public Main()  {

	setTitle("The JetChart Library - Range Adjustment Demo");

	createPanels();

	graph=new Graph();

	setChartProperties();

	AreaSerie as=new AreaSerie(new float[]{910,905,903,915,930,928,917,901},"Area Serie");
	as.setColor(Color.red);
	
	graph.addSerie(as);

	add("North",p);
	add("Center",graph);
	add("South",p2);
	
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent evt) {
		    System.exit(0);
		}
	    });
	
	setSize(600,500);
	setVisible(true);
    }

    private void createPanels() {
	p=new Panel();
	p.setFont(new Font("Monospaced",Font.PLAIN,10));
	cb=new Checkbox("Disable auto-increment");
	
	cb.addItemListener(this);
	p.add(cb);

	Label l=new Label("Min value:");
	p.add(l);
	// Scrollbar for range adjustment
	minRangeValue=new Scrollbar(Scrollbar.HORIZONTAL,900,1,0,901) {
	    public Dimension getPreferredSize() {
		Dimension d=super.getPreferredSize();
		return new Dimension(100,d.height);
	    }
	};

	minRangeValue.addAdjustmentListener(this);
	p.add(minRangeValue);

	Label l1=new Label("Range increment:");
	p.add(l1);


	// Scrollbar for range increment
	rangeIncrement=new Scrollbar(Scrollbar.HORIZONTAL,2,1,0,101) {
	    public Dimension getPreferredSize() {
		Dimension d=super.getPreferredSize();
		return new Dimension(100,d.height);
	    }
	};

	rangeIncrement.addAdjustmentListener(this);
	p.add(rangeIncrement);

	p2=new Panel();
	p2.setLayout(new FlowLayout(FlowLayout.LEFT));
	p2.setFont((new Font("Monospaced",Font.PLAIN,10)));

	cb2=new Checkbox("Horizontal chart");
	cb2.addItemListener(this);
	p2.add(cb2);

	Label l3=new Label("Min range value:");
	minRange=new Label("900");
	Label l4=new Label("Range increment:");
	increment=new Label("2");
	
	p2.add(l3);
	p2.add(minRange);
	p2.add(l4);
	p2.add(increment);

    }

    private void setChartProperties() {
	graph.setStartDate("07012000");
	graph.setDateIncrement(Graph.MONTH_INCREMENT);
	graph.setTitle(new String[]{"A Date Chart with an Area Serie","Range adjustment demo"});
	
	// sets minimum range value
	graph.setMinRangeValue(900);

	// sets range increment
	graph.setRangeIncrement(2);
	
	// sets 3D effect
	graph.set3DEnabled(true);

	// sets serie start position
	graph.setStartOnAxisEnabled(true);
	
	// enables dragging
	graph.setDraggingEnabled(true);
	
	// enables tooltip 
	graph.setToolTipEnabled(true);

	// enables grid with crossed lines
	graph.setGridEnabled(true);
	graph.getGrid().setCrossedLinesEnabled(true);

	// sets background gradient colors
	graph.setGradientColors(Color.blue,Color.white);

    
    }
    
    public void itemStateChanged(ItemEvent evt) {
	if (evt.getSource()==cb) 
	    graph.setAutoRangeOff(cb.getState());

	if (evt.getSource()==cb2) 
	    graph.setHorizontalGraphEnabled(cb2.getState());

	graph.repaint();
    }

    public void adjustmentValueChanged(AdjustmentEvent evt) {
	// sets new minimum range value
	if (evt.getSource()==minRangeValue) {
	    graph.setMinRangeValue(minRangeValue.getValue());
	    minRange.setText(Integer.toString(minRangeValue.getValue()));
	    graph.repaint();
	}

	// sets new range increment
	if (evt.getSource()==rangeIncrement) {
	    graph.setRangeIncrement(rangeIncrement.getValue());
	    increment.setText(Integer.toString(rangeIncrement.getValue()));
	    graph.repaint();
	}
    }
    

    public static void main(String[] args) {
	new Main();
    }
}
