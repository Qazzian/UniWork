import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import com.jinsight.jetchart.*;


/**
 * SwingConsole.java
 *
 *
 * Created: Fri Nov  5 09:08:35 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */

public class SwingConsole extends JDialog implements ActionListener, ChangeListener,CaretListener  {


    private final int XAXIS=0;
    private final int YAXIS=1;

    JComboBox comboSeries, legendForeground,legendBackground,gridColor;

    JComboBox xAxisFontName,xAxisFontSize,xAxisFontStyle,xAxisColor,xAxis3DColor;
    JComboBox yAxisFontName,yAxisFontSize,yAxisFontStyle,yAxisColor,yAxis3DColor;
    JComboBox toolTipFontName,toolTipFontSize,toolTipFontStyle,toolTipForeground,toolTipBackground;
    

    JCheckBox _3D,flip,valuesOnAxis,move3DSeries,grid,oppositeLines,
	      valueToolTip,opaqueToolTip,dragGraph,showLegend,drawLegendBackground,showValuesOnMarks;
    JTextField toolTipText;
    JSlider depth;
    Graph graph;
    Main demo;
    GradientDlg gd;
    TitleDialog td1,td2,td3;
    MarginsDialog md;
    JRadioButton legendLeft,legendRight,legendBottom,legendVertical,legendHorizontal;
    ButtonGroup bgLegendPosition,bgLegendOrientation;

    JTabbedPane jtp;
    JPanel chartPanel,axisPanel,legendPanel,gridPanel,toolTipPanel;

    JButton gradButton,chartTitleButton,valuesTitleButton,labelsTitleButton,marginsButton;
    
    public SwingConsole(Main demo) {
	super(demo,false);
	setTitle("Control Panel");
	this.graph=demo.graph;
	this.demo=demo;

	jtp=new JTabbedPane();
	jtp.addChangeListener(this);
	
	createChartPanel();
	jtp.addTab("Chart",chartPanel);
	
	createAxisPanel();
	jtp.addTab("Axis",axisPanel);

	createLegendPanel();
	jtp.addTab("Legend",legendPanel);

	createGridPanel();
	jtp.addTab("Grid",gridPanel);

	createToolTipPanel();
	jtp.addTab("ToolTip",toolTipPanel);

	getContentPane().add("Center",jtp);


	setSize(450,300);
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);
	setVisible(true);
    }

    private void createChartPanel() {
	
	chartPanel=new JPanel();
	GridBagLayout gb=new GridBagLayout();
	chartPanel.setLayout(gb);
	GridBagConstraints gc=new GridBagConstraints();
	gc.fill=GridBagConstraints.BOTH;
	gc.weightx=1.0;
	gc.anchor=GridBagConstraints.WEST;
	gc.insets=new Insets(5,5,0,0);
	gc.gridwidth=GridBagConstraints.REMAINDER;
	
	JLabel seriesLabel=new JLabel("Series");
	seriesLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gb.setConstraints(seriesLabel,gc);
	chartPanel.add(seriesLabel);

	gc.gridwidth=1;

	comboSeries=new JComboBox();
	comboSeries.setFont(new Font("SansSerif",Font.PLAIN,10));
	comboSeries.addItem("Bar && StackedBars");
	comboSeries.addItem("Line-01 serie");
	comboSeries.addItem("Area-01 serie");
	comboSeries.addItem("Point-01 serie");
	comboSeries.addItem("Column/Bar-01 serie");
	comboSeries.addItem("Images-01 serie");
	comboSeries.addItem("Line-02 series");
	comboSeries.addItem("Area-02 series");
	comboSeries.addItem("Point-02 series");
	comboSeries.addItem("Column/Bar-02 series");
	comboSeries.addItem("Stacked Bars-2 series");
	comboSeries.addActionListener(this);

	gb.setConstraints(comboSeries,gc);
	chartPanel.add(comboSeries);
	
	gradButton=new JButton("Gradient Colors");
	gradButton.setFont(new Font("SansSerif",Font.PLAIN,10));
	gradButton.addActionListener(this);
	gb.setConstraints(gradButton,gc);
	chartPanel.add(gradButton);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	_3D=new JCheckBox("3D");
	_3D.setSelected(true);
	_3D.setFont(new Font("SansSerif",Font.PLAIN,10));
	_3D.addActionListener(this);
	gb.setConstraints(_3D,gc);
	chartPanel.add(_3D);

	JLabel depthLabel=new JLabel("3D depth:");
	depthLabel.setBackground(Color.yellow);
	depthLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gb.setConstraints(depthLabel,gc);
	chartPanel.add(depthLabel);
	
	gc.gridwidth=1;
	depth=new JSlider(0,30,10);

	depth.setMajorTickSpacing(10);
	depth.setMinorTickSpacing(1);
	depth.setPaintTicks(true);
	depth.setPaintLabels(true);

	depth.addChangeListener(this);
	
	gb.setConstraints(depth,gc);
	chartPanel.add(depth);
	
	move3DSeries=new JCheckBox("Enable 3D Series in line");
	move3DSeries.setFont(new Font("SansSerif",Font.PLAIN,10));
	move3DSeries.addActionListener(this);
	gb.setConstraints(move3DSeries,gc);
	chartPanel.add(move3DSeries);
	
	gc.gridwidth=GridBagConstraints.REMAINDER;

	flip=new JCheckBox("Rotate chart");
	flip.setFont(new Font("SansSerif",Font.PLAIN,10));
	flip.addActionListener(this);
	gb.setConstraints(flip,gc);
	chartPanel.add(flip);

	gc.gridwidth=1;
	valuesOnAxis=new JCheckBox("Paint values on axis");
	valuesOnAxis.setFont(new Font("SansSerif",Font.PLAIN,10));
	valuesOnAxis.addActionListener(this);
	valuesOnAxis.setSelected(true);
	gb.setConstraints(valuesOnAxis,gc);
	chartPanel.add(valuesOnAxis);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	gc.fill=GridBagConstraints.NONE;
	marginsButton=new JButton("Margins");
	marginsButton.setFont(new Font("SansSerif",Font.PLAIN,10));
	marginsButton.addActionListener(this);
	gb.setConstraints(marginsButton,gc);
	chartPanel.add(marginsButton);

	gc.fill=GridBagConstraints.BOTH;
	gc.gridwidth=1;
	chartTitleButton=new JButton("Chart Title");
	chartTitleButton.setFont(new Font("SansSerif",Font.PLAIN,10));
	chartTitleButton.addActionListener(this);
	gb.setConstraints(chartTitleButton,gc);
	chartPanel.add(chartTitleButton);

	valuesTitleButton=new JButton("Values Axis Title");
	valuesTitleButton.setFont(new Font("SansSerif",Font.PLAIN,10));
	valuesTitleButton.addActionListener(this);
	gb.setConstraints(valuesTitleButton,gc);
	chartPanel.add(valuesTitleButton);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	labelsTitleButton=new JButton("Labels Axis Title");
	labelsTitleButton.setFont(new Font("SansSerif",Font.PLAIN,10));
	labelsTitleButton.addActionListener(this);
	gb.setConstraints(labelsTitleButton,gc);
	chartPanel.add(labelsTitleButton);
	
	gc.gridwidth=1;
	dragGraph=new JCheckBox("Enable legend and chart drag");
	dragGraph.setFont(new Font("SansSerif",Font.PLAIN,10));
	dragGraph.addActionListener(this);
	gb.setConstraints(dragGraph,gc);
	chartPanel.add(dragGraph);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	showValuesOnMarks=new JCheckBox("Show values on marks");
	showValuesOnMarks.setFont(new Font("SansSerif",Font.PLAIN,10));
	showValuesOnMarks.addActionListener(this);
	gb.setConstraints(showValuesOnMarks,gc);
	chartPanel.add(showValuesOnMarks);

	
    }

    private void createAxisPanel() {
	axisPanel=new JPanel(new GridLayout(2,1));

	GridBagLayout gb=new GridBagLayout();
	GridBagConstraints gc=new GridBagConstraints();
	gc.fill=GridBagConstraints.BOTH;
	gc.weightx=1.0;
	gc.anchor=GridBagConstraints.WEST;
	
	JPanel xAxisPanel=new JPanel();
	xAxisPanel.setBorder(BorderFactory.createTitledBorder("X Axis"));
	xAxisPanel.setLayout(gb);
	
	JPanel yAxisPanel=new JPanel();
	yAxisPanel.setBorder(BorderFactory.createTitledBorder("Y Axis"));
	yAxisPanel.setLayout(gb);


	// define ActionListener so para os eixos
	AxisActionListener axisListener=new AxisActionListener();


	// cria componentes que definem propriedades do eixo x
	JLabel xAxisFontNameLabel=new JLabel("Font name");
	xAxisFontNameLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	xAxisFontName=new JComboBox();
	xAxisFontName.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontNames(xAxisFontName);
	xAxisFontName.addActionListener(axisListener);
	
	JLabel xAxisFontSizeLabel=new JLabel("Font size");
	xAxisFontSizeLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	xAxisFontSize=new JComboBox();
	xAxisFontSize.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontSizes(xAxisFontSize);
	xAxisFontSize.addActionListener(axisListener);

	JLabel xAxisFontStyleLabel=new JLabel("Font style");
	xAxisFontStyleLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	xAxisFontStyle=new JComboBox();
	xAxisFontStyle.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontStyles(xAxisFontStyle);
	xAxisFontStyle.addActionListener(axisListener);

	JLabel xAxisColorLabel=new JLabel("Color");
	xAxisColorLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	xAxisColor=new JComboBox(getComboData());
	xAxisColor.setSelectedIndex(1);  // black
	xAxisColor.setFont(new Font("SansSerif",Font.PLAIN,10));
	xAxisColor.setRenderer(new ColorRenderer());
	xAxisColor.addActionListener(axisListener);
	
	JLabel xAxis3DColorLabel=new JLabel("3DColor");
	xAxis3DColorLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	
	xAxis3DColor=new JComboBox(getComboData());
	xAxis3DColor.setSelectedIndex(9); // lightGray
	xAxis3DColor.setFont(new Font("SansSerif",Font.PLAIN,10));
	xAxis3DColor.setRenderer(new ColorRenderer());
	xAxis3DColor.addActionListener(axisListener);
	
	// insere componentes em xAxisPanel
	gb.setConstraints(xAxisFontNameLabel,gc);
	gb.setConstraints(xAxisFontSizeLabel,gc);
	gb.setConstraints(xAxisColorLabel,gc);
	gb.setConstraints(xAxisFontName,gc);
	gb.setConstraints(xAxisFontSize,gc);
	gb.setConstraints(xAxisColor,gc);
	gb.setConstraints(xAxis3DColor,gc);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(xAxisFontStyleLabel,gc);
	gb.setConstraints(xAxisFontStyle,gc);
	gb.setConstraints(xAxis3DColorLabel,gc);
		

	xAxisPanel.add(xAxisFontNameLabel);
	xAxisPanel.add(xAxisFontSizeLabel);
	xAxisPanel.add(xAxisFontStyleLabel);
	xAxisPanel.add(xAxisFontName);
	xAxisPanel.add(xAxisFontSize);
	xAxisPanel.add(xAxisFontStyle);
	xAxisPanel.add(xAxisColorLabel);
	xAxisPanel.add(xAxis3DColorLabel);
	xAxisPanel.add(xAxisColor);
	xAxisPanel.add(xAxis3DColor);
	


	// cria componentes que definem propriedades do eixo y
	
	JLabel yAxisFontNameLabel=new JLabel("Font name");
	yAxisFontNameLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	yAxisFontName=new JComboBox();
	yAxisFontName.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontNames(yAxisFontName);
	yAxisFontName.addActionListener(axisListener);
	
	
	JLabel yAxisFontSizeLabel=new JLabel("Font size");
	yAxisFontSizeLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	
	yAxisFontSize=new JComboBox();
	yAxisFontSize.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontSizes(yAxisFontSize);
	yAxisFontSize.addActionListener(axisListener);
	
	JLabel yAxisFontStyleLabel=new JLabel("Font style");
	yAxisFontStyleLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	yAxisFontStyle=new JComboBox();
	yAxisFontStyle.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontStyles(yAxisFontStyle);
	yAxisFontStyle.addActionListener(axisListener);

	JLabel yAxisColorLabel=new JLabel("Color");
	yAxisColorLabel.setFont(new Font("SansSerif",Font.PLAIN,10));	
	
	yAxisColor=new JComboBox(getComboData());
	yAxisColor.setSelectedIndex(1);   // black
	yAxisColor.setFont(new Font("SansSerif",Font.PLAIN,10));
	yAxisColor.setRenderer(new ColorRenderer());
	yAxisColor.addActionListener(axisListener);
	
	JLabel yAxis3DColorLabel=new JLabel("3DColor");
	yAxis3DColorLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	yAxis3DColor=new JComboBox(getComboData());
	yAxis3DColor.setSelectedIndex(9); // lightGray
	yAxis3DColor.setFont(new Font("SansSerif",Font.PLAIN,10));
	yAxis3DColor.setRenderer(new ColorRenderer());
	yAxis3DColor.addActionListener(axisListener);

	// insere componentes em yAxisPanel
	gc.gridwidth=1;
	gb.setConstraints(yAxisFontNameLabel,gc);
	gb.setConstraints(yAxisFontSizeLabel,gc);
	gb.setConstraints(yAxisColorLabel,gc);
	gb.setConstraints(yAxisFontName,gc);
	gb.setConstraints(yAxisFontSize,gc);
	gb.setConstraints(yAxisColor,gc);
	gb.setConstraints(yAxis3DColor,gc);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(yAxisFontStyleLabel,gc);
	gb.setConstraints(yAxisFontStyle,gc);
	gb.setConstraints(yAxis3DColorLabel,gc);
		

	yAxisPanel.add(yAxisFontNameLabel);
	yAxisPanel.add(yAxisFontSizeLabel);
	yAxisPanel.add(yAxisFontStyleLabel);
	yAxisPanel.add(yAxisFontName);
	yAxisPanel.add(yAxisFontSize);
	yAxisPanel.add(yAxisFontStyle);
	yAxisPanel.add(yAxisColorLabel);
	yAxisPanel.add(yAxis3DColorLabel);
	yAxisPanel.add(yAxisColor);
	yAxisPanel.add(yAxis3DColor);



	axisPanel.add("North",xAxisPanel);
	axisPanel.add("South",yAxisPanel);
	
 
    }

    class ToolTipActionListener implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    if (evt.getSource()==toolTipFontName || evt.getSource()==toolTipFontSize || 
		evt.getSource()==toolTipFontStyle) {

		String fontName=(String)toolTipFontName.getSelectedItem();
		int fontStyle=toolTipFontStyle.getSelectedIndex();
		int fontSize=Integer.valueOf((String)toolTipFontSize.getSelectedItem()).intValue();
		Font f=new Font(fontName,fontStyle,fontSize);
		graph.getToolTip().setFont(f);
	    }
	    else if (evt.getSource()==toolTipForeground) {
		Object[] obj=(Object[])toolTipForeground.getSelectedItem();
		Color color=(Color)obj[0];
		graph.getToolTip().setForeground(color);
	    }
	    else if (evt.getSource()==toolTipBackground) {
		Object[] obj=(Object[])toolTipBackground.getSelectedItem();
		Color color=(Color)obj[0];
		graph.getToolTip().setBackground(color);
	    }
		
		
	}
    }


    class AxisActionListener implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    Object source=evt.getSource();
	    if (source==xAxisFontName || source==xAxisFontSize || source==xAxisFontStyle) {
		Font f=getAxisFont(XAXIS);
		graph.getXAxis().setFont(f);
	    }
	    else if (source==xAxisColor) {
		graph.getXAxis().setColor(getAxisColor(XAXIS));
	    }
	    else if (evt.getSource()==xAxis3DColor) {
		graph.getXAxis().setFill3DColor(get3DAxisColor(XAXIS));
	    }
	    
	    else if (source==yAxisFontName || source==yAxisFontSize || source==yAxisFontStyle) {
		Font f=getAxisFont(YAXIS);
		graph.getYAxis().setFont(f);
	    }
	    else if (source==yAxisColor) {
		graph.getYAxis().setColor(getAxisColor(YAXIS));
	    }
	    else if (source==yAxis3DColor) {
		graph.getYAxis().setFill3DColor(get3DAxisColor(YAXIS));
	    }

	    graph.refresh();
	}

    }
    
    private Font getAxisFont(int axis) {
	String fontName=null;
	int fontSize=0;
	int fontStyle=0;
	if (axis==XAXIS) {
	    fontName=(String)xAxisFontName.getSelectedItem();
	    fontSize=Integer.valueOf((String)xAxisFontSize.getSelectedItem()).intValue();
	    fontStyle=xAxisFontStyle.getSelectedIndex();
	}
	else {
	    fontName=(String)yAxisFontName.getSelectedItem();
	    fontSize=Integer.valueOf((String)yAxisFontSize.getSelectedItem()).intValue();
	    fontStyle=yAxisFontStyle.getSelectedIndex();
	}	    
	
	Font f=new Font(fontName,fontStyle,fontSize);
	
	return f;
    }

    private Color getAxisColor(int axis) {
	Color color=null;
	if (axis==XAXIS) {
	    Object[] obj=(Object[])xAxisColor.getSelectedItem();
	    color=(Color)obj[0];
	}
	else {
	    Object[] obj=(Object[])yAxisColor.getSelectedItem();
	    color=(Color)obj[0];
	}   
	return color;
    }
    
    private Color get3DAxisColor(int axis) {
	Color color=null;
	if (axis==XAXIS) {
	    Object[] obj=(Object[])xAxis3DColor.getSelectedItem();
	    color=(Color)obj[0];
	}
	else {
	    Object[] obj=(Object[])yAxis3DColor.getSelectedItem();
	    color=(Color)obj[0];
	}   
	return color;
    }
	
    

    private void defineFontNames(JComboBox axis) {
	axis.addItem("Serif");
	axis.addItem("SansSerif");
	axis.addItem("Monospaced");
	axis.addItem("Dialog");
	axis.addItem("DialogInput");  
	axis.setSelectedIndex(1);
    }

    private void defineFontSizes(JComboBox axis) {
	axis.addItem("8");
	axis.addItem("10");
	axis.addItem("12");
	axis.addItem("14");
	axis.addItem("16");
	axis.addItem("18");
	axis.addItem("20");
	axis.setSelectedIndex(1);  
    }


    private void defineFontStyles(JComboBox axis) {
	axis.addItem("Plain");
	axis.addItem("Bold");
	axis.addItem("Plain && Italic");
	axis.addItem("Bold && Italic");
	axis.setSelectedIndex(1);
    }

    private void createLegendPanel() {
	    
	legendPanel=new JPanel();
	GridBagLayout gb=new GridBagLayout();
	GridBagConstraints gc=new GridBagConstraints();
	gc.fill=GridBagConstraints.BOTH;
	gc.weightx=1.0;
	gc.weighty=1.0;
	gc.anchor=GridBagConstraints.WEST;
	legendPanel.setLayout(gb);
	
	showLegend=new JCheckBox("Show Legend");
	showLegend.setSelected(true);
	showLegend.setFont(new Font("SansSerif",Font.PLAIN,10));
	showLegend.addActionListener(this);
	gb.setConstraints(showLegend,gc);
	legendPanel.add(showLegend);

	drawLegendBackground=new JCheckBox("Paint background and border");
	drawLegendBackground.setSelected(true);
	drawLegendBackground.setFont(new Font("SansSerif",Font.PLAIN,10));
	drawLegendBackground.addActionListener(this);
	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(drawLegendBackground,gc);
	legendPanel.add(drawLegendBackground);

	gc.weighty=0.0;
	gc.weighty=0.0;
	gc.fill=GridBagConstraints.NONE;

	JLabel legendForegroundLabel=new JLabel("Foreground color");
	legendForegroundLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gc.gridwidth=1;
	gb.setConstraints(legendForegroundLabel,gc);
	legendPanel.add(legendForegroundLabel);

	JLabel legendBackgroundLabel=new JLabel("Background color");
	legendBackgroundLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(legendBackgroundLabel,gc);
	legendPanel.add(legendBackgroundLabel);
	legendPanel.add(legendBackgroundLabel);

	legendForeground=new JComboBox(getComboData());
	legendForeground.setSelectedIndex(1);
	legendForeground.setRenderer(new ColorRenderer());
	legendForeground.setFont(new Font("SansSerif",Font.PLAIN,10));
	legendForeground.addActionListener(this);
	gc.gridwidth=1;
	
	gb.setConstraints(legendForeground,gc);
	legendPanel.add(legendForeground);

	legendBackground=new JComboBox(getComboData());
	legendBackground.setRenderer(new ColorRenderer());
	legendBackground.setFont(new Font("SansSerif",Font.PLAIN,10));
	legendBackground.addActionListener(this);	
	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(legendBackground,gc);
	legendPanel.add(legendBackground);

	JPanel posPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));
	posPanel.setBorder(BorderFactory.createTitledBorder("Position"));

	legendLeft=new JRadioButton("Left");
	legendLeft.setFont(new Font("SansSerif",Font.PLAIN,10));
	legendLeft.addChangeListener(this);

	legendRight=new JRadioButton("Right");
	legendRight.setFont(new Font("SansSerif",Font.PLAIN,10));
	legendRight.addChangeListener(this);

	legendBottom=new JRadioButton("Bottom");
	legendBottom.setFont(new Font("SansSerif",Font.PLAIN,10));
	legendBottom.addChangeListener(this);
	legendBottom.setSelected(true);

	bgLegendPosition=new ButtonGroup();
	bgLegendPosition.add(legendLeft);
	bgLegendPosition.add(legendRight);
	bgLegendPosition.add(legendBottom);

	posPanel.add(legendLeft);
	posPanel.add(legendRight);
	posPanel.add(legendBottom);

	gc.weightx=1.0;
	gc.weighty=1.0;
	gc.fill=GridBagConstraints.BOTH;
	gb.setConstraints(posPanel,gc);
	legendPanel.add(posPanel);


	JPanel orientationPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));
	orientationPanel.setBorder(BorderFactory.createTitledBorder("Orientation"));
	
	legendVertical=new JRadioButton("Vertical");
	legendVertical.setFont(new Font("SansSerif",Font.PLAIN,10));
	legendVertical.setSelected(true);
	legendVertical.addChangeListener(this);

	legendHorizontal=new JRadioButton("Horizontal");
	legendHorizontal.setFont(new Font("SansSerif",Font.PLAIN,10));
	legendHorizontal.addChangeListener(this);

        bgLegendOrientation=new ButtonGroup();
	bgLegendOrientation.add(legendVertical);
	bgLegendOrientation.add(legendHorizontal);

	orientationPanel.add(legendVertical);
	orientationPanel.add(legendHorizontal);

	gb.setConstraints(orientationPanel,gc);
	legendPanel.add(orientationPanel);

    }


    private void createGridPanel() {

	gridPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));


	JLabel gridColorLabel=new JLabel("Grid Color:");
	gridColorLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	gridColor=new JComboBox(getComboData());
	gridColor.setSelectedIndex(3);
	gridColor.setRenderer(new ColorRenderer());
	gridColor.setFont(new Font("SansSerif",Font.PLAIN,10));
	gridColor.addActionListener(this);


	grid=new JCheckBox("Enable grid");
	grid.setSelected(true);
	grid.setFont(new Font("SansSerif",Font.PLAIN,10));
	grid.addActionListener(this);

	oppositeLines=new JCheckBox("Enable crossed lines");
	oppositeLines.setFont(new Font("SansSerif",Font.PLAIN,10));
	oppositeLines.addActionListener(this);

	gridPanel.add(gridColorLabel);
	gridPanel.add(gridColor);
	gridPanel.add(grid);
	gridPanel.add(oppositeLines);
    }

    public void createToolTipPanel() {
	toolTipPanel=new JPanel();

	GridBagLayout gb=new GridBagLayout();
	
	toolTipPanel.setLayout(gb);
	GridBagConstraints gc=new GridBagConstraints();
	
	gc.insets=new Insets(2,2,2,2);
	gc.fill=GridBagConstraints.BOTH;
	gc.anchor=GridBagConstraints.NORTHWEST;
	gc.weightx=1.0;

	// define ActionListener so para o tooltip
	ToolTipActionListener toolTipListener =new ToolTipActionListener();

	valueToolTip=new JCheckBox("Enable ToolTip");
	valueToolTip.setFont(new Font("SansSerif",Font.PLAIN,10));
	valueToolTip.addActionListener(this);
	gb.setConstraints(valueToolTip,gc);
	
	toolTipPanel.add(valueToolTip);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	opaqueToolTip=new JCheckBox("Opaque");
	opaqueToolTip.setFont(new Font("SansSerif",Font.PLAIN,10));
	opaqueToolTip.setSelected(true);
	opaqueToolTip.addActionListener(this);
	gb.setConstraints(opaqueToolTip,gc);
	toolTipPanel.add(opaqueToolTip);


	gc.gridwidth=GridBagConstraints.REMAINDER;
	JLabel toolTipTextLabel=new JLabel("ToolTip text");
	toolTipTextLabel.setFont(new Font("SansSerif",Font.PLAIN,10));

	gb.setConstraints(toolTipTextLabel,gc);
	toolTipPanel.add(toolTipTextLabel);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	gc.weightx=0.0;
	gc.fill=GridBagConstraints.NONE;
	toolTipText=new JTextField(20);
	toolTipText.setText("Value:");
	toolTipText.addCaretListener(this);
	gb.setConstraints(toolTipText,gc);
	toolTipPanel.add(toolTipText);

	gc.gridwidth=1;
	gc.weightx=1.0;
	gc.fill=GridBagConstraints.BOTH;

	JLabel toolTipFontNameLabel=new JLabel("Font name");
	toolTipFontNameLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gb.setConstraints(toolTipFontNameLabel,gc);
	toolTipPanel.add(toolTipFontNameLabel);

	JLabel toolTipFontSizeLabel=new JLabel("Font size");
	toolTipFontSizeLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gb.setConstraints(toolTipFontSizeLabel,gc);
	toolTipPanel.add(toolTipFontSizeLabel);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	JLabel toolTipFontStyleLabel=new JLabel("Font style");
	toolTipFontStyleLabel.setFont(new Font("SansSerif",Font.PLAIN,10));	
	gb.setConstraints(toolTipFontStyleLabel,gc);
	toolTipPanel.add(toolTipFontStyleLabel);

	gc.gridwidth=1;
	
	toolTipFontName=new JComboBox();
	toolTipFontName.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontNames(toolTipFontName);
	toolTipFontName.addActionListener(toolTipListener);
	gb.setConstraints(toolTipFontName,gc);
	toolTipPanel.add(toolTipFontName);
		
	toolTipFontSize=new JComboBox();
	toolTipFontSize.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontSizes(toolTipFontSize);
	toolTipFontSize.setSelectedIndex(2); // 12
	toolTipFontSize.addActionListener(toolTipListener);
	gb.setConstraints(toolTipFontSize,gc);
	toolTipPanel.add(toolTipFontSize);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	toolTipFontStyle=new JComboBox();
	toolTipFontStyle.setFont(new Font("SansSerif",Font.PLAIN,10));
	defineFontStyles(toolTipFontStyle);
	toolTipFontStyle.setSelectedIndex(0);
	toolTipFontStyle.addActionListener(toolTipListener);
	gb.setConstraints(toolTipFontStyle,gc);
	toolTipPanel.add(toolTipFontStyle);

	gc.gridwidth=1;
	JLabel foregroundLabel=new JLabel("Foreground color");
	foregroundLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gb.setConstraints(foregroundLabel,gc);
	toolTipPanel.add(foregroundLabel);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	JLabel backgroundLabel=new JLabel("Background color");
	backgroundLabel.setFont(new Font("SansSerif",Font.PLAIN,10));
	gb.setConstraints(backgroundLabel,gc);
	toolTipPanel.add(backgroundLabel);
	

	gc.gridwidth=1;
	gc.fill=GridBagConstraints.NONE;
	gc.weightx=0;

	
	toolTipForeground=new JComboBox(getComboData());
	toolTipForeground.setSelectedIndex(1);
	toolTipForeground.setRenderer(new ColorRenderer());
	toolTipForeground.setFont(new Font("SansSerif",Font.PLAIN,10));
	toolTipForeground.addActionListener(toolTipListener);
	gb.setConstraints(toolTipForeground,gc);
	toolTipPanel.add(toolTipForeground);

	gc.gridwidth=GridBagConstraints.REMAINDER;

	toolTipBackground=new JComboBox(getComboData());
	toolTipBackground.setSelectedIndex(4);
	toolTipBackground.setRenderer(new ColorRenderer());
	toolTipBackground.setFont(new Font("SansSerif",Font.PLAIN,10));
	toolTipBackground.addActionListener(toolTipListener);
	gb.setConstraints(toolTipBackground,gc);
	toolTipPanel.add(toolTipBackground);


    }	
	


    public void caretUpdate(CaretEvent evt) {
	graph.setToolTipLabel(toolTipText.getText());
    }
	

    public void stateChanged(ChangeEvent evt) {
	if (evt.getSource()==depth) {
	    graph.setVDepth(depth.getValue());
	    graph.setHDepth(depth.getValue());
	}
	// pode ser que a legenda tenha sido movida com o mouse. Aqui, se for selecionado o 
	// tab da legenda reajusta o botao selecionado
	else if (evt.getSource()==jtp && jtp.getSelectedIndex()==1) {
	    int position=graph.getLegend().getPosition();
	    if (position==Legend.LEFT)
		legendLeft.setSelected(true);
	    else if (position==Legend.RIGHT)
	         legendRight.setSelected(true);
	    else if (position==Legend.BOTTOM)
		legendBottom.setSelected(true);
	}
	else if (evt.getSource()==legendLeft)
	    graph.getLegend().setPosition(Legend.LEFT);
	else if (evt.getSource()==legendRight)
	    graph.getLegend().setPosition(Legend.RIGHT);
	else if (evt.getSource()==legendBottom)
	    graph.getLegend().setPosition(Legend.BOTTOM);
	else if (evt.getSource()==legendVertical)
	    graph.getLegend().setOrientation(Legend.VERTICAL);
	else if (evt.getSource()==legendHorizontal)
	    graph.getLegend().setOrientation(Legend.HORIZONTAL);
	graph.refresh();
    }
    
    public void actionPerformed(ActionEvent evt) {
	if (evt.getSource()==gradButton) {
	    if (gd==null)
		gd=new GradientDlg(this);
	    else
		gd.setVisible(true);
	   
	}
	else if (evt.getSource()==chartTitleButton) {
	    if (td1==null) 
		td1=new TitleDialog(this,"Chart Title");

	    td1.setVisible(true);
	}
	else if (evt.getSource()==valuesTitleButton) {
	   if (td2==null)
		td2=new TitleDialog(this,"Values Axis Title");
	   
	   td2.setVisible(true);
	}    
	else if (evt.getSource()==labelsTitleButton) {
	   if (td3==null)
		td3=new TitleDialog(this,"Labels Axis Title");
	   
	   td3.setVisible(true);
	}   

	else if (evt.getSource()==marginsButton) {
	    if (md==null)
		md=new MarginsDialog(this);
	    md.setVisible(true);
	}

	else if (evt.getSource()==dragGraph) {
	    graph.setDraggingEnabled(dragGraph.isSelected());
	    if (dragGraph.isSelected()) {
		String[] text={"Double-click  over  chart  to alternate",
			       "between scale adjustment and  dragging"};
		JOptionPane.showMessageDialog(null,text,"Information",JOptionPane.INFORMATION_MESSAGE);
	    }
	}

	else if (evt.getSource()==showValuesOnMarks) {
	    Vector series=graph.getSeries();
	    for (int counter=0;counter<series.size();counter++) {
		AbstractSerie as=(AbstractSerie)series.elementAt(counter);
		if (as instanceof GraphSerie) 
		    ((GraphSerie)as).setMarkLegendEnabled(showValuesOnMarks.isSelected());
	    }
	}

	//else if (evt.getSource()==showLegend) {
	//   graph.setLegendEnabled(showLegend.isSelected());
	//}

	else if (evt.getSource()==drawLegendBackground) {
	    graph.getLegend().setOpacityEnabled(drawLegendBackground.isSelected());
	}
	else if (evt.getSource()==legendBackground) {
	    Color color=getColor(legendBackground);
	    graph.getLegend().setBackground(color);
	}
	else if (evt.getSource()==legendForeground) {
	    Color color=getColor(legendForeground);
	    graph.getLegend().setForeground(color);
	}
	
	else if (evt.getSource()==_3D) {
	    graph.set3DEnabled(_3D.isSelected());
	    depth.setEnabled(_3D.isSelected());
	    
	}
	else if (evt.getSource()==flip) {
	    boolean isFlipped=flip.isSelected();
	    graph.setHorizontalGraphEnabled(isFlipped);
	    
	}
	else if (evt.getSource()==valueToolTip) {
	    graph.setToolTipEnabled(valueToolTip.isSelected());
	}
	else if (evt.getSource()==opaqueToolTip) {
	    graph.getToolTip().setOpacityEnabled(opaqueToolTip.isSelected());
	}


	else if (evt.getSource()==valuesOnAxis)
	    graph.setShowValuesEnabled(valuesOnAxis.isSelected());
	
	else if (evt.getSource()==move3DSeries)
	    graph.set3DSeriesInLineEnabled(move3DSeries.isSelected());
	
	else if (evt.getSource()==gridColor) {
	    Color color=getColor(gridColor);
	    graph.getGrid().setColor(color);
	}
	else if (evt.getSource()==grid) 
	    graph.setGridEnabled(grid.isSelected());
	
	else if (evt.getSource()==oppositeLines)
	    graph.getGrid().setCrossedLinesEnabled(oppositeLines.isSelected());
	
	else if (evt.getSource()==comboSeries) {
	    graph.removeAllSeries();
	    _3D.setEnabled(true);
	    switch (comboSeries.getSelectedIndex()) {
	    case 0 : {
		graph.addSerie(demo.sb1);
		graph.addSerie(demo.sb2);
		graph.addSerie(demo.bar3);

		break;
	    }
	    case 1 : { 
		graph.addSerie(demo.line1);
		break;
	    }
	    case 2 : {
		graph.addSerie(demo.area1);
		break;
	    }
	    case 3 : {
		graph.addSerie(demo.point1);
		break;
	    }
	    case 4 : {
		graph.addSerie(demo.bar1);
		break;
	    }
	    case 5 : {
		graph.set3DEnabled(false);
		_3D.setSelected(false);
		_3D.setEnabled(false);
		depth.setEnabled(false);
		graph.addSerie(demo.imageSerie);
		break;
	    }
	    case 6 : {
		graph.addSerie(demo.line1);
		graph.addSerie(demo.line2);
		
		break;
	    }
	    case 7 : {
		graph.addSerie(demo.area1);
		graph.addSerie(demo.area2);
		break;
	    }
	    case 8 : {
		graph.addSerie(demo.point2);
		graph.addSerie(demo.point3);
		break;
	    }
	    case 9 : {
		graph.addSerie(demo.bar1);
		graph.addSerie(demo.bar2);
		break;
	    }
	    case 10 : {
		graph.addSerie(demo.sb1);
		graph.addSerie(demo.sb2);
		break;
	    }
	   
	    
	    }
	    			    
	}

	// When an ImageSerie is selected, legend is disabled. So, it is necessary to 
	// restore legend property here.
	graph.setLegendEnabled(showLegend.isSelected());
	graph.repaint();
    }

    private Object[] getComboData() {
	Object[] obj=new Object[] {
	    new Object[]{Color.white,"white"},
	    new Object[]{Color.black,"black"},
	    new Object[]{Color.red,"red"},
	    new Object[]{Color.blue,"blue"},
    	    new Object[]{Color.yellow,"yellow"},
	    new Object[]{Color.magenta,"magenta"},
	    new Object[]{Color.orange,"orange"},
	    new Object[]{Color.gray,"gray"},
	    new Object[]{Color.green,"green"},
	    new Object[]{Color.lightGray,"lightGray"},
	    new Object[]{Color.cyan,"cyan"},
            new Object[]{Color.pink,"pink"}};
	return obj;
    }

    private Color getColor(JComboBox combo) {
	Object[] obj=(Object[])combo.getSelectedItem();
	Color color=(Color)obj[0];
	return color;
    } 
}











