import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * ColorRenderer.java
 *
 *
 * Created: Sat Nov 20 15:53:37 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */

public class ColorRenderer extends JLabel implements ListCellRenderer {
    private static ColorIcon icon=new ColorIcon();
    private Border
	redBorder=BorderFactory.createLineBorder(Color.red,2),
	emptyBorder=BorderFactory.createEmptyBorder(2,2,2,2);
    
    public Component getListCellRendererComponent(JList list, Object value,int index,
						  boolean isSelected,boolean cellHasFocus) {
	Object[] array=(Object[])value;
	icon.setColor((Color)array[0]);
	setIcon(icon);
	setText((String)array[1]);
	
	if (isSelected)
	    setBorder(redBorder);
	else
	    setBorder(emptyBorder);
	
	return this;
    }
}
