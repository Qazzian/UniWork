import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.Observable;
import java.util.Observer;
import com.jinsight.jetchart.*;

/**
 * SaveImageDialog.java
 *
 *
 * Created: Sun Oct 17 21:09:46 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */

public class SaveImageDialog extends JDialog implements Observer,WindowListener {
    JProgressBar jp;
    Graph graph;
    File f;
    boolean firstUpdate=true;
    public SaveImageDialog(Graph graph,File f) {
	super(null,true);
	setTitle("Image saving");
	this.graph=graph;
	this.f=f;
	addWindowListener(this);
	
	graph.addImageEncodingObserver(this);
	jp=new JProgressBar();
	getContentPane().add("South",jp);
	JLabel label=new JLabel("Wait. Saving image..."); 
	getContentPane().add("Center",label);
	pack();
	setSize(getSize().width+20,getSize().height+20);
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);
	SaveThread st=new SaveThread();
	st.setPriority(2);
	st.start();
	setVisible(true);
    }

    public void windowClosing(WindowEvent evt) {
	if (graph!=null)
	    graph.stopEncoding();
    }
    public void windowClosed(WindowEvent evt) {}
    public void windowActivated(WindowEvent evt) {}
    public void windowDeactivated(WindowEvent evt) {}
    public void windowOpened(WindowEvent evt) {}
    public void windowIconified(WindowEvent evt) {}
    public void windowDeiconified(WindowEvent evt) {}
    

   
    public void update(Observable obs, Object obj) {
	int value=((Integer)obj).intValue();

	// o codificador da imagem, na primeira vez que notifica o observer, envia o total de pixeis
	// que vao ser gravados no arquivo. Nas vezes subsequentes, envia a quantidade de pixeis
	// ja gravadas em arquivo.
	if (firstUpdate) {
	    jp.setMaximum(value);
	    firstUpdate=false;
	}
	else
	    jp.setValue(value);

    }

    class SaveThread extends Thread {
	public void run() {
	    try {
		// inicia codificacao da imagem. O primeiro parametro eh um objeto File
		// contendo o nome do arquivo a ser salvo. O segundo parametro eh a
		// escala percentual da imagem a ser salva.
		graph.gifEncode(f,100);
		//JOptionPane.showMessageDialog(null,"File succesfully saved",
		//		      "Information",JOptionPane.INFORMATION_MESSAGE);
		dispose();
	       
	    }
	    catch (IOException e) {
		String msg=e.getMessage();
		if (msg.equals(Graph.ENCODING_ABORTED))
		    JOptionPane.showMessageDialog(null,"Image encoding aborted","Warning",
						  JOptionPane.WARNING_MESSAGE);
		else
		    e.printStackTrace();
	    }
	}
    }
}
		 
