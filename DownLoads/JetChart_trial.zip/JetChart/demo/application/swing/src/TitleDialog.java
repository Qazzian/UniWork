import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import com.jinsight.jetchart.*;

/**
 * TitleDialog.java
 *
 *
 * Created: Sat Nov 20 15:52:20 1999
 *
 * @author Andre de Lima Soares 
 * @version 1.0
 */

public class TitleDialog extends JDialog {
    TitlePanel tp;
    Graph graph;
    SwingConsole console;
    String dialogTitle;
    public TitleDialog(SwingConsole console,String title)  {
	super(null,false);
	setTitle(title);
	dialogTitle=title;
	this.graph=console.graph;
	this.console=console;
        tp=new TitlePanel();

	Container ct=getContentPane();
	ct.add("Center",tp);

	pack();
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);
	
    }

    class TitlePanel extends JPanel implements ActionListener,CaretListener {
	JCheckBox showTitle,showBorder;
	JTextField title;
	JComboBox background,borderColor,font,size,style,color;
	Object[] comboData;
	
	TitlePanel() {
	    GridBagLayout gb=new GridBagLayout();
	    GridBagConstraints gc=new GridBagConstraints();
	    gc.insets=new Insets(2,2,2,2);

	    gc.fill=GridBagConstraints.BOTH;
	    gc.weightx=1.0;
	    gc.weighty=1.0;

	    this.setLayout(gb);

	    showTitle=new JCheckBox("Show title");
	    showTitle.addActionListener(this);
	    defineFont(showTitle);

	    comboData=setComboData();

	    JLabel backgroundLabel=new JLabel("Background Color");
	    defineFont(backgroundLabel);

	    background=new JComboBox(comboData);
	    background.addActionListener(this);
	    defineFont(background);
	    background.setRenderer(new ColorRenderer());

	    JLabel textLabel=new JLabel("Title");
	    defineFont(textLabel);

	    title=new JTextField(20);
	    title.setText(dialogTitle);
	    title.addCaretListener(this);
	    defineFont(title);

	    JLabel fontLabel=new JLabel("Font");
	    defineFont(fontLabel);

	    font=new JComboBox();
	    font.addActionListener(this);
	    font.addItem("Serif");
	    font.addItem("SansSerif");
	    font.addItem("Monospaced");
	    font.addItem("Dialog");
	    font.addItem("DialogInput");

	    font.setSelectedIndex(1);  // forca SansSerif-default
	    defineFont(font);

	    JLabel fontSizeLabel=new JLabel("Font size");
	    defineFont(fontSizeLabel);
	    size=new JComboBox();
	    size.addActionListener(this);
	    size.addItem("8");
	    size.addItem("10");
	    size.addItem("12");
	    size.addItem("14");
	    size.addItem("16");
	    size.addItem("18");
	    size.addItem("20");
	    size.setSelectedIndex(1);  // forca tamanho 10 - default
	    defineFont(size);

	    JLabel fontStyleLabel=new JLabel("Font style");
	    defineFont(fontStyleLabel);
	    style=new JComboBox();
	    style.addActionListener(this);
	    style.addItem("Plain");
	    style.addItem("Bold");
	    style.addItem("Plain && Italic");
	    style.addItem("Bold && Italic");

	    style.setSelectedIndex(1); // forca bold - default

	    defineFont(style);

	    
	    JLabel fontColorLabel=new JLabel("Font color");
	    defineFont(fontColorLabel);
	    color=new JComboBox(comboData);
	    color.setSelectedIndex(1); // forca cor preta para o titulo
	    color.addActionListener(this);
	    color.setRenderer(new ColorRenderer());
	    defineFont(color);

	    gc.gridwidth=GridBagConstraints.REMAINDER;
	    gb.setConstraints(showTitle,gc);
	    
	    
	    gb.setConstraints(backgroundLabel,gc);
	    gb.setConstraints(background,gc);
	    gc.gridwidth=1;
	    gb.setConstraints(textLabel,gc);

	    gb.setConstraints(title,gc);

	    gb.setConstraints(fontSizeLabel,gc);
	    gb.setConstraints(size,gc);

	    gc.gridwidth=GridBagConstraints.REMAINDER;
	    gc.weightx=0;

	    if (dialogTitle.equals("Chart Title"))
		gb.setConstraints(showTitle,gc);

	    gb.setConstraints(fontLabel,gc);
	    gb.setConstraints(font,gc);
	    gb.setConstraints(fontStyleLabel,gc);
	    gb.setConstraints(style,gc);
	    gb.setConstraints(fontColorLabel,gc);
	    gb.setConstraints(color,gc);

	    add(showTitle);

	    if (!dialogTitle.equals("Chart Title")) {
		add(backgroundLabel);
		add(background);
	    }
	    
	    add(textLabel);
	    add(fontLabel);
	    add(title);
	    add(font);
	    add(fontSizeLabel);
	    add(fontStyleLabel);
	    add(size);
	    add(style);
	    add(fontColorLabel);
	    add(color);


	    
	}


	public void actionPerformed(ActionEvent evt) {
	    if (showTitle.isSelected() && !title.getText().trim().equals("")) {
		Font font=getTitleFont();
		Color color=getTitleColor();
		Color background=getTitleBackground();

		//if (!title.getText().trim().equals("")) {
		if (TitleDialog.this==console.td1) {
		    String[] graphTitle={title.getText()};
		    graph.setTitle(graphTitle);
		    graph.setTitleFont(font);
		    graph.setTitleForeground(color);
		}
		if (TitleDialog.this==console.td2) {
		    graph.setValuesTitle(title.getText());
		    graph.setValuesTitleFont(font);
		    graph.setValuesTitleForeground(color);
		    graph.setValuesTitleBackground(getTitleBackground());
		}
		else if (TitleDialog.this==console.td3) {
		    graph.setLabelsTitle(title.getText());
		    graph.setLabelsTitleFont(font);
		    graph.setLabelsTitleForeground(color);
		    graph.setLabelsTitleBackground(getTitleBackground());
		}
	    }
	    else {
			
		if (TitleDialog.this==console.td1)
		    graph.setTitle(null);
		else if (TitleDialog.this==console.td2)
		    graph.setValuesTitle(null);
		else if (TitleDialog.this==console.td3)
		    graph.setLabelsTitle(null);
	    }

	    graph.repaint();
	    
	    
	}

	public void caretUpdate(CaretEvent evt) {
	   
	    if (showTitle.isSelected() && !title.getText().trim().equals("")) {

		Font font=getTitleFont();

		Color color=getTitleColor();
		// se a janela TitleDialog para titulo do chart for a janela atual...
		if (TitleDialog.this==console.td1) {
		    String[] graphTitle={title.getText()};
		    graph.setTitle(graphTitle);
		    graph.setTitleFont(font);
		    graph.setTitleForeground(color);
		}
				
		// se a janela Titledialog para titulo dos valores for a janela atual...
		else if (TitleDialog.this==console.td2) {
		    graph.setValuesTitle(title.getText());
		    graph.setValuesTitleFont(font);
		    graph.setValuesTitleForeground(color);
		    		    
		}
		// se a janela Titledialog para titulo dos labels for a janela atual...
		else if (TitleDialog.this==console.td3) {
		    graph.setLabelsTitle(title.getText());
		    graph.setLabelsTitleFont(font);
		    graph.setLabelsTitleForeground(color);
		}
		
	    }
	    else {
		if (TitleDialog.this==console.td1)
		    graph.setTitle(null);
		else if (TitleDialog.this==console.td2)
		    graph.setValuesTitle(null);
		else if (TitleDialog.this==console.td3)
		    graph.setLabelsTitle(null);
	    }

	    graph.repaint();

	}

	private Font getTitleFont() {
	    String fontName=(String)font.getSelectedItem();
	    int fontSize=Integer.valueOf((String)size.getSelectedItem()).intValue();
	    int fontStyle=style.getSelectedIndex();
	    Font f=new Font(fontName,fontStyle,fontSize);

	    return f;
	}
	 
	private Color getTitleColor() {
	    Object[] obj=(Object[])color.getSelectedItem();
	    Color fontColor=(Color)obj[0];
	    return fontColor;
	}

	private Color getTitleBackground() {
	    Object[] obj=(Object[])background.getSelectedItem();
	    Color titleBackgroundColor=(Color)obj[0];
	    return titleBackgroundColor;
	}

	private void defineFont(Component c) {
	    c.setFont(new Font("SansSerif",Font.PLAIN,10));
	}

	private Object[] setComboData() {
	    Object[] obj=new Object[] {
		new Object[]{Color.white,"white"},
	   	new Object[]{Color.black,"black"},
		new Object[]{Color.red,"red"},
		new Object[]{Color.blue,"blue"},
    		new Object[]{Color.yellow,"yellow"},
		new Object[]{Color.magenta,"magenta"},
		new Object[]{Color.orange,"orange"},
		new Object[]{Color.gray,"gray"},
		new Object[]{Color.green,"green"},
		new Object[]{Color.lightGray,"lightGray"},
	        new Object[]{Color.cyan,"cyan"},
		new Object[]{Color.pink,"pink"}};
	    return obj;
	}
	
    }
}



