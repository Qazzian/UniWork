import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.jinsight.jetchart.*;

/**
 * MarginsDlg.java
 *
 *
 * Created: Sun Nov 21 12:12:57 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */

public class MarginsDialog extends JDialog implements ChangeListener, WindowListener {
    JSlider top,bottom,left,right;
    Graph graph;
    public MarginsDialog(SwingConsole console) {
	super(null,true);
	setTitle("Margins");
	this.graph=console.graph;

	top=new JSlider(JSlider.VERTICAL,0,60,30);
	top.setInverted(true);
	top.setPreferredSize(new Dimension(50,80));
	top.setPaintLabels(true);
	top.setPaintTicks(true);
	top.setMajorTickSpacing(20);
	top.setMinorTickSpacing(5);
	top.addChangeListener(this);

	JPanel topPanel=new JPanel();
	topPanel.add(top);

	bottom=new JSlider(JSlider.VERTICAL,0,60,10);
	bottom.setMajorTickSpacing(20);
	bottom.setMinorTickSpacing(5);
	bottom.setPaintLabels(true);
	bottom.setPaintTicks(true);
	bottom.setPreferredSize(new Dimension(50,80));
	bottom.addChangeListener(this);
	JPanel bottomPanel=new JPanel();
	bottomPanel.add(bottom);
	

	left=new JSlider(0,60,10);
	left.setMajorTickSpacing(20);
	left.setMinorTickSpacing(5);
	left.setPaintLabels(true);
	left.setPaintTicks(true);
	left.setPreferredSize(new Dimension(80,50));
	left.addChangeListener(this);

	right=new JSlider(0,60,10);
	right.setInverted(true);
	right.setPaintLabels(true);
	right.setPaintTicks(true);
	right.setMajorTickSpacing(20);
	right.setMinorTickSpacing(5);
	right.setPreferredSize(new Dimension(80,50));
	right.addChangeListener(this);


	Container ct=getContentPane();
	ct.add("North",topPanel);
	ct.add("South",bottomPanel);
	ct.add("West",left);
	ct.add("East",right);

	addWindowListener(this);

	setSize(250,250);
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);
	
    }

    public void windowClosing(WindowEvent evt) {}
    public void windowClosed(WindowEvent evt) {}
    public void windowDeactivated(WindowEvent evt) {}
    public void windowActivated(WindowEvent evt) {
	graph.setTopMargin(top.getValue());
	graph.setBottomMargin(bottom.getValue());
	graph.setLeftMargin(left.getValue());
	graph.setRightMargin(right.getValue());
	graph.repaint();
    }
    public void windowIconified(WindowEvent evt) {}
    public void windowDeiconified(WindowEvent evt) {}
    public void windowOpened(WindowEvent evt) {}
    

  


    public void stateChanged(ChangeEvent evt) {
	if (evt.getSource()==top)
	    graph.setTopMargin(top.getValue());
	else if (evt.getSource()==bottom)
	    graph.setBottomMargin(bottom.getValue());
	else if (evt.getSource()==left)
	    graph.setLeftMargin(left.getValue());
	else if (evt.getSource()==right)
	    graph.setRightMargin(right.getValue());
	graph.repaint();
    }
}
	
    
