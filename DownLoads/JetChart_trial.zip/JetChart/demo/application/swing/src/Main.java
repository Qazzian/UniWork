import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import com.jinsight.jetchart.*;

/**
 * This is a swing demo of  all series and properties, except for the Pie Serie, which is 
 * demonstrated in the PieChart application.
 * Serie events are dispatched to registered Serie Event handlers when a
 * coordinate is clicked or dragged. A click over the serie image inside the 
 * Legend also dispatches a SerieEvent object.This class is not registered as a
 * SerieListener. To handle serie events, just implement the methods 
 * defined in the interface SerieListener. See SerieListener and SerieEvent
 * class for further information.
 */

public class Main extends JFrame implements ActionListener {
	
    Graph graph;
    SwingConsole console;
    JFileChooser chooser;
    JButton saveButton,consoleButton;

    LineSerie line1,line2;
    AreaSerie area1,area2;
    PointSerie point1,point2,point3;
    BarSerie bar1,bar2,bar3;
    StackBarSerie sb1,sb2;
    ImageSerie imageSerie;
   
    public Main() {
	setTitle("The JetChart Library - Swing Demo");
	JToolBar jb=new JToolBar();
	jb.setFont(new Font("SansSerif",Font.PLAIN,10));
	jb.setBorder(BorderFactory.createEtchedBorder());
	getContentPane().add("North",jb);
	saveButton=new JButton("Save to disk",new ImageIcon("save.gif"));
	saveButton.setFont(new Font("SansSerif",Font.PLAIN,10));
	consoleButton=new JButton("Control Panel",new ImageIcon("console.gif"));
	consoleButton.setFont(new Font("SansSerif",Font.PLAIN,10));
	saveButton.addActionListener(this);
	consoleButton.addActionListener(this);
	jb.add(saveButton);
	jb.add(consoleButton);
	
	createGraph();
	getContentPane().add("Center",graph);

	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(500,400);
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2, (d.height-getSize().height)/2);
	//setLocation(30,30);
	setVisible(true);
    }


    public void actionPerformed(ActionEvent evt) {
	if (evt.getSource()==saveButton) {
	    chooser=new JFileChooser();
	    chooser.setFileFilter(new GIFFilter());
	    int state=chooser.showSaveDialog(null);
	    if (state==JFileChooser.APPROVE_OPTION) {
		SaveImageDialog sid=new SaveImageDialog(graph,chooser.getSelectedFile());
	    }
	}
	else if (evt.getSource()==consoleButton) {
	    if (console==null)
		console=new SwingConsole(this);
	    else
		console.setVisible(true);
	    
	}
	    
    }

    private void createGraph() {
	// labels no eixo x
	String[] xLabels={"Label1","Label2","Label3","Label4"};
	
	// valores das series
	float[] yCoords1={15550,13332,22252,51113};
	float[] yCoords2={15557,26610,64412,23358};
	float[] yCoords3={20120,33253,14304,65423};

	// cria contexto grafico(chart)
	graph=new Graph(xLabels);
	//graph.setTopMargin(30);
	graph.set3DSeriesInLineEnabled(false);
	graph.set3DEnabled(true);
	graph.setGridEnabled(true);
	graph.setToolTipLabel("Value:");
	graph.getGrid().setColor(Color.blue);
	graph.setValueFormat("###,###,##0");

	graph.setSerieDraggingEnabled(true);
	line1=new LineSerie(yCoords1,"LineSerie1");
	line1.setColor(Color.green.darker());
	line1.setThickness(2);
		
	line2=new LineSerie(yCoords2,"LineSerie2");
	line2.setColor(Color.yellow);
	line2.setThickness(2);

	area1=new AreaSerie(yCoords1,"AreaSerie1");
	area1.setColor(Color.yellow);
	
	area2=new AreaSerie(yCoords2,"AreaSerie2");
	area2.setColor(Color.lightGray);


	point1=new PointSerie(yCoords1,"PointSerie1");
	point1.setColor(Color.pink);
	
	point2=new PointSerie(yCoords1,"PointSerie2");
	point2.setShape(PointSerie.CIRCLE);
	point2.setColor(Color.orange);

	point3=new PointSerie(yCoords2,"PointSerie3");
	point3.setShape(PointSerie.TRIANGLE);
	point3.setColor(Color.yellow);	
	
	// cria BarSeries
	bar1=new BarSerie(yCoords1,"BarSerie1");
	bar1.setWidth(15);
	bar1.setColor(Color.orange);
	//bar1.setShowValuesOnMarksEnabled(true);

	bar2=new BarSerie(yCoords2,"BarSerie2");
	bar2.setWidth(15);
	bar2.setColor(Color.green.darker());

	bar3=new BarSerie(yCoords3,"BarSerie3");
	bar3.setWidth(15);
	bar3.setColor(Color.green.darker());

	
	// cria StackBars
	sb1=new StackBarSerie(yCoords1,"StackBarSerie1");
	sb1.setStackBarWidth(15); // estatico e valido para todas as demais StackBarSeries
	sb1.setColor(Color.pink);
		
	sb2=new StackBarSerie(yCoords2,"StackBarSerie2");
	sb2.setColor(Color.cyan);


	// cria series de imagens
	Image img1=getToolkit().getImage("ball1.gif");
	Image img2=getToolkit().getImage("ball2.gif");
	Image img3=getToolkit().getImage("ball3.gif");
	Image img4=getToolkit().getImage("ball4.gif");
	
	Image[] images={img1,img2,img3,img4};
	imageSerie=new ImageSerie(yCoords1,images);
	imageSerie.setColor(Color.green.darker());
	

	// adiciona series
	graph.addSerie(sb1);
	graph.addSerie(sb2);
	graph.addSerie(bar3);
		

    }

    class GIFFilter extends javax.swing.filechooser.FileFilter {
	public boolean accept(File f) {
	    boolean accept=f.isDirectory();
	    if (!accept) {
		if (f.getPath().toLowerCase().endsWith("gif"))
		    accept=true;
	    }

	    return accept;
	}

	public String getDescription() {
	    return "GIF Files(*.gif)";
	}
    }

    public static void main(String[] args) {
	new Main();
    }
}



