import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

/**
 * GradientDlg.java
 *
 *
 * Created: Sat Nov 20 07:55:09 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */


public class GradientDlg extends JDialog implements ActionListener {
    JComboBox comboColor1,comboColor2;
    JRadioButton topToBottom,bottomToTop,leftToRight,rightToLeft;
    ButtonGroup bg;
    Graph graph;
    Object[] comboData;

    public GradientDlg(SwingConsole swingConsole) {
	super(null,true);
	//setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	setTitle("Gradient Colors");
	
	JPanel comboPanel=new JPanel() {
	    public Insets getInsets() {
		Insets insets=new Insets(2,2,2,2);
		return insets;
	    }
	};
	
	GridLayout gl=new GridLayout(3,2);
	comboPanel.setLayout(gl);

	this.graph=swingConsole.graph;

	comboData=setComboData();

	comboColor1=new JComboBox(comboData);
	comboColor1.setRenderer(new ColorRenderer());
	comboColor1.addActionListener(this);
	defineFont(comboColor1);
	
	comboColor2=new JComboBox(comboData);
	comboColor2.setRenderer(new ColorRenderer());
	comboColor2.addActionListener(this);
	defineFont(comboColor2);
		
	JLabel initColor=new JLabel("Initial Color");
	defineFont(initColor);
	JLabel finalColor=new JLabel("Final Color");
	defineFont(finalColor);

	// cria os radiobuttons
	topToBottom=new JRadioButton("Top to Bottom");
	defineFont(topToBottom);
	topToBottom.setSelected(true);
	topToBottom.addActionListener(this);

	bottomToTop=new JRadioButton("Bottom to Top");
	bottomToTop.addActionListener(this);
	defineFont(bottomToTop);

	leftToRight=new JRadioButton("Left to Right");
	leftToRight.addActionListener(this);
	defineFont(leftToRight);

	rightToLeft=new JRadioButton("Right to Left");
	rightToLeft.addActionListener(this);
	defineFont(rightToLeft);

	bg=new ButtonGroup();
	bg.add(topToBottom);bg.add(bottomToTop);bg.add(leftToRight);bg.add(rightToLeft);
	
	JPanel radioPanel=new JPanel(new GridLayout(2,2));
	defineFont(radioPanel);
	radioPanel.setBorder(BorderFactory.createTitledBorder("Orientation"));
	radioPanel.add(topToBottom);radioPanel.add(bottomToTop);radioPanel.add(leftToRight);
	radioPanel.add(rightToLeft);
	
	comboPanel.add(initColor);
	comboPanel.add(finalColor);
	comboPanel.add(comboColor1);
	comboPanel.add(comboColor2);

	getContentPane().add("North",comboPanel);
	getContentPane().add("Center",radioPanel);

	pack();
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);
	setVisible(true);
    }

    private void defineFont(Component c) {
	c.setFont(new Font("SansSerif",Font.PLAIN,10));
    }

    public void actionPerformed(ActionEvent evt) {
	if (evt.getSource()==comboColor1 || evt.getSource()==comboColor2) {
	    Color color1=getColor(comboColor1);
	    Color color2=getColor(comboColor2);
	    graph.setGradientColors(color1,color2);
	}
	else if (evt.getSource()==topToBottom)
	    graph.setGradientOrientation(graph.TOP_TO_BOTTOM);
	else if (evt.getSource()==bottomToTop)
	    graph.setGradientOrientation(graph.BOTTOM_TO_TOP);
	else if (evt.getSource()==leftToRight)
	    graph.setGradientOrientation(graph.LEFT_TO_RIGHT);
	else if (evt.getSource()==rightToLeft)
	    graph.setGradientOrientation(graph.RIGHT_TO_LEFT);

	graph.repaint();
	
    }

    private Object[] setComboData() {
	Object[] obj=new Object[] {
	    new Object[]{Color.white,"white"},
	    new Object[]{Color.black,"black"},
	    new Object[]{Color.red,"red"},
	    new Object[]{Color.blue,"blue"},
    	    new Object[]{Color.yellow,"yellow"},
	    new Object[]{Color.magenta,"magenta"},
	    new Object[]{Color.orange,"orange"},
	    new Object[]{Color.gray,"gray"},
	    new Object[]{Color.green,"green"},
	    new Object[]{Color.lightGray,"lightGray"},
	    new Object[]{Color.cyan,"cyan"},
	    new Object[]{Color.pink,"pink"}};
	return obj;
    }

    Color getColor(JComboBox combo) {
	Object[] obj=(Object[])combo.getSelectedItem();
	Color color=(Color)obj[0];
	return color;
    }



}   
    



