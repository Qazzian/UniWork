import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

/**
 *
 * This demo shows a date chart with an area serie.
 * 
 */
public class Main extends Frame implements
ItemListener,AdjustmentListener  {
    Graph graph;
    AreaSerie as;

    Checkbox is3D;
    Choice dateIncrement;

    Scrollbar depth;

    public Main() {
	
	// A title for the frame
	setTitle("The JetChart Library - Date Chart Demo");
	

	float[] values1={4000,4000,3000,3500,4550,5000,6000,4000,4000,3000,5200,5300,5000,6000,
			 6000,6000,6500,6500,6500,6500,6550,6600,6650,6650,6600,6650,6600,6700,
			 6700,6700,6780,6780,6790,6790,6679,7000,7700,7000,7000,7000,7600,7500,
			 7500,7600,7700,7700,7770,7600,7700,7800,7800,7890,7860,7500,7400,7200,
			 7500,7400,7320,7200,7100,7400,7600,7600,7760,7400,7300,7200,7800,7900,
			 8000,8000,8000,8000,8870,8000,8600,8600,8600,8900,8500,8400,8300,8100};
		
    
	
	// Creates one AreaSerie
	as=new AreaSerie(values1,"Area Serie");

	// Sets area  serie properties
	setAreaSerieProperties();
	
	// Creates graphic context
	graph=new Graph();

	// Sets chart optional properties
	setChartProperties();

	// Adds the area serie to the graphic context
	graph.addSerie(as);
	

	add("Center",graph);

	// Creates a top panel to layout components
	createTopPanel();

	// Adds window adapter
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(640,450);
	

	// Centers frame on the screen
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);

	setVisible(true);

    }

    // Event handler for 3D state and date increment style changes
    public void itemStateChanged(ItemEvent evt) {
	if (evt.getSource()==is3D) {
	    graph.set3DEnabled(is3D.getState());
	    depth.setEnabled(is3D.getState());
	}
	else if (evt.getSource()==dateIncrement) {
	    if (dateIncrement.getSelectedItem().equals("Day increment")) 
		graph.setDateIncrement(Graph.DAY_INCREMENT);
	    else if (dateIncrement.getSelectedItem().equals("Week increment"))
		graph.setDateIncrement(Graph.WEEK_INCREMENT);
	    else if (dateIncrement.getSelectedItem().equals("Month increment"))
		graph.setDateIncrement(Graph.MONTH_INCREMENT);
	    else if (dateIncrement.getSelectedItem().equals("Year increment"))
		graph.setDateIncrement(Graph.YEAR_INCREMENT);

	    // although the start date is already defined, this is really needed here because
	    // it forces labels repainting.
	    graph.setStartDate("01072000");
	}
		    
		    
	graph.repaint();
    }

    // Event handler for chart depth adjustment
    public void adjustmentValueChanged(AdjustmentEvent evt) {
	if (evt.getSource()==depth) {
	    graph.setVDepth(depth.getValue());
	    graph.repaint();
	}
    }
	    
	    
    // Creates top panel
    private void createTopPanel( ) {

	// Creates top panel with a border around
	Panel topPanel=new Panel() {
	    public void paint(Graphics g) {
		g.setColor(Color.lightGray);
		g.draw3DRect(0,0,getSize().width-1,getSize().height-1,true);
		g.draw3DRect(2,2,getSize().width-4,getSize().height-4,false);
	    }
	};

	topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
	topPanel.setFont(new Font("Monospaced",Font.PLAIN,10));
	
	dateIncrement=new Choice();
	dateIncrement.addItemListener(this);
	dateIncrement.add("Day increment");
	dateIncrement.add("Week increment");
	dateIncrement.add("Month increment");
	dateIncrement.add("Year increment");

	//  Checkbox for 3D property.
	is3D=new Checkbox("3D");
	is3D.addItemListener(this);
	
	// Scrollbar for chart depth adjustment
	depth=new Scrollbar(Scrollbar.HORIZONTAL,5,1,0,30) {
	    public Dimension getPreferredSize() {
		Dimension d=super.getPreferredSize();
		return new Dimension(150,d.height);
	    }
	};
	
	depth.setEnabled(false);
	depth.addAdjustmentListener(this);
	
	topPanel.add(is3D);
	topPanel.add(new Label("3D depth:"));
	topPanel.add(depth);
	topPanel.add(new Label("Date increment:"));
	topPanel.add(dateIncrement);
    
	add("North",topPanel);

    }

    private void setAreaSerieProperties() {
	// Sets color
	as.setColor(Color.red);
	as.setAreaLinesEnabled(false);

	// Sets values font
	as.setFont(new Font("Arial",Font.PLAIN,8));
    
    }

    private void setChartProperties() {

	graph.getToolTip().setFont(new Font("SansSerif",Font.PLAIN,10));

	// Sets start date as July 01, 2000
	graph.setStartDate("07012000");

	// Divides the labels axis in aprpoximately five sections.
	// Only the labels that coincide with the beggining of each section
	// will be displayed.
	graph.setLabelSections(5);

	// Sets date labels in a week by week increment. Day by day increment is the default one.
	graph.setDateIncrement(Graph.WEEK_INCREMENT);
        graph.setStartOnAxisEnabled(true);

	// Sets a text to prefix the tooltip content
	graph.setToolTipLabel("Label and value: ");

	// Sets the tooltip content type as label and value.
	graph.setToolTipType(Graph.LABEL_AND_VALUE);
	
	
	// Enables tooltip
        graph.setToolTipEnabled(true);

	// Sets chart title
	String[] title={"A Date Chart Demo","with one Area Serie."};
	graph.setTitle(title);
	
	// Sets labels title
	graph.setLabelsTitle("Labels Title");

	// Sets values title
	graph.setValuesTitle("Values Title");

	// Applies gradient colors to graphic context
	graph.setGradientColors(Color.yellow,new Color(51,102,255));
	//graph.setGradientOrientation(graph.LEFT_TO_RIGHT);

	// Enables chart and legend dragging. A double-click over chart alternates
	// between moving chart and scale adjustment.
	graph.setDraggingEnabled(true);

	// Enables grid and sets grid color
	graph.setGridEnabled(true);
	graph.getGrid().setColor(Color.gray.darker());
	// graph.getGrid().setCrossedLinesEnabled(true);

	// Sets legend orientation,horizontal and vertical gaps,opacity  and position. Legend can be dinamically
	// dragged, if the Graph draggable property is set to true.
	graph.getLegend().setOrientation(Legend.HORIZONTAL);


	graph.setValueFormat("###,##0.00");
    
	// Sets depth for vertical charts
	graph.setVDepth(5);

    }



    public static void main(String[] args) {
	new Main();
    }
}
