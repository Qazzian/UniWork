import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

/**
 * Main.java
 *
 *
 * Created: Wed Dec 15 16:34:56 1999
 *
 * @author Andre de Lima Soares - alsoares@jinsight.com
 * @version 1.0
 */

public class Main extends Frame implements ActionListener  {
    Graph graph;
    PieSerie ps;
    PieConsole pc;

    /**
     * The mouse can be used to rotate the pie and explode slices. 
     * To rotate the pie just click the left-button over it and dragg.
     * To explode slices, click the left-button combined with the Shift-key and
     * dragg.
     * The mouse can still be used to move the pie or change its size.
     * To move the pie, click in an area outside its bounds and dragg.
     * A double-click outside the pie bounds alternate between moving the pie
     * and changing its size.
     * Double-click over an area outside the pie bounds. After that, 
     * click the left-button over the same area and dragg.
     * The legend can also be dragged. Just click over it and dragg to the
     * left, right or bottom sides. A red border will appear when the legend
     * is positioned in a valid area.
     */

    public Main() {
	setTitle("The JetChart Library - Pie Chart Demo");
	
	// Legends of each slice
	String[] labels={"Andre","Simone","Carlos","Roberto","Monica","Adriano"};

	// Creates graphic context. That is where painting occurs.
	graph=new Graph(labels);

	// Specifies a format to values shown on active labels.
	graph.setValueFormat("###,##0.00");

	// Enables 3D view
	graph.set3DEnabled(true);

	// Enables chart dragging
	graph.setDraggingEnabled(true);

	// Disables tooltip
	graph.setToolTipEnabled(false);

	// Sets gradient effect from white to blue
	graph.setGradientColors(Color.white,Color.blue);
	
	// Sets legend position
	graph.getLegend().setPosition(Legend.RIGHT);
	
	// Values of each slice
	float[] sliceValues={100,50,90,40,200,60};
	
	// Creates pie serie
 	ps=new PieSerie(sliceValues);

	// Adds pie serie to graphic context
	graph.addSerie(ps);

	// Explodes one slice. All slices can be exploded dinamically, just dragging them with the
	// mouse left-button and shift-key pressed. A number greater than zero must be informed
	// to explode the slice.
	ps.getSlice(2).setPosition(20);

	// Sets a different font for all slice legends. 
	Slice[] slices=ps.getSlices();
	for (int counter=0;counter<slices.length;counter++) {
	    slices[counter].getSliceLegend().setFont(new Font("Arial",Font.BOLD,12));
	    slices[counter].getSliceLegend().setArrowColor(Color.magenta);
	}

	// Sets a different font for just one slice legend
	ps.getSlice(0).getSliceLegend().setFont(new Font("Monospaced",Font.ITALIC,14));

	// Changes arrow color of one slice legend
	ps.getSlice(0).getSliceLegend().setArrowColor(Color.blue);

	// Sets some different colors to slices legends
	ps.getSlice(0).getSliceLegend().setBackground(Color.red);
	ps.getSlice(0).getSliceLegend().setForeground(Color.white);
	ps.getSlice(0).getSliceLegend().setBackground(Color.pink);
	ps.getSlice(4).getSliceLegend().setBackground(Color.orange);


	// Enables opacity of some slice legends, individually.
	ps.getSlice(0).getSliceLegend().setOpacityEnabled(true);
	ps.getSlice(2).getSliceLegend().setOpacityEnabled(true);
	ps.getSlice(4).getSliceLegend().setOpacityEnabled(true);
	
	// Changes border of some slice legends
	ps.getSlice(0).getSliceLegend().setBorder(SliceLegend.RAISED_BEVEL);
	ps.getSlice(2).getSliceLegend().setBorder(SliceLegend.SHADOWED);
	ps.getSlice(4).getSliceLegend().setBorder(SliceLegend.LOWERED_BEVEL);
	

	// Creates a Panel with a border around
	Panel p=new Panel() {
	    public void paint(Graphics g) {
		g.setColor(Color.lightGray);
		g.draw3DRect(0,0,getSize().width-1,getSize().height-1,true);
		g.draw3DRect(2,2,getSize().width-4,getSize().height-4,false);
	    }
	};
	p.setLayout(new FlowLayout(FlowLayout.LEFT));

	add("North",p);

	// Creates a Button to show the Control Panel dialog window
	Button b=new Button("Control Panel");
	b.setFont(new Font("SansSerif",Font.PLAIN,10));
	b.addActionListener(this);

	p.add(b);
		
	add("Center",graph);

	// Adds a mouse listener
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(450,350);

	Dimension d=getToolkit().getScreenSize();
	
	// Centers frame on the screen
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);
	setVisible(true);
    }
    
    public void actionPerformed(ActionEvent evt) {
	if (pc==null)
	    pc=new PieConsole(this);
	else {
	    // centers the PieConsole instance in this window
	    pc.setLocation((getSize().width-pc.getSize().width)/2+getLocation().x,
			   (getSize().height-pc.getSize().height)/2+getLocation().y);
	    
	    pc.setVisible(true);
	}
    }

    public static void main(String[] args) {
	new Main();
    }

}




