import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

/**
 * PieConsole.java
 *
 *
 * Created: Wed Dec 15 17:50:11 1999
 *
 * @author Andre de Lima Soares
 * @version 1.0
 */

public class PieConsole extends Dialog implements AdjustmentListener,ItemListener {
    Scrollbar xRadiusInsets,yRadiusInsets,depth,legendDistance;
    Main pChart;
    Checkbox circled,border,legend,position,is3D,tooltip,title,xTitle,yTitle,graphLegend;
    Choice content,borderType;
    public PieConsole(Frame owner) {
	super(owner,true);
	pChart=(Main)owner;
	setTitle("Control Panel");

	GridBagLayout gb=new GridBagLayout();
	GridBagConstraints gc=new GridBagConstraints();
	
	setLayout(gb);

	createComponents(gb,gc);

	//setSize(200,200);
	pack();

	Dimension d=owner.getSize();
	Dimension s=getToolkit().getScreenSize();

	// centers this child window in the owner window
	setLocation((d.width-getSize().width)/2+owner.getLocation().x,(d.height-getSize().height)/2+owner.getLocation().y);

	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		setVisible(false);
	    }
	});

	setVisible(true);
    }

    private void createComponents(GridBagLayout gb,GridBagConstraints gc) {
	gc.fill=GridBagConstraints.BOTH;
	gc.weightx=1.0;
	gc.anchor=GridBagConstraints.WEST;
	gc.insets=new Insets(2,2,2,2);

	// creates labels for scrollbars
	Label labelXRadiusInsets=new Label("Horizontal insets",Label.LEFT);
	setCompFont(labelXRadiusInsets);
	Label labelYRadiusInsets=new Label("Vertical insets",Label.LEFT);
	setCompFont(labelYRadiusInsets);
	gb.setConstraints(labelXRadiusInsets,gc);
	add(labelXRadiusInsets);
	
	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(labelYRadiusInsets,gc);
	add(labelYRadiusInsets);

	gc.gridwidth=1;

	// creates scrollbars for xRadiusInsets and yRadiusInsets adjustment
	xRadiusInsets=new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,50);
	xRadiusInsets.addAdjustmentListener(this);
	yRadiusInsets=new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,50);
	yRadiusInsets.addAdjustmentListener(this);

	gb.setConstraints(xRadiusInsets,gc);
	add(xRadiusInsets);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(yRadiusInsets,gc);
	add(yRadiusInsets);

	gc.gridwidth=1;
	gc.fill=GridBagConstraints.NONE;
	circled=new Checkbox("Circled pie");
	setCompFont(circled);
	circled.addItemListener(this);
	gb.setConstraints(circled,gc);
	add(circled);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	border=new Checkbox("Show borders");
	setCompFont(border);
	border.addItemListener(this);
	gb.setConstraints(border,gc);
	add(border);

	gc.gridwidth=1;
	legend=new Checkbox("Show slice legends");
	setCompFont(legend);
	legend.addItemListener(this);
	gb.setConstraints(legend,gc);
	add(legend);
	
	gc.gridwidth=GridBagConstraints.REMAINDER;
	position=new Checkbox("Move slice legends outside");
	setCompFont(position);
	position.setEnabled(false);
	position.addItemListener(this);
	gb.setConstraints(position,gc);
	add(position);

	gc.gridwidth=1;
	is3D=new Checkbox("3D");
	setCompFont(is3D);
	is3D.setState(true);
	is3D.addItemListener(this);
	gb.setConstraints(is3D,gc);
	add(is3D);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	tooltip=new Checkbox("Enable tooltip");
	setCompFont(tooltip);
	tooltip.addItemListener(this);
	gb.setConstraints(tooltip,gc);
	add(tooltip);

	gc.gridwidth=1;
	title=new Checkbox("Show chart title");
	setCompFont(title);
	title.addItemListener(this);
	gb.setConstraints(title,gc);
	add(title);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	xTitle=new Checkbox("Show bottom title");
	setCompFont(xTitle);
	xTitle.addItemListener(this);
	gb.setConstraints(xTitle,gc);
	add(xTitle);

	gc.gridwidth=1;
	yTitle=new Checkbox("Show left title");
	setCompFont(yTitle);
	yTitle.addItemListener(this);
	gb.setConstraints(yTitle,gc);
	add(yTitle);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	graphLegend=new Checkbox("Show graph legend");
	setCompFont(graphLegend);
	graphLegend.setState(true);
	graphLegend.addItemListener(this);
	gb.setConstraints(graphLegend,gc);
	add(graphLegend);
	
	gc.gridwidth=1;
	gc.fill=GridBagConstraints.BOTH;
	gc.insets=new Insets(0,0,0,0);
	Label labelContent=new Label("Legend content",Label.LEFT);
	Label labelBorderType=new Label("Legend border type",Label.LEFT);

	setCompFont(labelContent);
	setCompFont(labelBorderType);
	
	gb.setConstraints(labelContent,gc);
	add(labelContent);

	gc.gridwidth=GridBagConstraints.REMAINDER;
	gb.setConstraints(labelBorderType,gc);
	add(labelBorderType);
	
	gc.gridwidth=1;

	content=new Choice();
	content.setEnabled(false);
	content.addItem("VALUE");
	content.addItem("PERCENT");
	content.addItem("LABEL");
	content.addItem("LABEL AND VALUE");
	content.addItem("LABEL AND PERCENT");
	content.addItem("VALUE AND PERCENT");
	content.addItemListener(this);
	
	gb.setConstraints(content,gc);
	add(content);
	
	gc.gridwidth=GridBagConstraints.REMAINDER;
	borderType=new Choice();
	borderType.setEnabled(false);
	borderType.addItemListener(this);
	borderType.addItem("SHADOWED");
	borderType.addItem("LOWERED BEVEL");
	borderType.addItem("RAISED BEVEL");
	gb.setConstraints(borderType,gc);
	add(borderType);
	
	

	gc.gridwidth=1;

	Label labelLegendDistance=new Label("Legend vertex distance",Label.LEFT);
	setCompFont(labelLegendDistance);
	gb.setConstraints(labelLegendDistance,gc);
	add(labelLegendDistance);

	gc.gridwidth=GridBagConstraints.REMAINDER;

	Label labelDepth=new Label("3D depth",Label.LEFT);
	setCompFont(labelDepth);
	gb.setConstraints(labelDepth,gc);
	add(labelDepth);

	gc.gridwidth=1;
	legendDistance=new Scrollbar(Scrollbar.HORIZONTAL,7,1,0,10);
	legendDistance.setEnabled(false);
	legendDistance.addAdjustmentListener(this);
	gb.setConstraints(legendDistance,gc);
	add(legendDistance);


	gc.gridwidth=GridBagConstraints.REMAINDER;
	
	depth=new Scrollbar(Scrollbar.HORIZONTAL,10,1,0,50);
	gb.setConstraints(depth,gc);
	add(depth);
	depth.addAdjustmentListener(this);
	

	

    }

    public void adjustmentValueChanged(AdjustmentEvent evt) {
	if (evt.getSource()==xRadiusInsets)
	    pChart.ps.setXRadiusInset(xRadiusInsets.getValue());
	else if (evt.getSource()==yRadiusInsets)
	    pChart.ps.setYRadiusInset(yRadiusInsets.getValue());
	else if (evt.getSource()==depth)
	    pChart.ps.set3DDepth(depth.getValue());
	else if (evt.getSource()==legendDistance) {
	    Slice[] slices=pChart.ps.getSlices();
	    for (int counter=0;counter<slices.length;counter++)
		slices[counter].getSliceLegend().setVertexDistance(((double)legendDistance.getValue())/10);
	}
	    
	pChart.graph.repaint();
	
    }

    public void itemStateChanged(ItemEvent evt) {
	if (evt.getSource()==circled) 
	    pChart.ps.setCircledEnabled(circled.getState());

	else if (evt.getSource()==border)
	    pChart.ps.setBorderEnabled(border.getState());

	else if (evt.getSource()==legend) {
	    
	    Slice[] slices=pChart.ps.getSlices();
	    for (int counter=0;counter<slices.length;counter++)
		slices[counter].setSliceLegendEnabled(legend.getState());
	    
	    legendDistance.setEnabled(legend.getState() && !position.getState());
	    position.setEnabled(legend.getState());
	    content.setEnabled(legend.getState());
	    borderType.setEnabled(legend.getState());
	}

	else if (evt.getSource()==position) {
	    pChart.ps.setSliceLegendPosition(position.getState() ? SliceLegend.OUTSIDE : SliceLegend.INSIDE);
	    legendDistance.setEnabled(!position.getState());
	}

	else if (evt.getSource()==content) {
	    Slice[] slices=pChart.ps.getSlices();
	    for (int counter=0;counter<slices.length;counter++)
		slices[counter].getSliceLegend().setContent(content.getSelectedIndex());
	}

	else if (evt.getSource()==borderType) {
	    Slice[] slices=pChart.ps.getSlices();
	    for (int counter=0;counter<slices.length;counter++)
		slices[counter].getSliceLegend().setBorder(borderType.getSelectedIndex());
	}

	else if (evt.getSource()==is3D)
	    pChart.graph.set3DEnabled(is3D.getState());

	else if (evt.getSource()==tooltip)
	    pChart.graph.setToolTipEnabled(tooltip.getState());

	else if (evt.getSource()==title) {
	    if (title.getState())
		pChart.graph.setTitle(new String[]{"PIE CHART TITLE"});
	    else
		pChart.graph.setTitle(null);
	}

	else if (evt.getSource()==xTitle) {
	    if (xTitle.getState())
		pChart.graph.getXAxis().setTitle("BOTTOM TITLE");
	    else
		pChart.graph.getXAxis().setTitle(null);
	}

	else if (evt.getSource()==yTitle) {
	    if (yTitle.getState())
		pChart.graph.getYAxis().setTitle("LEFT TITLE");
	    else
		pChart.graph.getYAxis().setTitle(null);
	}

	else if (evt.getSource()==graphLegend) 
	    pChart.graph.setLegendEnabled(graphLegend.getState());

	pChart.graph.repaint();

    }
    

    private void setCompFont(Component c) {
	c.setFont(new Font("Arial",Font.PLAIN,10));
    }
	
}

