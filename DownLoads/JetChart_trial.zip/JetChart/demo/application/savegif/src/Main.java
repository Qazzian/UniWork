import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Observable;
import java.util.Observer;
import com.jinsight.jetchart.*;

/**
 * Demo that shows basic code to generate gif file from a chart image with a Pie Serie.
 * Gif generation is useful when charts are generated from a servlet request. The gif
 * file is generated in the server-side and then referenced in the html code sent by the
 * servlet back to the client browser.
 */

public class Main extends Frame implements
ActionListener,Observer,Runnable {
    Graph graph;
    PieSerie ps;

    /**
     * A File object is created here. It is referenced by the gif encoding process to generate
     * a file in the application directory with the name piechart.gif.
     */
    File imageFile=new File("piechart.gif");

    boolean firstUpdate=true;

    Label gifLabel,gifPercent;
    int maximum;

    public Main() {
	setTitle("The JetChart Library - Demo with a Pie Chart and gif file generation");
	graph=new Graph();
	
	/**
	 * This is just a way to inform an observer about the gif generation process. 
	 * While pixels are being sent to file, the observer is notified, to allow some
	 * kind of visual information, like a gauge. See the update method at the end.
	 */
	graph.addImageEncodingObserver(this);

	// Sets graphic context properties
	setChartProperties();

	// Creates Pie Serie and sets its properties
	createPieSerie();
	
	// Adds pie serie to graphic context
	graph.addSerie(ps);
	
	add("Center",graph);

	// Creates top panel with a gif generation button
	createTopPanel();

	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});
	

	setSize(400,350);

	// Centers frame on the window
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);

	setVisible(true);
    }
    
    private void setChartProperties() {

	// Enables 3D
	graph.set3DEnabled(true);
	
	// Legends of each slice
	String[] sliceLegends={"Andre","Simone","Carlos","Roberto","Monica","Adriano"};
	graph.setLabels(sliceLegends);

	// Enables dragging
	graph.setDraggingEnabled(true);
	
	// Moves legend to the right
	graph.getLegend().setPosition(Legend.RIGHT);
    }

    private void createPieSerie() {
		// Values of each slice
	float[] sliceValues={100,50,90,40,200,60};
	
	

	// Creates pie serie
 	ps=new PieSerie(sliceValues);
	Slice[] slices=ps.getSlices();
	for (int counter=0;counter<slices.length;counter++)
	    slices[counter].setSliceLegendEnabled(true);
    }

    private void createTopPanel() {
	Panel topPanel=new Panel() {
	    public void paint(Graphics g) {
		g.setColor(Color.lightGray);
		g.draw3DRect(0,0,getSize().width-2,getSize().height-2,true);
		g.draw3DRect(2,2,getSize().width-4,getSize().height-4,false);
	    }
	};
	topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

	Button gif=new Button("Save gif");
	gif.addActionListener(this);
	topPanel.add(gif);

	gifLabel=new Label("Percentual of pixels sent to file:");
	gifPercent=new Label("    ");
	gifLabel.setVisible(false);
	gifPercent.setVisible(false);

	topPanel.add(gifLabel);
	topPanel.add(gifPercent);
	
	add("North",topPanel);
    }


   

    public void actionPerformed(ActionEvent evt) {
	/**
	 * Saves chart image in file imageFile. The saving process will take effect in a thread, here,
	 * because will be demonstrated how to generate visual information about the pixels already
	 * file. This is important, once gif generation can take a while, depending on the
	 * chart dimension.
	 */
	firstUpdate=true;
	gifLabel.setVisible(true);
	gifPercent.setVisible(true);
	validate();	

	/**
	 * Disables chart to avoid pie handling while generating gif. Other alternative is to set
	 * thread priority to 2, without disabling chart. But, in this case, gif generation will
	 * be slower.
	 */
	graph.setEnabled(false);

	Thread t=new Thread(this);
	t.start();
	
    }

    public void run() {
	/**
	 * Starts encoding process. The second parameter is a percentual scale to be applied to
	 * the image being saved. Note that the gifEncode method internally handles a gif encoder
	 * object, which sends to the update()
	 * method of the Observer object(in this case,this application) the total of pixels to 
	 * be saved and the number of pixels already saved, to be used in a visual information
	 * about the encoding process(A gauge, a label showing percentual values, etc). See the
	 * update() method below. There is a small delay before the encoder send values to the
	 * observer. That's because it is calculating the total amount of pixels of the chart image.
	 */
	try {
	    graph.gifEncode(imageFile,100);
	    // A message dialog can be inserted here to inform user about ending of the encoding process.
	    // In a swing application, a JOptionPane dialog is adequate.
	}
	catch (IOException e) {
	    e.printStackTrace();
	}
	finally {
	    // Disables labels visibility and enables chart.
	    gifLabel.setVisible(false);
	    gifPercent.setVisible(false);
	    gifPercent.setText("    ");
	    graph.setEnabled(true);
	}

    }

    // Implements the Observer interface
    public void update(Observable obs, Object obj) {
	
	/**
	 * The first time the observer is notified, the image encoder  sends the amount of pixels
	 * that will be saved in file, as an Integer object.  Subsequent notifications will inform the amount of pixels
	 * already sent to file. This is useful when is necessary to show some visual information
	 * about the encoding process. The firstUpdate boolean variable below controls value
	 * detection. The Observable obs variable is a reference to the gif encoder object, and
	 * is not useful here.
	 */
	int value=((Integer)obj).intValue();

	if (firstUpdate) {
	    // This code block is executed only once.
	    firstUpdate=false;
	    // Registers total of pixels
	    maximum=value;
	}
	else {
	    // Shows percentual information
	    gifPercent.setText(Integer.toString(value*100/maximum)+" %");
	    
	}
		
    }

    public static void main(String[] args) {
	new Main();
    }

}
    
