import com.jinsight.jetchart.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;


/**
 * This class demonstrates handling of serie events with all Serie classes of The JetChart Library.
 * It is a Swing example, and requires that the GradientPanel class be defined as an extension of
 * JPanel, instead of Panel, that is the default one, otherwise display problems may occur.
 * The Main class is implemented in a way that it is possible to run it as a single application or
 * a Swing applet. When it is executed as an application, a JFrame object is created and its 
 * content pane is set to be the same as the Main class content pane. 
 */

public class Main extends JApplet implements ItemListener {

    CustGraph lineGraph,barGraph,areaGraph,stackBarGraph,pointGraph,imageGraph,pieGraph,comboGraph;
    JTabbedPane jt;
    JCheckBox horizontal,_3D;

    Vector windows=new Vector();
    boolean showNewWindow;

    String[] labels={"label1","label2","label3","label4","label5","label6"};
    
    float[] values={354.23F,453.12F,200.87F,145.93F,231.55F,121.33F};
    float[] values2={244.33F,545.92F,354.12F,254F,419.81F,890.43F};

    Image img1=getToolkit().getImage("image1.gif");
    Image img2=getToolkit().getImage("image2.gif");
    Image img3=getToolkit().getImage("image3.gif");
    Image img4=getToolkit().getImage("image4.gif");
    Image img5=getToolkit().getImage("image5.gif");
    Image img6=getToolkit().getImage("image6.gif");

    Image[] images={img1,img2,img3,img4,img5,img6};	
    

    // The elementsLists1 and elementsList2 arrays keep the lists that will be displayed when 
    // and element of a serie is clicked.
    String[][] elementsLists1=new String[][]{{"car","motorcycle","bicycle","airplane"},
				 {"computer","mouse","keyboard","notebook","monitor"},
				 {"apple","orange","watermelon","strawberry","cashew"},
				 {"Andre","Simone","Ivan","Ronaldo","Maria","Valquiria","Carlos"},
				 {"cat","dog","bird","lion","elephant","mouse","tiger","cow","dinosaur"},
				 {"house","kitchen","bedroom","bathroom","dinner-room","carpet","chair"}};
    
    String[][] elementsLists2=new String[][]{{"oven","refrigerator","freezer","mixer"},
				 {"yellow","red","black","orange","blue"},
				 {"pen","pencil","eraser","ruler"},
				 {"iron","silver","gold","diamond","emerald"},
				 {"pants","shirt","dress","socks","brush","shoes"},
				 {"eyes","mouth","hair","hands","legs","foot","fingers"}};

    String[][] elementsLists3=new String[][]{{"Brasil","Spain","India","Portugal"},
				 {"Russia","France","Ireland","Holland","China"},
				 {"Japan","Corea","Malasia","Sweden"},
				 {"South America","North America","Europe","Asia","Africa"},
				 {"Angola","Mocambique","Marrocos","Congo","Africa do Sul","Quenia"},
				 {"Iran","Israel","Siria","Libano","Iraque","Palestina","Turquia"}};
    
    // the seriesLists  array keeps two lists, which will be displayed when a click over 
    // the image of a serie in a legend is performed.
    String[][] seriesLists=new  String[][]{{"JAVA","PASCAL","COBOL","FORTRAN","SMALLTALK"},
					  {"FOOTBALL","BASKETBALL","VOLEYBALL","HANDBALL"},
                                          {"ENGINEER","DOCTOR","PROGRAMMER","PHYSICIAN"}};
    
    public void init() {
	
	jt=new JTabbedPane();

	createLineChart();
	createBarChart();
	createAreaChart();
	createStackBarChart();
	createPointChart();
	createImageChart();
	createPieChart();
	createComboChart();
	
	SerieHandler sh=new SerieHandler();

	lineGraph.addSerieListener(sh);
	barGraph.addSerieListener(sh);
	areaGraph.addSerieListener(sh);
	stackBarGraph.addSerieListener(sh);
	pointGraph.addSerieListener(sh);
	imageGraph.addSerieListener(sh);
	pieGraph.addSerieListener(sh);
	comboGraph.addSerieListener(sh);

	createBottomPanel();

	getContentPane().add(jt,BorderLayout.CENTER);


    }

    private void createLineChart() {
	lineGraph=new CustGraph();
	lineGraph.setTitle(new String[]{"A Line Chart" });
	lineGraph.setDraggingEnabled(true);
	lineGraph.setLabels(labels);
	lineGraph.setGradientColors(Color.white,new Color(180,255,255));
	lineGraph.setGridEnabled(true);
	lineGraph.getGrid().setCrossedLinesEnabled(true);
	lineGraph.setStartOnAxisEnabled(true);

	LineSerie ls=new LineSerie(values,"Line Serie");
	ls.setColor(Color.red);
	ls.setThickness(3);
	lineGraph.addSerie(ls);

	jt.addTab("Line Chart",lineGraph);

    }

    private void createBarChart() {
	barGraph=new CustGraph();
	barGraph.setTitle(new String[]{"A Bar Chart" });
	barGraph.setLabels(labels);
	barGraph.setGridEnabled(true);
	BarSerie bs=new BarSerie(values,"Bar Serie");
	bs.setColor(Color.green);
	bs.setWidth(20);
	barGraph.addSerie(bs);

	jt.addTab("Bar Chart",barGraph);	

    }

    private void createAreaChart() {
	areaGraph=new CustGraph();
	areaGraph.setTitle(new String[]{"An Area Chart" });
	areaGraph.setGradientColors(Color.white,new Color(051,204,255));
	areaGraph.setGradientOrientation(Graph.LEFT_TO_RIGHT);

	areaGraph.setGridEnabled(true);
	areaGraph.setLabels(labels);
	areaGraph.setStartOnAxisEnabled(true);
	AreaSerie as=new AreaSerie(values,"Area Serie");
	as.setColor(Color.yellow);
	areaGraph.addSerie(as);

	jt.addTab("Area Chart",areaGraph);	

    }

    private void createStackBarChart() {

	stackBarGraph=new CustGraph();
	stackBarGraph.setTitle(new String[]{"A Stacked Bars Chart" });

	stackBarGraph.setGridEnabled(true);
	stackBarGraph.setLabels(labels);

	StackBarSerie sb1=new StackBarSerie(values,"Stacked Bar Serie 1");
	sb1.setColor(Color.cyan);
	sb1.setId(0);

	StackBarSerie sb2=new StackBarSerie(values2,"StackBar Serie 2");
	sb2.setColor(Color.orange);
	sb2.setId(1);

	stackBarGraph.addSerie(sb1);
	stackBarGraph.addSerie(sb2);

	
	jt.addTab("Stacked Bar Chart",stackBarGraph);
	
    }
    
    private void createPointChart() {
	pointGraph=new CustGraph();
	pointGraph.setTitle(new String[]{"A Point Chart" });
	pointGraph.setGradientColors(new Color(051,204,255),Color.yellow);
	pointGraph.setGridEnabled(true);
	pointGraph.setLabels(labels);

	PointSerie ps1=new PointSerie(values,"Point Serie 1");
	ps1.setColor(Color.green.darker());
	ps1.setShape(PointSerie.TRIANGLE);
	ps1.setId(0);

	PointSerie ps2=new PointSerie(values2,"Point Serie 2");
	ps2.setColor(Color.pink);
	ps2.setId(1);

	pointGraph.addSerie(ps1);
	pointGraph.addSerie(ps2);

	jt.addTab("Point Chart",pointGraph);
	    
    }    

    private void createImageChart() {
	imageGraph=new CustGraph();
	imageGraph.setTitle(new String[]{"An Image Chart" });

	imageGraph.setGridEnabled(true);
	imageGraph.setToolTipEnabled(true);
	imageGraph.setLabels(labels);
	ImageSerie is=new ImageSerie(values,images);
	
	imageGraph.addSerie(is);

	jt.addTab("Image Chart",imageGraph);
	    
    }    


    private void createPieChart() {
	pieGraph=new CustGraph();
	pieGraph.setTitle(new String[]{"A Pie Chart" });

	pieGraph.setLabels(labels);
	pieGraph.setGridEnabled(true);
	PieSerie ps=new PieSerie(values);
	pieGraph.addSerie(ps);
	// explodes first slice
	ps.getSlice(0).setPosition(10); 
	ps.setBorderEnabled(true);
	
	jt.addTab("Pie Chart",pieGraph);

    } 

    private void createComboChart() {

	comboGraph=new CustGraph();
	comboGraph.setTitle(new String[]{"A Combined Chart" });

	comboGraph.setLabels(labels);
	comboGraph.setGridEnabled(true);
	comboGraph.set3DSeriesInLineEnabled(false);
	comboGraph.setGridEnabled(true);
	comboGraph.getLegend().setAutoOrientationEnabled(false);
	comboGraph.getLegend().setPosition(Legend.BOTTOM);
	comboGraph.getXAxis().setFill3DColor(new Color(134,204,255));
	comboGraph.getYAxis().setFill3DColor(new Color(134,204,255));

	StackBarSerie sb1=new StackBarSerie(values2,"Stacked Bar Serie 1");
	sb1.setColor(Color.pink);
	sb1.setId(0);

	StackBarSerie sb2=new StackBarSerie(values2,"Stacked Bar Serie 2");
	sb2.setColor(Color.orange);
	sb2.setId(1);

	BarSerie bs=new BarSerie(values,"Bar Serie");
	bs.setColor(Color.yellow);
	bs.setId(2);
	
	comboGraph.addSerie(sb1);
	comboGraph.addSerie(sb2);
	comboGraph.addSerie(bs);

	jt.addTab("Combo Chart",comboGraph);
	
    }
    
	
    
    private void createBottomPanel() {
	JPanel bottomPanel=new JPanel();

	horizontal=new JCheckBox("Horizontal Chart");
	horizontal.addItemListener(this);

	_3D=new JCheckBox("3D");
	_3D.addItemListener(this);

	bottomPanel.add(horizontal);
	bottomPanel.add(_3D);

	getContentPane().add("South",bottomPanel);
    }
	
    public void itemStateChanged(ItemEvent evt) {
	if (evt.getSource()==horizontal) { 
	    lineGraph.setHorizontalGraphEnabled(horizontal.isSelected());
	    barGraph.setHorizontalGraphEnabled(horizontal.isSelected());
	    areaGraph.setHorizontalGraphEnabled(horizontal.isSelected());
	    stackBarGraph.setHorizontalGraphEnabled(horizontal.isSelected());
	    pointGraph.setHorizontalGraphEnabled(horizontal.isSelected());
	    imageGraph.setHorizontalGraphEnabled(horizontal.isSelected());
	    comboGraph.setHorizontalGraphEnabled(horizontal.isSelected());
	}
	if (evt.getSource()==_3D) {
	    lineGraph.set3DEnabled(_3D.isSelected());
	    barGraph.set3DEnabled(_3D.isSelected());
	    areaGraph.set3DEnabled(_3D.isSelected());
	    stackBarGraph.set3DEnabled(_3D.isSelected());
	    pointGraph.set3DEnabled(_3D.isSelected());
	    imageGraph.set3DEnabled(_3D.isSelected());
	    pieGraph.set3DEnabled(_3D.isSelected());
	    comboGraph.set3DEnabled(_3D.isSelected());
	    
	}

	repaintAll();
	
    }	    
    
    private void repaintAll() {
	lineGraph.repaint();
	barGraph.repaint();
	areaGraph.repaint();
	stackBarGraph.repaint();
	pointGraph.repaint();
	imageGraph.repaint();
	pieGraph.repaint();
	comboGraph.repaint();
    }


    // This class and an adapter that has already implemented the methods defined
    // in the SerieListener interface. 
    class SerieHandler extends SerieAdapter {
	
	public void serieClicked(SerieEvent evt) {

	    String[] obj=null;

	    Graph graph=evt.getGraph();

	    AbstractSerie as=evt.getSerie();

	    if (evt.getClickCount()==2) {

		if (graph==lineGraph || graph==barGraph || graph==areaGraph || graph==imageGraph) {
		    if (!evt.isOverLegend()) {
			// retrieves the index of the element clicked. Ranges from 0 to (the total number of
			// values of the serie)-1.  
			int elementIndex=evt.getSerie().getElementIndex();
			
			// retrieves the associated list from the elementsLists array
			//created in the init() method.
			obj=elementsLists1[elementIndex];
			
		    }
		    else 
			obj=seriesLists[0];
		}
		else if (graph==stackBarGraph || graph==pointGraph || graph==comboGraph) {
		    if (!evt.isOverLegend()) {
			if (as.getId()==0)
			    obj=elementsLists1[as.getElementIndex()];
			else if (as.getId()==1)
			    obj=elementsLists2[as.getElementIndex()];
			else if (as.getId()==2)
			    obj=elementsLists3[as.getElementIndex()];

		    }
		    else 
			obj=seriesLists[as.getId()];

		}
		else if (graph==pieGraph) {
			int elementIndex=evt.getSerie().getElementIndex();
			obj=elementsLists1[elementIndex];
			
		}
		
	
		PopUpWindow popUp=new PopUpWindow(obj,120,100);
			
		
		// Sets the position where the window will be displayed. It is displayed with its
		// left upper corner positioned exactly at the place where the mouse was clicked.
		Point p=getLocation();
		SwingUtilities.convertPointToScreen(p,lineGraph);
		
		popUp.setLocation(p.x+evt.getX(),p.y+evt.getY());
				
		popUp.setVisible(true);
		
		// registers that a new window was created, to control window disposal inside the
		// mouseReleased handler of the CustGraph class.
		showNewWindow=true;
		
		// the windows Vector is verified in the serie event handler in order to get rid
		// of all visible windows.
		windows.addElement(popUp);
		
	    }
	}
	
    }

    // A customized JWindow class to display lists.
    class PopUpWindow extends JWindow {

	public PopUpWindow(String[] obj,int width,int height) { 
	    
	    // creates a JList to display the list
	    JList list=new JList();
	    list.setListData(obj);
	    
	    // Creates a JPanel with a border around.
	    JPanel panel=new JPanel();
	    panel.setLayout(new BorderLayout());
	    panel.setBorder(BorderFactory.createTitledBorder("Title"));
	    
	    // Adds the list to the JPanel
	    panel.add(new JScrollPane(list),BorderLayout.CENTER);
	    
	    // Adds the JPanel to the Window
	    this.getContentPane().add(panel,BorderLayout.CENTER);
	    
	    // Sets window size. 
	    setSize(width,height);
	}
    }
    
    class CustGraph extends Graph {
	// overrides the mouseReleased handler of the Graph class. The super class handler must
	// ever be invoked at the beginning(super.mouseReleased(evt)).
	public void mouseReleased(MouseEvent evt) {
	    super.mouseReleased(evt);
	    
	    // If a single click is performed and a window has been recently displayed, loops 
	    // through the windows Vector in order to dispose window.
	    if (evt.getClickCount()==1 && showNewWindow) {
		for (int counter=0;counter<windows.size();counter++) {
		    Window w=(Window)windows.elementAt(counter);
		    w.dispose();
		    
		}
		windows.removeAllElements();
	    }
	    // resets window controller.
	    showNewWindow=false;
	    
	}

	// if dragging is enabled and a window is visible, if the mouseDragged handler is not
	// overriden and the mouse is dragged, the window will remain active. The mouseDragged handler
	// must be overriden to control windows disposal in the same way mouseReleased does.
	public void mouseDragged(MouseEvent evt) {
	    super.mouseDragged(evt);
	    // If a window has been recently displayed, loops 
	    // through the windows Vector in order to dispose window.
	    if (showNewWindow) {
		for (int counter=0;counter<windows.size();counter++) {
		    Window w=(Window)windows.elementAt(counter);
		    w.dispose();
		    
		}
		windows.removeAllElements();
		// resets window controller.
		showNewWindow=false;
	    }
	}
	
	
	
    }

    public static void main(String[] args) {
	JApplet applet=new Main();
	applet.init();
	JFrame frame=new JFrame();
	frame.setTitle("The JetChart Library - Serie Event Handler Demo");
	frame.setContentPane(applet.getContentPane());
	frame.setSize(500,500);
	frame.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent evt) {
		    System.exit(0);
		}
	    });

	frame.setVisible(true);
		
    }
}
	
