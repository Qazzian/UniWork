import com.jinsight.jetchart.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/**
 * Main.java
 *
 *
 * Created: Thu Aug 31 18:32:27 2000
 *
 * @author Andre de Lima Soares - alsoares@jinsight.com
 */


/**
 * This example runs either as a single java application or an applet.
 * 
 */
public class Main extends Applet implements SerieListener {

    BarSerie b;
    StackBarSerie sb,sb2;
    PieSerie pie;
    Graph graph;
    public void init() {
	
	setLayout(new BorderLayout());
	
	graph=new Graph();
	graph.setLabels(new String[]{"label1","label2","label3","label4","label5"});
	
	graph.setTitle(new String[]{"The JetChart Library - Chart with serie events"});
	graph.set3DEnabled(true);
	graph.setGradientColors(Color.yellow,new Color(0,140,255));
	graph.setToolTipEnabled(true);
	graph.setGridEnabled(true);
	//graph.set3DSeriesInLineEnabled(false);
	//graph.setDraggingEnabled(true);

	// The Main object is added as a listener and must implement the SerieListener interface.
	graph.addSerieListener(this);
	
	// Creates a bar serie
	b=new BarSerie(new float[]{200,210,140,430,320},"BarSerie");
	b.setColor(Color.blue);

	// Creates two stacked bars series
	sb=new StackBarSerie(new float[]{143,100,210,345,400},"Stackedbar1");
	sb.setColor(Color.yellow);

	sb2=new StackBarSerie(new float[]{320,110,400,500,300},"Stackedbar2");
	sb2.setColor(Color.orange);

	// Sets width of stacked bars to 15.
	StackBarSerie.setStackBarWidth(15);

	// Creates one pie serie. Colors are customized. If not informed, each slice will be
	// automatically assigned a predefined sequence of colors.
	pie=new PieSerie(new float[]{200,210,340,432,500});
	pie.setSliceColors(new Color[]{Color.yellow,Color.white,Color.blue,Color.lightGray,Color.green});


	// To test pie serie, enable the first line and disable subsequent addition of series.
	//graph.addSerie(pie);
	graph.addSerie(b);
	graph.addSerie(sb);
	graph.addSerie(sb2);

	// Enables serie dragging. Serie dragging is useful to provide any kind of simulation.
	// To drag a serie, move the mouse cursor over the top area of a bar or a coordinate of
	// a line serie, area serie, etc. When the cursor changes to the resize shape, click and
	// drag. While dragging a SerieEvent object is dispatched to the serieDragged(SerieEvent evt)
	// of all SerieListeners registered with the Graph object. See documentation of 
	// SerieListener and SerieEvent.
	graph.setSerieDraggingEnabled(true);

	add("Center",graph);

    }

    // When mouse is released, a SerieEvent is created and dispatched to registered SerieListeners.
    public void serieReleased(SerieEvent evt) {
    }

    // A single click over a bar or a double click over a pie slice displays a message in the console.
    public void serieClicked(SerieEvent evt) {

	// gets the index of the serie element.
	int elementIndex=evt.getSerie().getElementIndex();
	

	if (!(evt.getSerie()==pie)) {

	    // if legend was not clicked...
	    if (!evt.isOverLegend()) {
		if (evt.getSerie()==b)
		    System.out.println("Element nr "+elementIndex+" of serie named BarSerie was clicked");
		else if (evt.getSerie()==sb)
		    System.out.println("Element nr "+elementIndex+" of serie named Stackedbar1 was clicked");
		else if (evt.getSerie()==sb2)
		    System.out.println("Element nr "+elementIndex+" of serie named Stackedbar2 was clicked");
	    }
	    // when legend is clicked and serie is not a pie serie , elementIndex is -1. 
	    // Here we must test evt.getSerie(). 
	    else {
		AbstractSerie as=evt.getSerie();
		if (as==b)
		    System.out.println("Legend image of serie named BarSerie was clicked");
		else if (as==sb)
		    System.out.println("Legend image of serie named Stackedbar1 was clicked");
		else if (as==sb2)
		    System.out.println("Legend image of serie named Stackedbar2 was clicked");
	    }
	}
	
	else {
	    // if legend was not clicked...
	    if (!evt.isOverLegend()) {
		// gets clicked slice
		Slice slice=pie.getSlice(elementIndex);
		// prints the old value
		System.out.println("Old value: "+slice.getValue());
		// sets a new value
		slice.setValue(100);
		graph.repaint();
	    }
	    // when legend is clicked and serie is a pie serie, elementIndex is the slice index.
	    else
		System.out.println("Legend image of slice nr "+elementIndex+" was clicked");
	    
	}
	

    }
 
    /**
     * Line series, point series,image series, bar series, and area series can be dragged.
     * stacked bars series and pie series can't be dragged. Enable the lines inside the 
     * serieDragged() handler to see effect when any bar is dragged. When the cursor is 
     * moved over the top of each bar, its shape is changed, indicating that dragging is 
     * enabled. When performing a serie dragging, respective bar values are changed accordingly.
     * The dragging extension is limited by the minimum and maximum values initially defined
     * to the serie that is being dragged.
     */
    public void serieDragged(SerieEvent evt) {
	
	int elementIndex=evt.getSerie().getElementIndex();
	float[] values=evt.getSerie().getValues();
	if (evt.getSerie()==b)
	    System.out.println("New value of element nr "+elementIndex+" of serie named BarSerie:"+
		 	       values[elementIndex]);
	
	
    }


    public static void main(String[] args) {
	Frame f=new Frame();
	Main m=new Main();
	m.init();
	f.add("Center",m);

	f.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent evt) {
		    System.exit(0);
		}
	    });

	f.setSize(400,400);
	f.setVisible(true);
    }
}
