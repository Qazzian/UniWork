import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

/**
 *
 * This demo shows a chart with three annotations.
 * 
 */
public class Main extends Frame {
    Graph graph;
    LineSerie ls;

    public Main() {
	
	// A title for the frame
	setTitle("The Jet Chart Library - Line Serie chart demo with annotations");
	
	// Values for the series
	float[] values={226,223,221,220,221,220,215,216,219,222,223,222,223,225,228,226,223};
	
	// Creates two line series
	ls=new LineSerie(values,"Line Serie");
	ls.setColor(Color.orange);

	graph=new Graph();
	graph.setGradientColors(Color.white,Color.cyan);
	graph.set3DEnabled(true);
	graph.setSerieDraggingEnabled(true);
	graph.setToolTipEnabled(true);
	graph.setGridEnabled(true);
	
	graph.setStartDate("10012000");
	graph.setVDepth(20);

	graph.setAutoRangeOff(true);
	graph.setRangeIncrement(10);
	graph.setMinRangeValue(170);
	graph.setMaxRangeValue(250);

	// Creates three Note objects
	Note n1=new Note(new String[]{"This text is inside a Note object.",
				      "Drag it to any place you wish.",
				      "Double-click it to enable/disable opacity."},200,240);

	n1.setBackground(new Color(255,255,128));

	Note n2=new Note(new String[]{"This is the second annotation."},200,200);
	n2.setOpacityEnabled(false);

	Note n3=new Note(new String[]{"This is the third annotation"},200,100);
	
	// Adds the Note objects to the graphic context
	graph.addNote(n1);
	graph.addNote(n2);
	graph.addNote(n3);

	// Adds the line serie to the graphic context
	graph.addSerie(ls);

	add("Center",graph);

	// Adds window adapter
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(500,400);

	// Centers frame on the screen
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);

	setVisible(true);

    }

    public static void main(String[] args) {
	new Main();
    }
}
