import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

public class Main extends Frame implements ItemListener,AdjustmentListener {
    Graph graph;
    BarSerie bs1,bs2,bs3;

    Checkbox is3D,isInLine,isHorizontal;

    Scrollbar depth;

    public Main() {
	
	// A title for the frame
	setTitle("The JetChart Library - Bars Chart Demo");
	
	// Values for the series
	float[] values1={100000,200000,1500000};
	float[] values2={300000,-150000,900000};
	float[] values3={400000,350000,2500000};
	
	// Creates three bar series
	bs1=new BarSerie(values1,"Bar Serie 1");
	bs2=new BarSerie(values2,"Bar Serie 2");
	bs3=new BarSerie(values3,"Bar Serie 3");
		
	// Sets bar series properties
	setBarSeriesProperties();
	
	// Labels for chart
	String[] labels={"label1","label2","label3"};

	// Creates graphic context, passing labels
	graph=new Graph(labels);

	// Sets chart optional properties
	setChartProperties();

	// Adds the three bar series to the graphic context
	graph.addSerie(bs1);
	graph.addSerie(bs2);
	graph.addSerie(bs3);
	add("Center",graph);

	// Creates a top panel to layout components
	createTopPanel();

	// Adds window adapter
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(500,400);

	// Centers frame on the screen
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);

	setVisible(true);

    }

    // Event handler for 3D state and chart orientation
    public void itemStateChanged(ItemEvent evt) {
	if (evt.getSource()==is3D) {
	    graph.set3DEnabled(is3D.getState());
	    depth.setEnabled(is3D.getState());
	    isInLine.setEnabled(is3D.getState());
	}
	else if (evt.getSource()==isHorizontal)
	    graph.setHorizontalGraphEnabled(isHorizontal.getState());
	else if (evt.getSource()==isInLine)
	    graph.set3DSeriesInLineEnabled(isInLine.getState());
	graph.repaint();
    }

    // Event handler for chart depth adjustment
    public void adjustmentValueChanged(AdjustmentEvent evt) {
	if (evt.getSource()==depth) {
	    graph.setVDepth(depth.getValue());
	    graph.setHDepth(depth.getValue());
	    graph.repaint();
	}
    }
	    
	    
    // Creates top panel
    private void createTopPanel( ) {

	// Creates top panel with a border around
	Panel topPanel=new Panel() {
	    public void paint(Graphics g) {
		g.setColor(Color.lightGray);
		g.draw3DRect(0,0,getSize().width-1,getSize().height-1,true);
		g.draw3DRect(2,2,getSize().width-4,getSize().height-4,false);
	    }
	};

	topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
	
	//  Checkbox for 3D property.
	is3D=new Checkbox("3D");
	is3D.setFont(new Font("Arial",Font.PLAIN,10));
	is3D.addItemListener(this);
	
	// Checkbox for chart orientation property
	isHorizontal=new Checkbox("Horizontal");
	isHorizontal.setFont(new Font("Arial",Font.PLAIN,10));
	isHorizontal.addItemListener(this);

	// Checkbox for inline property
	isInLine=new Checkbox("3D series Inline");
	isInLine.addItemListener(this);
	isInLine.setFont(new Font("Arial",Font.PLAIN,10));
	isInLine.setEnabled(false);

	// Scrollbar for chart depth adjustment
	depth=new Scrollbar(Scrollbar.HORIZONTAL,5,1,0,30) {
	    public Dimension getPreferredSize() {
		Dimension d=super.getPreferredSize();
		return new Dimension(100,d.height);
	    }
	};
	
	depth.setEnabled(false);
	depth.addAdjustmentListener(this);
	
	topPanel.add(is3D);
	topPanel.add(isHorizontal);
	topPanel.add(isInLine);
	topPanel.add(new Label("3D depth:"));
	topPanel.add(depth);
    
	add("North",topPanel);

    }

    private void setBarSeriesProperties() {
	// Sets color
	bs1.setColor(Color.red);
	bs2.setColor(Color.green);
	bs3.setColor(Color.pink);

	// Sets width
	bs1.setWidth(15);
	bs2.setWidth(15);
	bs3.setWidth(15);
		
	// Enables values on marks of BarSerie bs1
	bs3.setMarkLegendEnabled(true);

	// Sets mark legend foreground color of BarSerie bs1
	bs3.setMarkLegendForeground(Color.blue);

	// Sets values font of BarSerie bs1
	bs3.setFont(new Font("Arial",Font.PLAIN,8));
    
    }

    private void setChartProperties() {

	// Enables tooltip
	graph.setToolTipEnabled(true);
	
	// Sets chart title
	String[] title={"Bars chart","Demo with three series"};
	graph.setTitle(title);
	
	// Sets labels title
	graph.setLabelsTitle("Labels Title");

	// Sets values title
	graph.setValuesTitle("Values Title");

	// Applies gradient colors to graphic context
	graph.setGradientColors(Color.yellow,new Color(51,102,255));
	//graph.setGradientOrientation(graph.LEFT_TO_RIGHT);

	// Enables chart and legend dragging. A double-click over chart alternates
	// between moving chart and scale adjustment.
	graph.setDraggingEnabled(true);

	// Enables grid and sets grid color
	graph.setGridEnabled(true);
	graph.getGrid().setColor(Color.black);
	// graph.getGrid().setCrossedLinesEnabled(true);

	// Sets legend orientation and position. Legend can be dinamically
	// dragged, if the Graph draggable property is set to true.
	graph.getLegend().setOrientation(Legend.HORIZONTAL);
	//graph.getLegend().setPosition(Legend.RIGHT);
	//graph.getLegend().setPosition(Legend.LEFT);

	// Sets format for values.
	graph.setValueFormat("###,###0.00");
    
	// Sets depth for vertical graph.
	graph.setVDepth(5);

	// Sets depth for horizontal graph.
	graph.setHDepth(5);

	// Disables inline painting of 3D series, drawing bar series side by side.
	graph.set3DSeriesInLineEnabled(false);
	
	
    }



    public static void main(String[] args) {
	new Main();
    }
}
 
