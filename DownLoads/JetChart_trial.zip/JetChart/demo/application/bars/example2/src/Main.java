import com.jinsight.jetchart.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/**
 * Main.java
 *
 *
 * Created: Mon Nov 11 
 *
 * @author Andre de Lima Soares - alsoares@jinsight.com
 */


/**
 * This example runs either as a single java application or an applet.
 * It demonstrates how to set individual colored bars in a bar serie. 
 */
public class Main extends Applet implements ItemListener {

    BarSerie b;
    Graph graph;
    public void init() {

	setLayout(new BorderLayout());

	Panel p=new Panel(new FlowLayout(FlowLayout.LEFT));
	Checkbox cb=new Checkbox("Horizontal");
	cb.addItemListener(this);
	p.add(cb);

	add("North",p);
	
	graph=new Graph();
	graph.setVDepth(10);

	graph.setLabels(new String[]{"Jan","Feb","Mar","Apr","May"});

	graph.setTitle(new String[]{"The JetChart Library - A bar chart demo with","bars individually colored"});
	graph.setTitleForeground(Color.white);
	graph.set3DEnabled(true);

	graph.setGradientColors(Color.black,Color.blue);
	graph.getXAxis().setColor(Color.black);
	graph.getYAxis().setColor(Color.red);
	graph.getXAxis().setFill3DColor(Color.green.darker());
	graph.getYAxis().setFill3DColor(Color.green.darker());
	graph.getGrid().setColor(Color.lightGray);

	graph.setToolTipEnabled(true);

	graph.setGridEnabled(true);

	graph.setDraggingEnabled(true);
	
	// Creates a bar serie.
	b=new BarSerie(new float[]{143,100,210,345,400},"Bar Serie");
	
	b.setWidth(30);
	
	b.setColors(new Color[]{Color.yellow,Color.red,Color.green,Color.pink,Color.blue});

	graph.addSerie(b);

	add("Center",graph);

    }

    public void itemStateChanged(ItemEvent evt) {
	Checkbox cb=(Checkbox)evt.getSource();
	graph.setHorizontalGraphEnabled(cb.getState());
	graph.repaint();
    }

    public static void main(String[] args) {
	Frame f=new Frame();
	Main m=new Main();
	m.init();
	f.add("Center",m);

	f.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent evt) {
		    System.exit(0);
		}
	    });

	f.setSize(400,400);
	f.setVisible(true);
    }
}
