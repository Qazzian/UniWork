import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

/**
 * Copyright Jinsight Software Solutions. All rights reserved.
 *
 * Author: Andre de Lima Soares - alsoares@jinsight.com
 * Last update: November 17, 2000
 * Version: 1.0.
 */

public class Main extends Frame implements ItemListener,SerieListener  {
    Graph graph;

    Checkbox cb1,cb2,cb3,cb4,cb5,cb6;
    OHLCSerie ohlc;
    public Main() {
	
	// A title for the frame
	setTitle("The JetChart Library - OHLC Chart Demo");
	
	// Creates OHLC serie. Each bidimensional array element is a float array
	// with four values: high,low,open and close. When an OHLC serie type is set
	// to BAR_HLC or LINE_HLC , the third value(open) is disregarded.
	ohlc=new OHLCSerie(new float[][]{{70,30,40,60},{75,50,70,55},{68,43,45,65},
					 {65,38,40,60},{73,43,60,51},{50,20,30,45},
					 {48,30,47,33},{65,40,50,65},{80,50,50,73},
					 {85,55,70,60},{100,75,83,90},{95,80,82,91},
					 {80,60,76,65},{78,50,50,63},{67,44,47,61}});
	
	ohlc.setHighlightEnabled(true);
	ohlc.setHighlightColor(Color.green);

	ohlc.setType(OHLCSerie.CANDLESTICK);
	
	// Sets candlestick width
	ohlc.setWidth(4);

	// Sets color of bars when OHLC serie type is 'BAR_OHLC' or 'BAR_HLC'.
	ohlc.setColor(Color.blue.darker());

	// Sets size of dashes, when OHLC serie type is 'BAR_OHLC' or 'BAR_HLC'.
	ohlc.setDashSize(6);

	// Sets color of bearish candle sticks. Default is black.
	ohlc.setBearishColor(Color.red);
	// Sets color of bullish candle sticks. Default is white.
	ohlc.setBullishColor(Color.green);

	// Sets LINE_OHLC/LINE_HLC  chart line thickness
	ohlc.setLineThickness(3);

	graph=new Graph();
	graph.setDraggingEnabled(true);

	graph.setToolTipEnabled(true);
	// Sets a text to be prefixed in the tooltip.
	graph.setToolTipLabel("Date:");
	graph.getToolTip().setFont(new Font("Monospaced",Font.PLAIN,10));

	// Sets tooltip type to display label after prefixed text.
	graph.setToolTipType(Graph.LABEL_AND_VALUE);
	
	graph.setTitle(new String[]{"HLOC(High-Low-Open-Close) Chart Demo","with a 14 days period."});
	graph.setGridEnabled(true);
	graph.getGrid().setColor(Color.lightGray);

	// Disables automatic scale. Sets max value of scale to 100 with increment of 10.
	graph.setAutoRangeOff(true);
	graph.setRangeIncrement(10);
	graph.setMaxRangeValue(120);
	//graph.setMinRangeValue(10);

	graph.addSerie(ohlc);

	graph.addSerieListener(this);
       
	// The following two lines have no effect wher an OHLC serie is added to the chart.
	// Are here just for demonstration purpose.
	graph.set3DEnabled(true);
	graph.setHorizontalGraphEnabled(true);
	
	
	// Sets a start date. Labels are calculated automatically from this date.
	graph.setStartDate("09012000");

	// A new method. Increment is passed in the second argument.
	// Here we have a two-week increment. It is the same as
	// graph.setDateIncrement(Graph.WEEK_INCREMENT,2)
	graph.setDateIncrement(Graph.DAY_INCREMENT,14);

	
	// A Note object is simply a way to put customized notes over the chart.
	// Here, the position is statically defined as 200,210, but the Note object
	// can be dragged anywhere.
	Note note=new Note(new String[]{"This text is inside a Note object.",
					"Drag it to any place you wish.","Double-click it to enable/disable opacity."},
			   225,265);

	note.setBackground(new Color(255,255,204));
	note.setForeground(Color.blue.darker());
	note.setFont(new Font("Arial",Font.PLAIN,10));
	note.setOpacityEnabled(false);
	graph.addNote(note);
	
	graph.setSerieDraggingEnabled(true);

	add("Center",graph);

	// Creates a top panel to layout components
	createTopPanel();

	// Adds window adapter
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(600,360);

	// Centers frame on the screen
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);

	setVisible(true);

    }

    public void itemStateChanged(ItemEvent evt) {
	if (evt.getSource()==cb1) {
	    ohlc.setType(OHLCSerie.CANDLESTICK);
	    ohlc.setWidth(4);
	}
	else if (evt.getSource()==cb2) {
	    ohlc.setType(OHLCSerie.ROUNDED_CANDLESTICK);
	    ohlc.setWidth(4);
	}
	else if (evt.getSource()==cb3) {
	    ohlc.setType(OHLCSerie.BAR_OHLC);
	    ohlc.setWidth(2);
	}
	else if (evt.getSource()==cb4) {
	    ohlc.setType(OHLCSerie.BAR_HLC);
	    ohlc.setWidth(2);
	}
	else if (evt.getSource()==cb5) {
	    ohlc.setType(OHLCSerie.LINE_OHLC);
	}
	else if (evt.getSource()==cb6) {
	    ohlc.setType(OHLCSerie.LINE_HLC);
	}
	graph.repaint();
    }


    // This method is the handler of serie click events. Analyze it carefully  to understand
    // how to handle click events on series with multiple values associated with each coordinate.
    public void serieClicked(SerieEvent evt) {

	// If the serie clicked was the OHLCSerie...
	if (evt.getSerie() instanceof OHLCSerie) {
	    // gets the bidimensional array that contains all OHLCSerie values.
	    float[][] multipleValues=evt.getSerie().getMultipleValues();
	    
	    // gets the float array with ohlc values associated with the element.
	    float[] values=multipleValues[evt.getSerie().getElementIndex()];
	    
	    // prints values to the standard output. 
	    System.out.println("High:"+values[0]+" Low:"+values[1]+" Open:"+values[2]+" Close:"+values[3]);
	}
	// To test this block, create a LineSerie and add it to the chart.
	// Then click over any coordinate to see its respective value printed in the
	// standard output.
	else {
	    // gets the unidimensional array that contains values.
	    float[] values=evt.getSerie().getValues();
	    // prints value  to the standard output.
	    System.out.println(values[evt.getSerie().getElementIndex()]);
	}
    }

    // this method has no effect on OHLCSeries.
    // An ohlc serie implements the NoDraggable interface.
    public void serieDragged(SerieEvent evt) {
    }

    public void serieReleased(SerieEvent evt) {
    }
	    
    // Creates top panel
    private void createTopPanel( ) {

	// Creates top panel with a border around
	Panel topPanel=new Panel() {
	    public void paint(Graphics g) {
		g.setColor(Color.lightGray);
		g.draw3DRect(0,0,getSize().width-1,getSize().height-1,true);
		g.draw3DRect(2,2,getSize().width-4,getSize().height-4,false);
	    }
	};

	topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
	topPanel.setFont(new Font("monospaced",Font.PLAIN,10));
	
	CheckboxGroup cbg=new CheckboxGroup();
	cb1=new Checkbox("CandleStick",true,cbg);
	cb2=new Checkbox("Rounded CandleStick",false,cbg);
	cb3=new Checkbox("OHLC Bar",false,cbg);
	cb4=new Checkbox("HLC Bar",false,cbg);
	cb5=new Checkbox("OHLC Line",false,cbg);
	cb6=new Checkbox("HLC Line",false,cbg);
	cb1.addItemListener(this);
	cb2.addItemListener(this);
	cb3.addItemListener(this);
	cb4.addItemListener(this);
	cb5.addItemListener(this);
	cb6.addItemListener(this);

	topPanel.add(cb1);
	topPanel.add(cb2);
	topPanel.add(cb3);
	topPanel.add(cb4);
	topPanel.add(cb5);
	topPanel.add(cb6);
	add("North",topPanel);

    }

    public static void main(String[] args) {
	new Main();
    }
}
