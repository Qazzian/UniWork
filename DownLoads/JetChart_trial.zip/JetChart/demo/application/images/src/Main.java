import java.awt.*;
import java.awt.event.*;
import com.jinsight.jetchart.*;

/**
 *
 * This demo shows a chart with one Image Serie.
 * 
 */ 
    
public class Main extends Frame implements ItemListener {
    Graph graph;
    ImageSerie is;

    Checkbox isHorizontal;

    public Main() {
	
	// A title for the frame
	setTitle("The JetChart Library - Image Chart Demo");
	
	// Values for the series
	float[] values={400,70,130,250};

	// Creates Image Serie
	Image img1=getToolkit().getImage("floppy.gif");
	Image img2=getToolkit().getImage("cdrom.gif");
	Image img3=getToolkit().getImage("floppy.gif");
	Image img4=getToolkit().getImage("cdrom.gif");
	Image[] images={img1,img2,img3,img4};	
	is=new ImageSerie(values,images);
	
	// Labels for chart
	String[] labels={"floppy","cd-rom","floppy","cd-rom"};

	// Creates graphic context, passing labels
	graph=new Graph(labels);

	// Sets chart optional properties
	setChartProperties();

	// Adds the image serie  to the graphic context
	graph.addSerie(is);

	add("Center",graph);

	// Creates a top panel to layout components
	createTopPanel();

	// Adds window adapter
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent evt) {
		System.exit(0);
	    }
	});

	setSize(400,360);

	// Centers frame on the screen
	Dimension d=getToolkit().getScreenSize();
	setLocation((d.width-getSize().width)/2,(d.height-getSize().height)/2);

	setVisible(true);

    }

    // Event handler for  chart orientation
    public void itemStateChanged(ItemEvent evt) {
	graph.setHorizontalGraphEnabled(isHorizontal.getState());
	graph.repaint();
    }

	    
    // Creates top panel
    private void createTopPanel( ) {

	// Creates top panel with a border around
	Panel topPanel=new Panel() {
	    public void paint(Graphics g) {
		g.setColor(Color.lightGray);
		g.draw3DRect(0,0,getSize().width-1,getSize().height-1,true);
		g.draw3DRect(2,2,getSize().width-4,getSize().height-4,false);
	    }
	};

	topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
	
	// Checkbox for chart orientation property
	isHorizontal=new Checkbox("Horizontal");
	isHorizontal.setFont(new Font("Arial",Font.PLAIN,10));
	isHorizontal.addItemListener(this);

	topPanel.add(isHorizontal);

	add("North",topPanel);

    }


    private void setChartProperties() {

	// Sets gradient colors
	graph.setGradientColors(Color.white,Color.gray);

	// Enables tooltip
	graph.setToolTipEnabled(true);
	
	// Sets chart title
	String[] title={"Images chart","Demo with one serie"};
	graph.setTitle(title);
	
	// Sets labels title
	graph.setLabelsTitle("Labels Title");

	// Sets values title
	graph.setValuesTitle("Values Title");

	// Enables chart and legend dragging. A double-click over chart alternates
	// between moving chart and scale adjustment.
	graph.setDraggingEnabled(true);

	// Enables grid and sets grid color
	graph.setGridEnabled(true);
	graph.getGrid().setColor(Color.blue);
	// graph.getGrid().setCrossedLinesEnabled(true);

	// Sets format for values.
	graph.setValueFormat("###,###0.00");
    

    }



    public static void main(String[] args) {
	new Main();
    }
}
